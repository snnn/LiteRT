# Shared NNPACK tensor runner

This directory provides `litert::tensor::NnpackRunner`, the abstract base class
that manages tensor inputs, outputs, buffers, and execution order for concrete
runtime adapters. [XnnpackRunner](../xnnpack/runner.h) implements its backend
hooks using XNNPACK. Graph construction and operator lowering live in
[`litert/tensor/backends`](../../backends).

Start with [runner.h](runner.h) for the public API and backend contract, then
read `NnpackRunner::Run()` in [runner.cc](runner.cc) to follow execution.
For an example that builds and runs a tensor expression, see the
[XNNPACK runner README](../xnnpack/README.md).

## Directory structure

| File | Responsibility |
| --- | --- |
| [runner.h](runner.h) | Declares `NnpackRunner`, its input/output API, typed convenience overloads, graph and buffer accessors, shared state, and pure virtual backend hooks. |
| [runner.cc](runner.cc) | Implements input/output validation, buffer allocation and growth, input updates, lazy preparation, and the reshape/setup/invoke sequence. |
| [runner_test.cc](runner_test.cc) | Tests the base class using a small identity backend with injectable failures. Covers buffer behavior, validation, shape changes, execution, and status propagation. |
| [runner_test_suite.h](runner_test_suite.h) | Defines the reusable Google Test typed suite `NnpackRunnerTest` for numerical and integration tests against concrete backends. |
| [BUILD](BUILD) | Defines the `:runner` library, `:runner_test` executable, and test-only `:runner_test_suite` header library. Default visibility is limited to `//litert/tensor` and its subpackages. |

## Graph and runtime state

The constructor takes ownership of an already-built
`std::unique_ptr<NnpackGraph>`. The base class stores the following state:

| State or dependency | How it is used |
| --- | --- |
| `graph_` | Owns the [NnpackGraph](../../backends/common_nnpack/graph.h), which contains value metadata, tensor lookup information, external-value flags, and storage that keeps constants alive. A concrete graph subclass can also own the backend subgraph. |
| `NnpackValue` | Describes a graph value with `info` (type, shape, and other tensor metadata), a backend value `id`, role `flags`, and optional locked constant data. |
| `external_buffers_` | Maps backend value IDs to `std::shared_ptr<Buffer>` for runtime inputs and outputs. These buffers stay available across runs. |
| `num_threads_` | Defaults to one. The base `SetNumThreads()` stores the count, which is passed to `CreateRuntime()`. A concrete runner manages any threadpool resources. |
| `runtime_prepared_` | Records whether runtime creation has succeeded. Later runs reuse the prepared runtime. |
| [Buffer abstractions](../../buffer.h) | Supply owning CPU allocations, non-owning views, mutable access, and `LockedBufferSpan` objects for scoped data access. |
| [Common backend utilities](../../backends/common_nnpack/utils.cc) | Provide `ToNnpackDims()`, which converts input shapes to `size_t` dimensions and rejects negative dimensions before passing them to the backend. |

The lookup path is `TensorHandle` → `NnpackGraph::Lookup()` → index in
`graph.values()` → `NnpackValue::id` → entry in `external_buffers_`. A value's
vector index and backend ID are distinct concepts. Tensor handles identify
values by their underlying graph tensor, so a newly created tensor with the
same name is not a replacement for the original handle.

`graph()` and `external_buffers()` expose the stored state for inspection.
Their mutable counterparts provide direct access; changes made through them
bypass the public setters' validation. The base class is movable and
non-copyable. Backend runtime ownership and cleanup belong to the concrete
runner.

## Execution lifecycle

```mermaid
flowchart TD
    A[Run] --> B[PrepareRuntime: create once]
    B --> C[Set input shapes and check buffers]
    C --> D[ReshapeRuntime]
    D --> E[Query output shapes and reserve buffers]
    E --> F[SetupExternalValues: bind and lock buffers]
    F --> G[InvokeRuntime]
```

`PrepareRuntime()` calls `CreateRuntime(num_threads_)` only while
`runtime_prepared_` is false. It sets that flag after successful creation, so a
failed attempt can be retried. Call it explicitly to prepare in advance, or
let `Run()` call it lazily. Preparation creates the runtime; it does not bind
buffers or propagate input shapes. Configure thread counts and backend options
before preparing: the base class does not invalidate a prepared runtime when
configuration changes.

Every `Run()` performs these steps:

1. Prepare the runtime if necessary.
2. For each external input, convert its current shape, call
   `SetExternalValueShape()`, require an associated buffer, and check its
   capacity through `Reserve()`.
3. Call `ReshapeRuntime()` to propagate shapes through the backend graph.
4. For each external output, call `GetExternalValueShape()`, update
   `value.info.shape`, and reserve enough output storage. Missing output buffers
   are allocated automatically.
5. Call `SetupExternalValues()` with the graph values, external-buffer map,
   and a local vector of buffer locks.
6. Call `InvokeRuntime()`. The lock vector remains alive through invocation and
   is released when `Run()` returns.

Each step propagates its first non-OK status to the caller. Subsequent runs
repeat shape propagation and buffer setup using the same prepared runtime.

## Inputs, outputs, and buffer lifetimes

| API | Behavior |
| --- | --- |
| `SetInput(tensor, bytes, copy_data)` | Requires an external input and an exact byte count for its current shape. Defaults to a read-only `SpanCpuBuffer` view; `copy_data = true` creates an `OwningCpuBuffer`. The mutable-byte-span overload delegates to the same implementation. |
| `SetInput(tensor, sequence)` | Checks the sequence element type and binds a non-owning view. The rvalue overload is deleted to reject temporary sequences. |
| `SetInputAsCopy(tensor, sequence)` | Checks the element type and unconditionally copies the sequence into owning storage. |
| `SetInput(tensor, external_tensor)` | Requires matching tensor types and an attached source buffer. Reserves enough capacity for the source shape, retains the resulting shared buffer reference, and adopts that shape in the runner's metadata. |
| `SetOutput(tensor, bytes)` | Requires an external output and an exact byte count for its currently recorded shape. Stores a writable `MutableSpanCpuBuffer` view; it never copies the supplied data. Omit this call to let `Run()` allocate output storage. |
| `ReshapeInput(tensor, shape)` | Updates the runner's input metadata and, when an owning buffer is already bound, grows it if necessary. Shape propagation and non-owning buffer capacity checks occur during the next `Run()`. |
| `WriteInput(tensor, offset_bytes, data)` | Locks an existing input buffer for mutable access, checks the write against its capacity, and copies bytes at the requested byte offset. Typed span and sequence overloads are byte-conversion helpers. |
| `ReadOutput(tensor)` | Returns a locked read-only byte view of a bound output buffer. It validates the tensor's output role and buffer presence. |
| `ReadOutputAs<T>(tensor)` | Adds an element-type check and returns a typed locked view of the same output storage. |

The internal `Reserve()` helper allocates a missing buffer, keeps a buffer that
already has sufficient capacity, or replaces an undersized `OwningCpuBuffer`.
It rejects undersized non-owning views. Its `preserve_data` argument determines
whether existing bytes are copied when an owning buffer grows.

Keep these details in mind when reusing a runner:

- **Views borrow storage.** Memory backing non-owning buffers must remain valid
  while the runner uses it. A shared pointer to a view keeps the buffer wrapper
  alive, but does not make the underlying memory owned.
- **Mutable input updates require mutable storage.** The ordinary `SetInput()`
  span and sequence overloads bind read-only views, even when the source is
  mutable. Use copied inputs or attach a `MutableSpanCpuBuffer` through an
  external tensor when using `WriteInput()`.
- **Reshaping updates runner metadata.** It does not change the original tensor
  handle's shape. Growing an owning input via `ReshapeInput()` uses
  `preserve_data = false`; fill the new buffer before invoking the runtime.
  A non-owning input can be rebound after reshaping, before the next run.
- **Output capacity and logical shape can differ.** `Reserve()` does not shrink
  existing buffers, and `ReadOutput()` locks the entire buffer. After a smaller
  output shape is reported, use `graph().values()[index].info` to determine the
  logical output size instead of assuming the returned span was shortened.
  Prefer automatic output allocation when output sizes can grow.
- **Read views are not snapshots.** Later runs can overwrite the same storage.
  Copy results that must be retained across invocations.

Unknown tensor handles produce `NotFound` through the graph lookup. Incorrect
roles, mismatched types or byte counts, immutable writes, negative runtime
input dimensions, and undersized views generally produce `InvalidArgument`.
Missing input/output buffers produce `FailedPrecondition` where required.
Backend statuses pass through the shared runner unchanged.

## Backend implementation contract

A concrete runner implements the following pure virtual methods:

| Hook | Responsibility |
| --- | --- |
| `FlagExternalInput()` / `FlagExternalOutput()` | Return the role bits used by the graph builder and backend. The shared runner uses these bits to select values for input/output operations. |
| `CreateRuntime(num_threads)` | Create and retain the executable runtime from the owned graph. Return a failure status if creation fails. |
| `SetExternalValueShape(id, dims)` | Apply the current shape of one external input to the backend runtime. |
| `ReshapeRuntime()` | Propagate shapes and prepare backend storage for the current inputs. |
| `GetExternalValueShape(id, dims)` | Populate the output dimensions reported by the runtime after reshaping. |
| `SetupExternalValues(values, external_buffers, locks)` | Bind external values to their host buffers and retain the locks needed for invocation in the supplied vector. The value list also contains internal values, so the implementation must select the external ones. |
| `InvokeRuntime()` | Execute the prepared and bound runtime, completing buffer access before returning. |

[The XNNPACK adapter](../xnnpack/runner.cc) shows the production implementation
of these hooks. `TestRunner` in [runner_test.cc](runner_test.cc) is a smaller
example: it copies input bytes to the output and reports the input shape as the
output shape. Its `FailOn()` method injects errors at individual backend hooks.

When extending runtime behavior, keep shared buffer rules and execution order
in this directory, backend API calls in the concrete runner, and graph
conversion or operator lowering in the backend directories.

## Tests and build targets

There are two complementary testing components:

| Component | Coverage and extension point |
| --- | --- |
| [runner_test.cc](runner_test.cc) | Exercises the base API with the identity backend: copy/view semantics, source-tensor binding, mutable writes, exact size and role validation, unknown handles, reshaping and buffer capacity, output allocation and reads, move construction, and failures from every execution hook. Add backend-independent buffer and lifecycle cases here. |
| [runner_test_suite.h](runner_test_suite.h) | Builds real tensor expressions and checks concrete runner results. Covers representative FP32 arithmetic, activations, convolution variants, fully connected and batch matrix multiplication, shape operations, reductions, resize, constants, runtime inputs, move operations, and buffer growth/errors. Add shared backend integration cases here. |

The typed suite's fixture takes a traits type with the following members:

| Traits member | Meaning |
| --- | --- |
| `Tag` | Tensor backend mixin tag; the fixture constructs `Tensor<Tag>`. |
| `Runner` | Concrete runner type with `Create(outputs)` and the shared input/output API. |
| `kFlagExternalInput`, `kFlagExternalOutput` | Flag values used to inspect graph roles. |
| `kSupportsConv2D`, `kSupportsDepthwiseConv2D`, `kSupportsTransposeConv2D`, `kSupportsResize` | Compile-time gates for the corresponding optional test groups. |

See [XnnpackTestTraits](../xnnpack/runner_test.cc) for an instantiation using
`INSTANTIATE_TYPED_TEST_SUITE_P`. A backend test target depends on its runner,
its arithmetic backend, `:runner_test_suite`, and Google Test. When adding a
`TYPED_TEST_P` case, also add its name to `REGISTER_TYPED_TEST_SUITE_P` at the
end of the header.

These are representative FP32 integration tests. The resize capability flag
gates successful resize cases; the nearest-neighbor rejection cases still run
without that flag. Check individual tests when adding a backend or changing
capability flags.

Run these commands from the repository root:

```sh
# Build the shared implementation.
bazel build //litert/tensor/runners/common_nnpack:runner

# Test shared behavior with the identity backend.
bazel test //litert/tensor/runners/common_nnpack:runner_test --test_output=errors

# Run the reusable typed suite against XNNPACK.
bazel test //litert/tensor/runners/xnnpack:runner_test --test_output=errors
```

`:runner_test_suite` is a test-only library of test definitions; a concrete
backend's test executable instantiates and runs them.
