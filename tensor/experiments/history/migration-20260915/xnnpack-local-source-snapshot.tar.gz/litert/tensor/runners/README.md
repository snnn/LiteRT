# Tensor runners

Runners bind host data to a lowered tensor graph and execute it. This directory
contains the shared `NnpackRunner` lifecycle and its concrete XNNPACK adapter.
Read the [XNNPACK usage example](xnnpack/README.md#example) to run a graph, or
start with the [shared runner](common_nnpack/README.md) when changing buffer
handling or execution order.

## Components

| Directory | Responsibility |
| --- | --- |
| [common_nnpack](common_nnpack/README.md) | `NnpackRunner` owns graph metadata and external buffers, implements the input/output API, and coordinates preparation, shape propagation, buffer binding, and invocation through virtual backend hooks. It also provides unit tests with an identity backend and a reusable typed integration suite. |
| [xnnpack](xnnpack/README.md) | `XnnpackRunner` implements those hooks with the XNNPACK C API, owns the runtime and pthreadpool, and accepts a caller-owned weights cache. Its factory lowers requested tensor outputs through `BuildXnnpackGraph()`. |

Graph construction and operation lowering live in
[`backends`](../backends), while the public tensor and buffer abstractions live
in [tensor.h](../tensor.h) and [buffer.h](../buffer.h).

## From a graph to an invocation

```mermaid
flowchart LR
    T[Tensor expression outputs] --> B[Backend graph conversion]
    B --> G[Owned graph]
    G --> R[NnpackRunner lifecycle]
    I[Host input buffers] --> R
    R --> H[XnnpackRunner hooks]
    H --> X[XNNPACK runtime]
    X --> O[Output buffers]
```

For XNNPACK, `XnnpackRunner::Create(outputs)` builds and takes ownership of the
graph. The caller configures the runner and binds external inputs. The first
`Run()` creates the runtime lazily; `PrepareRuntime()` can perform that step
in advance. Every run then propagates input shapes, obtains output shapes,
reserves output storage, binds external buffers, and invokes the runtime.
Buffer locks remain alive through invocation.

The same runner can execute repeatedly with new input data and backend-supported
shape changes. The runtime is reused, while shapes and buffer bindings are
updated for each invocation. Tensor handles identify values through the owned
graph's lookup table; names alone do not identify runtime inputs or outputs.

The shared API includes copied or borrowed input binding, optional caller
output storage, input reshaping and partial writes, and locked output reads.
Borrowed storage must remain valid while used, and non-owning views cannot
grow automatically. Configure threading and XNNPACK's weights cache before
runtime preparation. See the child READMEs for detailed ownership and resizing
rules.

## Where to make changes

| Change | Starting point |
| --- | --- |
| Input/output validation, buffer growth, or execution order | [NnpackRunner implementation](common_nnpack/runner.cc) and its [unit tests](common_nnpack/runner_test.cc). |
| XNNPACK runtime calls, threadpool management, or weights-cache plumbing | [XnnpackRunner interface](xnnpack/runner.h) and [implementation](xnnpack/runner.cc). |
| An operation's backend representation | The [XNNPACK arithmetic backend](../backends/xnnpack/arithmetic.cc). |
| Numerical integration cases shared by concrete runners | [runner_test_suite.h](common_nnpack/runner_test_suite.h), with traits and instantiation in [xnnpack/runner_test.cc](xnnpack/runner_test.cc). |
| Another runtime adapter using the same lifecycle | Implement the [shared backend hook contract](common_nnpack/README.md#backend-implementation-contract), own the backend resources in the concrete runner, and supply graph conversion plus test traits. |

The shared runner tests and the
[backend numerical test framework](../backends/testing/README.md) are separate
test layers: the former directly exercises the runner API, while the latter
uses a `TestBackendBridge` abstraction to test operators across backends.

## Build and test

This directory groups packages; its children contain the Bazel targets. From
the repository root, use Bazel or Bazelisk:

```sh
bazelisk build //litert/tensor/runners/common_nnpack:runner \
  //litert/tensor/runners/xnnpack:runner
bazelisk test //litert/tensor/runners/common_nnpack:runner_test \
  //litert/tensor/runners/xnnpack:runner_test --test_output=errors
```

The common runner library is visible within `//litert/tensor` and its
subpackages; the XNNPACK runner library is public. The common typed suite is a
test-only library instantiated by the XNNPACK test executable.
