# XNNPACK tensor runner

This directory implements `litert::tensor::XnnpackRunner`, which executes LiteRT
tensor expression graphs on the CPU through XNNPACK. It connects the tensor
API's graph and buffer abstractions to XNNPACK's runtime API.

Start with [runner.h](runner.h) for the public interface and resource ownership,
then read [runner.cc](runner.cc) for the XNNPACK calls. The inherited execution
flow lives in [the shared runner implementation](../common_nnpack/runner.cc).

## Directory structure

| File | Responsibility |
| --- | --- |
| [runner.h](runner.h) | Declares `XnnpackRunner`, its factory and runtime hooks. Implements thread configuration, weights-cache access, move operations, and resource cleanup. |
| [runner.cc](runner.cc) | Implements runtime creation, shape propagation, external-buffer binding, and invocation using the XNNPACK C API. |
| [runner_test.cc](runner_test.cc) | Supplies `XnnpackTestTraits` and instantiates the shared `NnpackRunnerTest` typed test suite for XNNPACK. |
| [BUILD](BUILD) | Defines the public Bazel library `:runner` and the Google Test target `:runner_test`, including their dependencies. |

## How the components fit together

```mermaid
flowchart TD
    T[LiteRT tensor expressions] --> B[BuildXnnpackGraph]
    B --> G[XnnpackGraph]
    G --> R[XnnpackRunner]
    N[NnpackRunner: shared execution flow] -. inherited by .-> R
    R --> X[XNNPACK runtime]
```

Several components used here live in neighboring directories:

| Component | Role |
| --- | --- |
| [Tensor API](../../tensor.h) and [arithmetic API](../../arithmetic.h) | Represent tensors and build expressions such as `Add(input, bias)`. Tensor handles identify graph values when setting inputs or reading outputs. |
| [XNNPACK arithmetic backend](../../backends/xnnpack/arithmetic.h) | Defines `XnnpackMixinTag` and operation extensions. Their `ToXnnpack()` implementations in [arithmetic.cc](../../backends/xnnpack/arithmetic.cc) lower tensor operations into XNNPACK nodes. |
| [XNNPACK conversion](../../backends/xnnpack/conversion.cc) | Implements `BuildXnnpackGraph()`: discovers the graph from requested outputs, identifies external values, initializes XNNPACK once, defines tensor values, and lowers operations. |
| [XnnpackGraph](../../backends/xnnpack/graph.h) and [NnpackGraph](../../backends/common_nnpack/graph.h) | Own the XNNPACK subgraph and maintain tensor-to-value mappings, shapes, external input/output flags, and storage needed to keep constants alive. Each `NnpackValue` holds metadata, an XNNPACK value ID, flags, and an optional locked constant buffer. |
| [NnpackRunner](../common_nnpack/runner.h) | Owns the graph and external-buffer map. Implements the public input/output API, lazy runtime preparation, and the sequence of reshape, setup, and invoke calls. It delegates backend operations to virtual hooks implemented here. |
| [Buffer abstractions](../../buffer.h) | Provide owning CPU storage, non-owning views, and `LockedBufferSpan` objects that keep buffers locked while their data is accessed. |
| [XNNPACK status conversion](../../backends/xnnpack/utils.h) | Converts `xnn_status` results into `absl::Status` for error propagation. |

## Execution lifecycle

1. **Build the graph.** `XnnpackRunner::Create(outputs, runtime_flags = 0)` calls
   `BuildXnnpackGraph()` and takes ownership of the result. Graph construction
   follows the requested outputs back through their dependencies. Leaf inputs
   without attached buffers become external inputs; buffered constants are
   retained by the graph. The requested outputs become external outputs.
   Alternatively, the explicit constructor accepts an existing
   `std::unique_ptr<XnnpackGraph>` and optional runtime flags. Flags are fixed
   when constructing the runner and retained across moves.
2. **Configure and bind inputs.** Set the thread count and optional weights
   cache, then supply data for every external input through the inherited
   `SetInput()` or `SetInputAsCopy()` methods.
3. **Prepare the runtime.** `PrepareRuntime()` calls `CreateRuntime()` once.
   The XNNPACK implementation passes the subgraph, weights cache, and threadpool
   to `xnn_create_runtime_v3()` with the configured flags, which default to
   zero. `Run()` performs this step
   lazily if needed. Preparation creates the runtime; shape propagation and
   buffer binding happen during `Run()`.
4. **Reshape on each run.** The shared runner sends current input shapes to
   XNNPACK, checks input-buffer capacity, and reshapes the runtime. It then
   queries output shapes, updates its graph metadata, and allocates or grows
   owning output buffers as needed.
5. **Bind and invoke.** `SetupExternalValues()` builds an array of
   `xnn_external_value` records from the external-buffer map. It locks each
   buffer and calls `xnn_setup_runtime_v2()`. The shared runner keeps those
   locks alive until `xnn_invoke_runtime()` returns.
6. **Read or reuse.** Read the result through `ReadOutput()` or
   `ReadOutputAs<T>()`. Subsequent `Run()` calls reuse the runtime and repeat
   shape propagation, buffer setup, and invocation, allowing new input data
   and supported shape changes.

The hooks in [runner.cc](runner.cc) map directly to XNNPACK entry points:

| Runner hook | XNNPACK call |
| --- | --- |
| `CreateRuntime()` | `xnn_create_runtime_v3()` |
| `SetExternalValueShape()` | `xnn_reshape_external_value()` |
| `ReshapeRuntime()` | `xnn_reshape_runtime()` |
| `GetExternalValueShape()` | `xnn_get_external_value_shape()` |
| `SetupExternalValues()` | `xnn_setup_runtime_v2()` |
| `InvokeRuntime()` | `xnn_invoke_runtime()` |

## Example

This function builds an addition graph, supplies a runtime input, and returns
the result `{10.5f, 20.5f}`. It uses copied input data so the runner owns the
input storage.

```cpp
#include <vector>

#include "absl/status/status.h"
#include "absl/status/statusor.h"
#include "litert/tensor/arithmetic.h"
#include "litert/tensor/backends/xnnpack/arithmetic.h"
#include "litert/tensor/datatypes.h"
#include "litert/tensor/runners/xnnpack/runner.h"
#include "litert/tensor/tensor.h"

namespace litert::tensor {

absl::StatusOr<std::vector<float>> EvaluateAdd() {
  using XnnTensor = Tensor<XnnpackMixinTag>;
  XnnTensor input({.name = "input", .type = Type::kFP32, .shape = {2}});
  XnnTensor bias({.name = "bias",
                  .type = Type::kFP32,
                  .shape = {2},
                  .buffer = std::vector<float>{0.5f, 0.5f}});
  XnnTensor sum = Add(input, bias);

  auto runner = XnnpackRunner::Create({sum});
  if (!runner.ok()) return runner.status();
  runner->SetNumThreads(2);

  absl::Status status =
      runner->SetInputAsCopy(input, std::vector<float>{10.f, 20.f});
  if (!status.ok()) return status;
  status = runner->Run();
  if (!status.ok()) return status;

  auto result = runner->ReadOutputAs<float>(sum);
  if (!result.ok()) return result.status();
  return std::vector<float>(result->begin(), result->end());
}

}  // namespace litert::tensor
```

Consumers that build expressions need dependencies on both
`//litert/tensor/runners/xnnpack:runner` and
`//litert/tensor/backends/xnnpack:arithmetic`, as well as the targets for the
tensor API and other headers they include directly.

## Buffers, shapes, and ownership

The input/output methods are inherited from `NnpackRunner`:

| API | Behavior |
| --- | --- |
| `SetInput(tensor, data, copy_data)` | Binds a byte span whose size matches the current input shape. Defaults to a non-owning view; `copy_data = true` creates owned storage. |
| `SetInput(tensor, sequence)` | Checks the element type and keeps a non-owning view of a contiguous sequence. Temporary sequences are rejected by a deleted overload. |
| `SetInputAsCopy(tensor, sequence)` | Checks the element type and always copies the sequence. |
| `SetInput(tensor, external_tensor)` | Takes the source tensor's shape and buffer, checks that the types match, and retains a shared buffer reference. |
| `SetOutput(tensor, data)` | Binds a writable, non-owning byte span for a graph output. Its size must match the output shape currently recorded by the runner. If this call is omitted, `Run()` allocates output storage automatically. |
| `ReshapeInput(tensor, shape)` | Updates the runner's input metadata and grows existing owning storage when necessary. Shape changes reach XNNPACK on the next `Run()`. |
| `WriteInput(tensor, offset_bytes, data)` | Writes into an existing mutable input buffer with bounds checking. |
| `ReadOutput()` / `ReadOutputAs<T>()` | Returns a locked view of output storage; the typed version also checks the tensor element type. |

Keep memory backing non-owning input and output views alive while it is bound
and used. Such views cannot grow automatically: `Run()` fails if a shape change
requires more bytes than they provide. After reshaping an input, rebind it to
sufficiently large storage as needed. Prefer automatically allocated output
buffers when output sizes can grow.

Growing owning input storage with `ReshapeInput()` does not preserve its
contents; populate it again with `SetInputAsCopy()` or `WriteInput()` before the
next run. Output views refer to storage that later runs may overwrite, so copy
results that must be retained.

Shapes are stored in the runner's `NnpackValue::info`; `ReshapeInput()` uses the
original tensor handle as an identifier and does not update that handle's
shape. After a run, inspect `runner.graph().values()` and the graph's `Lookup()`
mapping for the runtime's output shapes.

`XnnpackRunner` is movable and non-copyable. Its runtime is held in a
`unique_ptr` whose deleter calls `xnn_delete_runtime()`. The runner also owns
and destroys its pthreadpool. The default thread count is one; `SetNumThreads()`
creates a pool only for counts greater than one.

The weights cache is a borrowed `xnn_weights_cache_t`: the caller manages its
creation, finalization, and lifetime, and must keep it alive while the runtime
uses it. Configure the cache and thread count before `PrepareRuntime()` or the
first `Run()`. Preparation is cached, and these setters do not rebuild an
existing runtime. The `runtime()`, `threadpool()`, and `weights_cache()` getters
expose borrowed handles.

## Errors and tests

The factory returns `absl::StatusOr<XnnpackRunner>`; execution and buffer
operations return statuses. Shared-runner validation reports issues such as
incorrect tensor roles, mismatched types or byte counts, missing input buffers,
and non-owning buffers that are too small. The XNNPACK adapter also reports
missing or un-lockable external buffers as `FailedPrecondition` errors.
`XnnStatusToAbsl()` currently maps every non-success XNNPACK status to
`InternalError`, including the numeric status and the API label when supplied.

From the repository root, build and test this directory with:

```sh
bazel build //litert/tensor/runners/xnnpack:runner
bazel test //litert/tensor/runners/xnnpack:runner_test --test_output=errors
```

[runner_test.cc](runner_test.cc) instantiates
[the shared typed suite](../common_nnpack/runner_test_suite.h), selecting
`XnnpackMixinTag`, `XnnpackRunner`, the XNNPACK external-value flags, and support
for convolution, depthwise convolution, transpose convolution, and resize tests.
The suite exercises numerical execution across arithmetic and neural-network
operations, runtime inputs, constant handling, move semantics, reshaping, and
buffer-capacity errors. Additional tests for the common runner's buffer and
lifecycle behavior live in [common_nnpack/runner_test.cc](../common_nnpack/runner_test.cc):

```sh
bazel test //litert/tensor/runners/common_nnpack:runner_test --test_output=errors
```

When extending this code, put XNNPACK runtime integration changes in this
directory, shared input/output and lifecycle changes in `common_nnpack`, and
operator lowering changes in `backends/xnnpack/arithmetic.h` and `arithmetic.cc`.
Add shared runner cases to the typed suite when they apply across backends;
put XNNPACK-specific runtime tests in this directory's `runner_test.cc`.
