/* Copyright 2025 Google LLC.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "litert/tensor/tensor.h"

#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "absl/log/absl_check.h"
#include "absl/log/absl_log.h"
#include "absl/status/status.h"
#include "absl/status/statusor.h"
#include "absl/strings/string_view.h"
#include "litert/tensor/buffer.h"
#include "litert/tensor/datatypes.h"
#include "litert/tensor/internal/graph.h"
#include "litert/tensor/utils/macros.h"
#include "litert/tensor/utils/source_location.h"

namespace litert::tensor {

TensorHandle::TensorHandle(source_location loc)
    : impl_(graph::NewTensor(std::move(loc))) {}

TensorHandle::TensorHandle(graph::Tensor impl) : impl_(impl) {}

TensorHandle::TensorHandle(TensorInit init, source_location loc)
    : TensorHandle(std::move(loc)) {
  Set(std::move(init));
}

TensorHandle TensorHandle::ShallowClone() const {
  TensorHandle handle;
  ShallowCloneTo(handle);
  return handle;
}

void TensorHandle::ShallowCloneTo(TensorHandle& other) const {
  LRT_TENSOR_ASSIGN_OR_ABORT(graph::TensorInformation & other_info,
                             GetInfo(other.impl_));
  LRT_TENSOR_ASSIGN_OR_ABORT(other_info, GetInfo(impl_));
}

TensorHandle& TensorHandle::Set(TensorInit init, source_location loc) & {
  if (!graph::GetStatus(impl_).ok()) {
    impl_ = graph::NewTensor(loc);
  }
  // We just checked that the tensor exists so we access it directly to avoid
  // triggering the absl::StatusOr linter that would force us to do a redundant
  // check.
  graph::TensorInformation& info = impl_.group->tensor_infos[impl_.index];
  info.name = std::move(init.name);
  info.type = init.type;
  info.shape = std::move(init.shape);
  std::visit(
      [&info](auto&& arg) {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, std::shared_ptr<Buffer>>) {
          info.buffer = std::forward<decltype(arg)>(arg);
        } else if constexpr (std::is_same_v<T, std::vector<float>> ||
                             std::is_same_v<T, std::vector<int32_t>> ||
                             std::is_same_v<T, std::vector<int8_t>> ||
                             std::is_same_v<T, std::vector<int4_t>>) {
          info.type = info.type == Type::kUnknown
                          ? ApiType<typename T::value_type>::value
                          : info.type;
          info.buffer = OwningCpuBuffer::CopyAs(info.type, arg);
        } else if constexpr (std::is_arithmetic_v<T>) {
          if (info.type == Type::kUnknown) {
            info.type = ApiType<T>::value;
          }
          if (const size_t size = info.GetSize(); size != 1) {
            info.buffer =
                OwningCpuBuffer::CopyAs(info.type, std::vector<T>(size, arg));
          } else {
            info.buffer = OwningCpuBuffer::CopyAs(info.type, {arg});
            if (info.shape.empty()) {
              info.shape = {1};
            }
          }
        } else {
          ABSL_LOG(ERROR) << "Failed to create buffer from typed vector: "
                             "unsupported datatype.";
        }
      },
      std::move(init.buffer));
  info.quantization = init.quantization;
  return *this;
}

TensorHandle& TensorHandle::SetName(std::string name) & {
  if (absl::Status s = graph::SetName(GetRaw(), std::move(name)); !s.ok()) {
    ABSL_LOG(ERROR) << "Error when setting tensor name: " << s;
  }
  return *this;
}

TensorHandle&& TensorHandle::SetName(std::string name) && {
  return std::move(this->SetName(std::move(name)));
}

absl::string_view TensorHandle::GetName() const {
  absl::StatusOr<const std::string&> name = graph::GetName(GetRaw());
  if (name.ok()) {
    return *name;
  }
  return "";
}

TensorHandle& TensorHandle::SetType(Type type) & {
  absl::StatusOr<graph::TensorInformation&> info = graph::GetInfo(impl_);
  if (!info.ok()) {
    ABSL_LOG(ERROR) << "Error when getting tensor info: " << info.status();
    return *this;
  }
  info->type = type;
  return *this;
}

TensorHandle&& TensorHandle::SetType(Type type) && {
  return std::move(this->SetType(type));
}

Type TensorHandle::GetType() const {
  absl::StatusOr<const graph::TensorInformation&> info = graph::GetInfo(impl_);
  if (!info.ok()) {
    ABSL_LOG(ERROR) << "Error when getting tensor info: " << info.status();
    return Type::kUnknown;
  }
  return info->type;
}

TensorHandle& TensorHandle::SetQuantization(
    std::shared_ptr<Quantization> quantization) & {
  absl::StatusOr<graph::TensorInformation&> info = graph::GetInfo(impl_);
  if (!info.ok()) {
    ABSL_LOG(ERROR) << "Error when getting tensor info: " << info.status();
    return *this;
  }
  info->quantization = std::move(quantization);
  return *this;
}

TensorHandle&& TensorHandle::SetQuantization(
    std::shared_ptr<Quantization> quantization) && {
  return std::move(this->SetQuantization(std::move(quantization)));
}

std::shared_ptr<const Quantization> TensorHandle::GetQuantization() const {
  absl::StatusOr<const graph::TensorInformation&> info = graph::GetInfo(impl_);
  if (!info.ok()) {
    ABSL_LOG(ERROR) << "Error when getting tensor info: " << info.status();
    return nullptr;
  }
  return info->quantization;
}

std::shared_ptr<Quantization> TensorHandle::GetQuantization() {
  absl::StatusOr<graph::TensorInformation&> info = graph::GetInfo(impl_);
  if (!info.ok()) {
    ABSL_LOG(ERROR) << "Error when getting tensor info: " << info.status();
    return nullptr;
  }
  return info->quantization;
}

TensorHandle& TensorHandle::SetBuffer(std::shared_ptr<Buffer> buffer) & {
  if (absl::Status s = graph::SetBuffer(GetRaw(), std::move(buffer)); !s.ok()) {
    ABSL_LOG(ERROR) << "Error when setting tensor buffer: " << s;
  }
  return *this;
}

TensorHandle&& TensorHandle::SetBuffer(std::shared_ptr<Buffer> buffer) && {
  return std::move(this->SetBuffer(std::move(buffer)));
}

absl::StatusOr<Buffer&> TensorHandle::GetBuffer() const {
  // graph::GetBuffer expects a non-const graph::Tensor&, but GetRaw() returns
  // a const graph::Tensor& in this const method. Using const_cast to
  // temporarily remove the const qualifier. The underlying graph::GetBuffer
  // should ideally be updated to accept const graph::Tensor&.
  return graph::GetBuffer(const_cast<graph::Tensor&>(GetRaw()));
}

std::shared_ptr<Buffer> TensorHandle::GetBufferPtr() const {
  absl::StatusOr<const graph::TensorInformation&> info =
      graph::GetInfo(GetRaw());
  if (!info.ok()) {
    ABSL_LOG(ERROR) << "Error when getting tensor info: " << info.status();
    return nullptr;
  }
  return info->buffer;
}

TensorHandle& TensorHandle::SetShape(Shape shape) & {
  absl::StatusOr<graph::TensorInformation&> info = graph::GetInfo(GetRaw());
  if (!info.ok()) {
    ABSL_LOG(ERROR) << "Error when setting tensor shape: " << info.status();
  }
  info->shape = std::move(shape);
  return *this;
}

TensorHandle&& TensorHandle::SetShape(Shape shape) && {
  return std::move(this->SetShape(std::move(shape)));
}

// Gets the tensor type.
const Shape& TensorHandle::GetShape() const {
  absl::StatusOr<const graph::TensorInformation&> info =
      graph::GetInfo(GetRaw());
  ABSL_CHECK(info.ok()) << "Error when getting tensor shape: " << info.status();
  return info->shape;
}

absl::Status TensorHandle::GetStatus() const {
  return graph::GetStatus(GetRaw());
}

}  // namespace litert::tensor
