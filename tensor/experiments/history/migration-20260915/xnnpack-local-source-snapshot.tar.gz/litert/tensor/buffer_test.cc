/* Copyright 2025 Google LLC.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "litert/tensor/buffer.h"

#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <iterator>
#include <list>
#include <memory>
#include <type_traits>
#include <utility>
#include <vector>

#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include "absl/algorithm/container.h"
#include "litert/tensor/datatypes.h"
#include "litert/tensor/internal/matchers.h"
#include "litert/tensor/internal/type_id.h"
#include "litert/tensor/utils/matchers.h"

namespace litert::tensor {
namespace {

using ::litert::tensor::IsOk;
using ::testing::Address;
using ::testing::Contains;
using ::testing::Each;
using ::testing::ElementsAre;
using ::testing::ElementsAreArray;
using ::testing::Eq;
using ::testing::Not;
using ::testing::NotNull;
using ::testing::Pointer;
using ::testing::ResultOf;
using ::testing::SizeIs;
using ::testing::litert::AlignmentIs;

// Helps building a `LockedBufferSpan` with side effects.
struct Lockable {
  static constexpr int kData[] = {1, 2, 3, 4};
  int i = 0;
  LockedBufferSpan<std::byte> LockMutable() {
    ++i;
    return LockedBufferSpan<std::byte>(
        reinterpret_cast<std::byte*>(const_cast<int*>(kData)),
        [this](std::byte*) { --i; }, sizeof(kData));
  }
};

TEST(LockedBufferSpanTest, ManagesLocking) {
  Lockable l;
  ASSERT_EQ(l.i, 0);
  {
    LockedBufferSpan<std::byte> span = l.LockMutable();
    ASSERT_EQ(l.i, 1);
  }
  ASSERT_EQ(l.i, 0);
}

TEST(LockedBufferSpanTest, CanBeCastAndUsedAsAContainer) {
  Lockable l;
  LockedBufferSpan<int> span = l.LockMutable().As<int>();
  EXPECT_THAT(span, ElementsAreArray(Lockable::kData));
  EXPECT_THAT(span, SizeIs(std::size(Lockable::kData)));
  EXPECT_THAT(const_cast<const LockedBufferSpan<int>&>(span),
              ElementsAreArray(Lockable::kData));
  EXPECT_THAT(const_cast<const LockedBufferSpan<int>&>(span),
              SizeIs(std::size(Lockable::kData)));
}

TEST(LockedBufferSpanTest, SharedOwnershipAcrossCopies) {
  Lockable l;
  ASSERT_EQ(l.i, 0);
  {
    LockedBufferSpan<std::byte> span1 = l.LockMutable();
    ASSERT_EQ(l.i, 1);
    {
      LockedBufferSpan<std::byte> span2 = span1;
      LockedBufferSpan<int> span3 = span1.As<int>();
      ASSERT_EQ(l.i, 1);
    }
    ASSERT_EQ(l.i, 1);
  }
  ASSERT_EQ(l.i, 0);
}

TEST(LockedBufferSpanTest, SubSpan) {
  const int data[] = {10, 20, 30, 40, 50};
  LockedBufferSpan<const int> span(data, [](const int*) {}, std::size(data));

  LockedBufferSpan<const int> sub1 = span.SubSpan(1, 3);
  EXPECT_THAT(sub1, ElementsAre(20, 30, 40));
  EXPECT_EQ(sub1.size(), 3);

  LockedBufferSpan<const int> sub2 = span.SubSpan(2);
  EXPECT_THAT(sub2, ElementsAre(30, 40, 50));
  EXPECT_EQ(sub2.size(), 3);

  LockedBufferSpan<const int> sub_oob = span.SubSpan(10);
  EXPECT_EQ(sub_oob.size(), 0);
}

TEST(LockedBufferSpanTest, ConstructFromUniquePtr) {
  auto ptr = std::make_unique<int[]>(3);
  ptr[0] = 100;
  ptr[1] = 200;
  ptr[2] = 300;
  LockedBufferSpan<int> span(std::move(ptr), 3);
  EXPECT_THAT(span, ElementsAre(100, 200, 300));
}

TEST(SpanCpuBufferTest, BuildFromRawData) {
  const int32_t backing_array[] = {1, 2, 3, 4, 5};
  SpanCpuBuffer bv(
      reinterpret_cast<std::byte*>(const_cast<int32_t*>(backing_array)),
      sizeof(backing_array));
  LockedBufferSpan<const int32_t> data = bv.Lock().As<const int32_t>();
  EXPECT_THAT(data, ElementsAreArray(backing_array));
}

TEST(SpanCpuBufferTest, BuildFromCArray) {
  const int32_t backing_array[] = {1, 2, 3, 4, 5};
  SpanCpuBuffer buffer(backing_array);
  LockedBufferSpan<const int32_t> data = buffer.Lock().As<const int32_t>();
  EXPECT_THAT(data, ElementsAreArray(backing_array));
}

TEST(OwningCpuBuffer, IsAlignedWorks) {
  const char data[kCpuBufferAlignment] = {};
  ASSERT_THAT(data,
              Contains(Address(AlignmentIs(kCpuBufferAlignment))).Times(1));

  for (size_t i = 0; i < kCpuBufferAlignment; ++i) {
    EXPECT_EQ(OwningCpuBuffer::IsAligned(data + i),
              testing::Value(data + i, AlignmentIs(kCpuBufferAlignment)));
  }
}

TEST(OwningCpuBuffer, AlignedAllocationIsAligned) {
  // We allocate severals blocks to avoid an allocation that would be
  // aligned by chance. We keep them around to avoid the system reusing a block
  // that was just freed.
  std::vector<OwningCpuBuffer::CustomAllocPtr> allocations;
  for (size_t i = 0; i < 100; ++i) {
    allocations.push_back(
        OwningCpuBuffer::AlignedAlloc(kCpuBufferAlignment + 1));
  }
  EXPECT_THAT(allocations, Each(AlignmentIs(kCpuBufferAlignment)));
  EXPECT_THAT(allocations,
              Each(Pointer(ResultOf(&OwningCpuBuffer::IsAligned, Eq(true)))));
}

TEST(OwningCpuBuffer, TransferOwnershipFromRawData) {
  const int32_t reference_data[] = {1, 2, 3, 4, 5};
  OwningCpuBuffer::CustomAllocPtr data =
      OwningCpuBuffer::AlignedAlloc(sizeof(reference_data));
  absl::c_copy(reference_data, reinterpret_cast<int32_t*>(data.get()));

  LRT_TENSOR_ASSERT_OK_AND_ASSIGN(
      std::shared_ptr<OwningCpuBuffer> buffer,
      OwningCpuBuffer::Own(std::move(data),
                           std::size(reference_data) * sizeof(int32_t)));

  ASSERT_THAT(buffer, NotNull());
  ASSERT_THAT(buffer->LockMutable().As<int32_t>(),
              ElementsAreArray(reference_data));
}

TEST(OwningCpuBuffer, TransferOwnershipFromRawDataFailsIfMisaligned) {
  // We create a purposefully misaligned pointer.
  std::byte* raw_data = new std::byte[2];
  OwningCpuBuffer::CustomAllocPtr data(
      OwningCpuBuffer::IsAligned(raw_data) ? raw_data + 1 : raw_data,
      [](std::byte* p) {
        if (OwningCpuBuffer::IsAligned(p - 1)) {
          p = p - 1;
        }
        delete[] p;
      });
  EXPECT_THAT(OwningCpuBuffer::Own(std::move(data), 2), Not(IsOk()));
}

TEST(OwningCpuBuffer, CopyFromRawData) {
  const int32_t reference_data[] = {1, 2, 3, 4, 5};

  std::shared_ptr<OwningCpuBuffer> buffer = OwningCpuBuffer::Copy(
      reinterpret_cast<const char*>(reference_data), sizeof(reference_data));
  ASSERT_THAT(buffer, NotNull());
  ASSERT_THAT(buffer->LockMutable().As<int32_t>(),
              ElementsAreArray(reference_data));
}

TEST(OwningCpuBuffer, CopyFromSequence) {
  const std::list<int32_t> reference_data{1, 2, 3, 4, 5};

  std::shared_ptr<OwningCpuBuffer> buffer =
      OwningCpuBuffer::Copy<Type::kI32>(reference_data);
  ASSERT_THAT(buffer, NotNull());
  ASSERT_THAT(buffer->LockMutable().As<int32_t>(),
              ElementsAreArray(reference_data));
}

TEST(OwningCpuBuffer, CopyFromInitializerList) {
  std::initializer_list<float> reference_data{1, 2, 3, 4, 5};

  std::shared_ptr<OwningCpuBuffer> buffer =
      OwningCpuBuffer::Copy<Type::kFP32>(reference_data);
  ASSERT_THAT(buffer, NotNull());
  ASSERT_THAT(buffer->LockMutable().As<float>(),
              ElementsAreArray(reference_data));
}

TEST(OwningCpuBuffer, CopyToBF16) {
  std::initializer_list<int> reference_data{1, 2, 3, 4, 5};

  std::shared_ptr<OwningCpuBuffer> buffer =
      OwningCpuBuffer::Copy<Type::kBF16>(reference_data);
  ASSERT_THAT(buffer, NotNull());
  ASSERT_THAT(buffer->LockMutable().As<bf16_t>(),
              ElementsAreArray(reference_data));
}

TEST(OwningCpuBuffer, CopyFromBF16) {
  std::initializer_list<bf16_t> reference_data{1, 2, 3, 4, 5};

  std::shared_ptr<OwningCpuBuffer> buffer =
      OwningCpuBuffer::Copy<Type::kI32>(reference_data);
  ASSERT_THAT(buffer, NotNull());
  ASSERT_THAT(buffer->LockMutable().As<int>(),
              ElementsAreArray(reference_data));
}

TEST(BufferTest, GetTypeId) {
  const int32_t backing_array[] = {1, 2, 3, 4, 5};
  SpanCpuBuffer span_buffer(backing_array);
  EXPECT_EQ(span_buffer.GetTypeId(), internal::TypeId::Get<SpanCpuBuffer>());

  int32_t mutable_array[] = {1, 2, 3, 4, 5};
  MutableSpanCpuBuffer mutable_span_buffer(mutable_array);
  EXPECT_EQ(mutable_span_buffer.GetTypeId(),
            internal::TypeId::Get<MutableSpanCpuBuffer>());

  auto owning_buffer = OwningCpuBuffer::Copy(
      reinterpret_cast<const char*>(backing_array), sizeof(backing_array));
  EXPECT_EQ(owning_buffer->GetTypeId(),
            internal::TypeId::Get<OwningCpuBuffer>());
}

TEST(BufferTest, IsA) {
  const int32_t backing_array[] = {1, 2, 3, 4, 5};
  SpanCpuBuffer span_buffer(backing_array);
  EXPECT_TRUE(span_buffer.IsA(internal::TypeId::Get<SpanCpuBuffer>()));
  EXPECT_FALSE(span_buffer.IsA(internal::TypeId::Get<MutableSpanCpuBuffer>()));
  EXPECT_FALSE(span_buffer.IsA(internal::TypeId::Get<OwningCpuBuffer>()));

  int32_t mutable_array[] = {1, 2, 3, 4, 5};
  MutableSpanCpuBuffer mutable_span_buffer(mutable_array);
  EXPECT_TRUE(
      mutable_span_buffer.IsA(internal::TypeId::Get<MutableSpanCpuBuffer>()));
  EXPECT_TRUE(mutable_span_buffer.IsA(internal::TypeId::Get<SpanCpuBuffer>()));
  EXPECT_FALSE(
      mutable_span_buffer.IsA(internal::TypeId::Get<OwningCpuBuffer>()));

  auto owning_buffer = OwningCpuBuffer::Copy(
      reinterpret_cast<const char*>(backing_array), sizeof(backing_array));
  EXPECT_TRUE(owning_buffer->IsA(internal::TypeId::Get<OwningCpuBuffer>()));
  EXPECT_FALSE(owning_buffer->IsA(internal::TypeId::Get<SpanCpuBuffer>()));
  EXPECT_FALSE(
      owning_buffer->IsA(internal::TypeId::Get<MutableSpanCpuBuffer>()));
}

TEST(BufferTest, As) {
  const int32_t backing_array[] = {1, 2, 3, 4, 5};
  SpanCpuBuffer span_buffer(backing_array);
  Buffer& buffer_ref = span_buffer;

  LRT_TENSOR_ASSERT_OK_AND_ASSIGN(SpanCpuBuffer & span_buffer_as,
                                  buffer_ref.As<SpanCpuBuffer>());
  EXPECT_EQ(&span_buffer_as, &span_buffer);
  EXPECT_THAT(buffer_ref.As<MutableSpanCpuBuffer>(), Not(IsOk()));
  EXPECT_THAT(buffer_ref.As<OwningCpuBuffer>(), Not(IsOk()));

  const Buffer& const_buffer_ref = span_buffer;
  LRT_TENSOR_ASSERT_OK_AND_ASSIGN(const SpanCpuBuffer& const_span_buffer_as,
                                  const_buffer_ref.As<SpanCpuBuffer>());
  EXPECT_EQ(&const_span_buffer_as, &span_buffer);
  EXPECT_THAT(const_buffer_ref.As<MutableSpanCpuBuffer>(), Not(IsOk()));
  EXPECT_THAT(const_buffer_ref.As<OwningCpuBuffer>(), Not(IsOk()));

  int32_t mutable_array[] = {1, 2, 3, 4, 5};
  MutableSpanCpuBuffer mutable_span_buffer(mutable_array);
  Buffer& mutable_buffer_ref = mutable_span_buffer;

  LRT_TENSOR_ASSERT_OK_AND_ASSIGN(
      MutableSpanCpuBuffer & mutable_span_buffer_as,
      mutable_buffer_ref.As<MutableSpanCpuBuffer>());
  EXPECT_EQ(&mutable_span_buffer_as, &mutable_span_buffer);
  EXPECT_THAT(mutable_buffer_ref.As<SpanCpuBuffer>(), IsOk());
  EXPECT_THAT(mutable_buffer_ref.As<OwningCpuBuffer>(), Not(IsOk()));
}

TEST(LockedBufferSpanTest, GettersCannotBeCalledFromTemporaryValues) {
  auto call_data =
      [](auto&& obj) -> decltype(std::forward<decltype(obj)>(obj).data()) {};
  static_assert(
      std::is_invocable_v<decltype(call_data), LockedBufferSpan<std::byte>&>);
  static_assert(
      !std::is_invocable_v<decltype(call_data), LockedBufferSpan<std::byte>&&>);
  static_assert(!std::is_invocable_v<decltype(call_data),
                                     const LockedBufferSpan<std::byte>&&>);

  auto call_begin =
      [](auto&& obj) -> decltype(std::forward<decltype(obj)>(obj).begin()) {};
  static_assert(
      std::is_invocable_v<decltype(call_begin), LockedBufferSpan<std::byte>&>);
  static_assert(!std::is_invocable_v<decltype(call_begin),
                                     LockedBufferSpan<std::byte>&&>);
  static_assert(!std::is_invocable_v<decltype(call_begin),
                                     const LockedBufferSpan<std::byte>&&>);

  auto call_end =
      [](auto&& obj) -> decltype(std::forward<decltype(obj)>(obj).end()) {};
  static_assert(
      std::is_invocable_v<decltype(call_end), LockedBufferSpan<std::byte>&>);
  static_assert(
      !std::is_invocable_v<decltype(call_end), LockedBufferSpan<std::byte>&&>);
  static_assert(!std::is_invocable_v<decltype(call_end),
                                     const LockedBufferSpan<std::byte>&&>);

  SUCCEED();
}

TEST(ByteSizeTest, SpanCpuBufferReportsTheViewedSize) {
  const std::vector<float> data = {1.f, 2.f, 3.f, 4.f};
  SpanCpuBuffer buffer(reinterpret_cast<const std::byte*>(data.data()),
                       data.size() * sizeof(float));
  EXPECT_THAT(buffer.ByteSize(), IsOkAndHolds(data.size() * sizeof(float)));
  EXPECT_THAT(buffer.ByteSize(), IsOkAndHolds(buffer.Lock().size()));
}

TEST(ByteSizeTest, MutableSpanCpuBufferReportsTheViewedSize) {
  std::vector<float> data = {1.f, 2.f, 3.f, 4.f};
  MutableSpanCpuBuffer buffer(reinterpret_cast<std::byte*>(data.data()),
                              data.size() * sizeof(float));
  EXPECT_THAT(buffer.ByteSize(), IsOkAndHolds(data.size() * sizeof(float)));
  EXPECT_THAT(buffer.ByteSize(), IsOkAndHolds(buffer.Lock().size()));
  EXPECT_THAT(buffer.ByteSize(), IsOkAndHolds(buffer.LockMutable().size()));
}

TEST(ByteSizeTest, OwningCpuBufferReportsTheAllocatedSize) {
  constexpr size_t kAllocCount = 4;
  const std::shared_ptr<OwningCpuBuffer> buffer =
      OwningCpuBuffer::Allocate<Type::kFP32>(kAllocCount);
  EXPECT_THAT(buffer->ByteSize(), IsOkAndHolds(kAllocCount * sizeof(float)));
  EXPECT_THAT(buffer->ByteSize(), IsOkAndHolds(buffer->Lock().size()));
  EXPECT_THAT(buffer->ByteSize(), IsOkAndHolds(buffer->LockMutable().size()));
}

TEST(ByteSizeTest, IsReachableThroughTheBaseInterface) {
  constexpr size_t kAllocCount = 4;
  const std::shared_ptr<Buffer> buffer =
      OwningCpuBuffer::Allocate<Type::kFP32>(kAllocCount);
  EXPECT_THAT(buffer->ByteSize(), IsOkAndHolds(kAllocCount * sizeof(float)));
}

TEST(ByteSizeTest, AnEmptyBufferReportsZero) {
  const SpanCpuBuffer buffer;
  EXPECT_THAT(buffer.ByteSize(), IsOkAndHolds(size_t{0}));
}

}  // namespace
}  // namespace litert::tensor
