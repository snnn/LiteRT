# LiteRT tensor expressions

This tree provides a C++ API for constructing tensor expression graphs and
lowering them into executable backends. Most public types and functions live
in `litert::tensor`. An expression such as `Add(input, bias)` records an
operation, connects its inputs and outputs, and infers metadata. A backend
converts the selected output graph, and a runner binds data and executes it.
The concrete backend and runner present in this checkout use XNNPACK on CPU.

For the local Gemma4 work, see
[Native runner improvements](NATIVE_RUNNER_IMPROVEMENTS.md). It summarizes the
changes built on LiteRT and this checkout, their source locations, and the
recorded correctness, performance, and memory results.

Start with [tensor.h](tensor.h) and [arithmetic.h](arithmetic.h) to construct
expressions. For execution, follow the
[XNNPACK runner example](runners/xnnpack/README.md#example). For changes to the
graph representation or operation construction, start with
[the internal architecture](internal/README.md).

## Directory map

| Directory | Responsibility |
| --- | --- |
| [internal](internal/README.md) | Graph objects and ownership, operation-construction helpers, backend extension registration, broadcasting, traversal, probing, diagnostics, and a compile-wrapper prototype. |
| [backends](backends/README.md) | Shared graph-conversion infrastructure, XNNPACK operation lowering and value definitions, and a reusable numerical test framework. |
| [runners](runners/README.md) | Shared runtime preparation and input/output handling, the XNNPACK runtime adapter, and runner tests. |
| [utils](utils/README.md) | Error propagation and extraction macros, source-location capture, and test assertions/matchers. |
| [examples](examples/README.md) | Optional local Gemma4 E2B/E4B CPU example, mobile checkpoint loading, and model-level numerical comparison. |

The files at this level define the public tensor and storage abstractions:

| Files | Responsibility |
| --- | --- |
| [tensor.h](tensor.h), [tensor.cc](tensor.cc) | `TensorInit`, `TensorHandle`, `Tensor<Mixins...>`, creation helpers, metadata and buffer access, shallow cloning, and tensor-status conversion. |
| [arithmetic.h](arithmetic.h) | Template expression builders for elementwise operations, activations, shape changes, reductions, neural-network layers, custom operations, and composite graphs. |
| [arithmetic_graph.h](arithmetic_graph.h) | Backend-independent operation descriptors and attributes, such as axes, strides, padding, activation options, and composite decomposition boundaries. These describe operations; backend extensions supply their lowering. |
| [buffer.h](buffer.h), [buffer.cc](buffer.cc) | The abstract `Buffer` interface, locked spans, borrowed CPU views, and aligned owning CPU storage with copy, conversion, and allocation helpers. |
| [datatypes.h](datatypes.h) | Logical tensor types, native/API type mappings, packed integer storage, FP16/BF16 wrappers, byte sizing, and host-side conversion helpers. |
| [tensor_test.cc](tensor_test.cc), [arithmetic_test.cc](arithmetic_test.cc) | Tests for tensor construction, metadata, sharing, graph connectivity, inferred shapes/types, operation attributes, and multi-output graphs. |
| [buffer_test.cc](buffer_test.cc), [datatypes_test.cc](datatypes_test.cc) | Tests for buffer ownership and locks, alignment, copying, storage sizes, and packed/floating-point conversions. |
| [BUILD](BUILD) | Public tensor, arithmetic, datatype, and buffer libraries, plus their four unit-test targets. |
| [CMakeLists.txt](CMakeLists.txt) | Standalone Linux and Android test build for this entire tree, including the XNNPACK dependencies and an additional debugger-enabled test executable. |

## From an expression to execution

```mermaid
flowchart TD
    T[Tensor handles and operation builders] --> G[Expression graph and backend extensions]
    G --> P[Execution plan from requested outputs]
    P --> B[Backend build context]
    B --> S[Owned backend subgraph and constants]
    S --> R[Runner prepares runtime]
    I[Runtime input data and shapes] --> R
    R --> O[Reshape, bind buffers, invoke, read outputs]
```

1. **Construct tensors.** A `TensorHandle` refers to graph metadata: name, type,
   shape, optional buffer, and optional quantization parameters. Leaf tensors
   without attached buffers can become runtime inputs; leaf tensors with data
   can become constants during backend conversion.
2. **Build expressions.** `Tensor<Mixins...>` carries the tags used to select
   backend extensions. Public builders create operation descriptors, connect
   input and output groups, attach supported extensions, and infer output
   metadata. The common elementwise path also checks input types and broadcast
   compatibility. Multi-output operations share a producing operation and
   output group.
3. **Select outputs and lower.** `GetExecutionPlan()` visits dependencies of
   requested outputs. For XNNPACK, `BuildXnnpackGraph()` discovers external
   values, initializes the backend, and uses its build context to translate
   tensor metadata and operation extensions into XNNPACK values and nodes.
   The resulting graph owns its mappings and retained constant storage.
4. **Bind and execute.** `XnnpackRunner::Create(outputs)` performs that graph
   conversion. Its inherited `NnpackRunner` API accepts input data and prepares
   the runtime lazily. Each `Run()` propagates input shapes, obtains output
   shapes, reserves output storage, binds buffers, and invokes the runtime.
   Output access returns locked views; subsequent runs can reuse the runtime.

The expression API is broader than any one backend's implementation. Attaching
`XnnpackMixinTag` enables the available XNNPACK operation specializations when
expressions are built; graph conversion does not attach missing extensions
later. A successfully constructed expression still needs a supported lowering
and runtime configuration. Consult the
[XNNPACK backend constraints](backends/xnnpack/README.md#operation-lowering)
when selecting operators, attributes, or datatypes.

## Tensor identity, metadata, and errors

Copying a tensor handle shares the same underlying graph value. Equality
compares that identity, so two independently created tensors with identical
names and shapes are different values. Mutating metadata through one shared
handle affects the other handles to that value.

`ShallowClone()` creates a new value identity with copied metadata while
sharing the buffer and quantization objects. `ShallowCloneTo()` copies that
information into an existing destination identity. These are metadata copies;
they do not deep-copy storage or duplicate the producing operation graph.

`TensorInit` accepts a shared buffer, selected typed vectors, or supported
scalars. Vector/scalar initialization creates owning CPU storage and can infer
the element type when it is unknown. A scalar initializes the declared shape
with that value; with no shape, scalar initialization uses `{1}`. Attaching a
`shared_ptr<Buffer>` keeps that buffer object without copying its data.

Operations and invalid handles can carry an error in the underlying tensor
group. Check `GetStatus()` before consuming results, and propagate statuses
from conversion and runners. The
[status macros](utils/README.md#propagating-errors) also understand tensor
handles through the conversion specializations in `tensor.h`. Validation is
operation-specific: some builders use assertions or assume valid metadata,
so a status check is not a replacement for respecting their input contract.

Shape metadata inferred during expression construction and shapes stored in a
runner's converted graph are separate. Runtime input reshaping updates the
runner's metadata; it does not rewrite the original tensor handle's shape.
See the [shared runner's buffer and shape rules](runners/common_nnpack/README.md#inputs-outputs-and-buffer-lifetimes)
for repeated execution and dynamic input sizes.

## Buffers and element representations

| Abstraction | Data and lifetime behavior |
| --- | --- |
| `Buffer` | Reports byte size and provides read or mutable CPU access through `Lock()`/`LockMutable()`. Concrete implementations define access and ownership behavior; mutable access can return an empty span when unsupported. |
| `SpanCpuBuffer` | Borrows read-only CPU storage. Locking is a no-op and does not extend the underlying allocation's lifetime. |
| `MutableSpanCpuBuffer` | Adds writable access to borrowed CPU storage. The caller still owns the memory. |
| `OwningCpuBuffer` | Owns shared allocation storage. Its factories allocate, copy, convert, transform, or adopt memory; allocation and adoption use `kCpuBufferAlignment` (64 bytes). Its locks retain shared ownership of the allocation. |
| `LockedBufferSpan<T>` | Holds a pointer, byte extent, and shared unlock state. Copies, typed casts, and subspans share that state; the callback runs when the last related lock is released. Data ownership depends on the buffer that produced it. |

Keep borrowed memory valid while a graph or runner uses it. A shared pointer
to a viewing buffer owns the wrapper, not the viewed allocation. Locked views
are not result snapshots: an invocation can overwrite the same storage, so
copy results that must remain unchanged.

`Type` describes logical elements. `NativeStorage<Type>` maps them to storage
types, and `ApiType<T>` maps C++ types back to logical types. I4/U4 pack two
elements into a byte and I2 packs four. Use `BufferSize(type, element_count)`
for byte sizing; it rounds packed storage up to whole bytes. A typed span over
packed storage counts packed objects rather than unpacked logical elements.

`Convert()`, `ConvertTo()`, and the owning-buffer factories provide host-side
numeric conversion and packing helpers. These are distinct from a graph
`Cast`, `Quantize`, or `Dequantize` operation. Quantization parameters are shared
metadata records, including per-channel affine and blockwise forms; merely
attaching them does not convert the buffer bytes or establish backend support.

## Small expression example

This example constructs an FP32 addition graph and checks its construction
status. `input` has no data buffer, while `bias` carries a constant vector.
The graph's inferred output shape is `{2}`. Numerical execution follows the
[runner example](runners/xnnpack/README.md#example).

```cpp
#include <vector>

#include "litert/tensor/arithmetic.h"
#include "litert/tensor/backends/xnnpack/arithmetic.h"
#include "litert/tensor/datatypes.h"
#include "litert/tensor/tensor.h"

int main() {
  using namespace litert::tensor;
  using XnnTensor = Tensor<XnnpackMixinTag>;

  XnnTensor input({.name = "input", .type = Type::kFP32, .shape = {2}});
  XnnTensor bias({.name = "bias",
                 .type = Type::kFP32,
                 .shape = {2},
                 .buffer = std::vector<float>{0.5f, 0.5f}});
  XnnTensor sum = Add(input, bias);
  return sum.GetStatus().ok() ? 0 : 1;
}
```

A consumer needs the targets for its directly included public headers and
`//litert/tensor/backends/xnnpack:arithmetic` for the XNNPACK extensions. Add
`//litert/tensor/runners/xnnpack:runner` when executing through that adapter.

## Extending and testing

| Change | Starting point |
| --- | --- |
| Add an expression operation | Define its descriptor in `arithmetic_graph.h`, build and validate it in `arithmetic.h`, and test graph structure/metadata in `arithmetic_test.cc`. Add backend lowering and numerical tests for executable support. |
| Change graph ownership, traversal, or backend registration | [internal](internal/README.md). Preserve producer/output and input/consumer relationships. |
| Change backend conversion or operator execution support | [backends](backends/README.md). Separate graph bookkeeping from concrete backend API calls. |
| Change input/output binding or runtime lifecycle | [runners](runners/README.md). |
| Add a datatype or buffer implementation | Update the relevant type/storage mappings or buffer contract here, then test byte sizing, conversions, access, and lifetimes. |
| Change status propagation or testing helpers | [utils](utils/README.md). |

Root arithmetic tests validate expression construction and metadata, while
backend and runner tests check lowering and numerical execution. Passing
construction tests does not imply numerical support for every tested type or
operation. The reusable backend numerical suite can skip unsupported cases,
and the XNNPACK quantized fully connected case has an explicit skip for known
numerical issues. Inspect test skips when assessing coverage.

The compile wrapper under `internal` is prototype infrastructure with a
different backend contract from `NnpackRunner`; see its
[current behavior and limits](internal/README.md#compile-wrapper-prototype)
before using it as an execution entry point.

## Build and test

Run the following commands from the repository root. The default suite covers
tensor construction, buffers and datatypes, graph internals, backend conversion,
numerical operations, both runners, and error-handling helpers. No model files
are required; the tests construct their inputs in memory.

### Linux x86_64 with Bazel

Bazelisk and a C++17 compiler are required. These commands were verified with
Bazel 9.2.0, GCC 16.2.1, and Clang 22.1.8. Pin the Bazel version for repeatable
local runs:

```sh
export USE_BAZEL_VERSION=9.2.0

# Build all tensor libraries and test executables.
bazelisk build //litert/tensor/... --lockfile_mode=off --jobs=16

# Run all 17 test targets, without reusing cached test results.
bazelisk test //litert/tensor/... --lockfile_mode=off --jobs=16 \
  --nocache_test_results --test_output=errors

# Enable the graph debugger so its logging tests execute instead of skipping.
bazelisk test //litert/tensor/internal:op_debugger_test \
  --define=OP_DEBUGGER=true --lockfile_mode=off --jobs=16 \
  --nocache_test_results --test_output=errors

# Also check optimized code with Clang.
CC=clang CXX=clang++ bazelisk test //litert/tensor/... -c opt \
  --lockfile_mode=off --jobs=16 --nocache_test_results --test_output=errors
```

`--lockfile_mode=off` prevents these commands from updating the workspace's
Bazel module lockfile. Adjust `--jobs` to the machine's resources. Bazel writes
test logs and XML below `bazel-testlogs/litert/tensor/`. Child READMEs list
narrower targets for work on a particular component; for just the runners, use
`//litert/tensor/runners/...` instead of `//litert/tensor/...`.

### Linux x86_64 with CMake

The standalone [CMake build](CMakeLists.txt) requires CMake 3.24 or newer,
Ninja, Python 3, and a C++17 compiler. Its first configuration downloads pinned
GoogleTest, Abseil, and XNNPACK dependencies. It does not require a Bazel build
or an existing Bazel dependency cache.

```sh
cmake -S litert/tensor -B build/tensor-linux -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++
cmake --build build/tensor-linux --parallel 16
ctest --test-dir build/tensor-linux --output-on-failure

# Select only the common runner and XNNPACK runner tests.
ctest --test-dir build/tensor-linux -L runners --output-on-failure
```

With the example option left OFF, this builds all 13 core implementation files
and registers 18 CTest entries: the
17 existing test executables plus a separate debugger-enabled variant. The
ordinary graph library keeps its default behavior. Executables are under
`bin/` in the build directory; `tensor-tests.json` records their paths and
labels for the Android launcher. CTest's detailed log is
`Testing/Temporary/LastTest.log`. To inspect individual cases or save GoogleTest
XML, run a built executable with `--gtest_list_tests` or
`--gtest_output=xml:/absolute/path/results.xml`.

### Android arm64 over ADB

Set `ANDROID_HOME` to the Android SDK directory and install its platform-tools
and NDK **27.3.13750724 (r27d)**. Connect and authorize an arm64 Android device.
The commands below use API 24 as the minimum Android API level; the connected
device must run API 24 or newer. Validation used an Android 15 / API 35 phone.

Use the NDK CMake toolchain for this checkout. The legacy Bazel
`--config=android_arm64` configuration does not select an Android toolchain with
the tested Bazel version. Configuring the repository root with CMake builds
XNNPACK's targets; configure **`litert/tensor`** to include the tensor tests.

```sh
export ANDROID_NDK="$ANDROID_HOME/ndk/27.3.13750724"
"$ANDROID_HOME/platform-tools/adb" devices -l
TENSOR_SERIAL=replace-with-the-intended-device-serial

# Build and run both configurations in separate directories.
(
  set -e
  for tensor_config in Debug RelWithDebInfo; do
    tensor_build="build/tensor-android-$tensor_config"
    cmake -S litert/tensor -B "$tensor_build" -G Ninja \
      -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake" \
      -DANDROID_ABI=arm64-v8a \
      -DANDROID_PLATFORM=android-24 \
      -DANDROID_STL=c++_static \
      -DCMAKE_BUILD_TYPE="$tensor_config"
    cmake --build "$tensor_build" --parallel 16
    python3 scripts/run-litert-tensor-tests-android.py \
      --build-dir "$tensor_build" \
      --serial "$TENSOR_SERIAL" \
      --output-dir "$tensor_build-results-$(date +%Y%m%d-%H%M%S)"
  done
)
```

The [Android launcher](../../scripts/run-litert-tensor-tests-android.py) finds
ADB through `ANDROID_HOME`. Set `TENSOR_SERIAL` to the intended device before
running the commands, especially when several phones are connected. If the
serial is omitted, the launcher requires exactly one authorized device online.
Add `--filter '_runner_test$'` to select only the two runner
executables. Each invocation requires a new output directory to prevent old
results from being mistaken for a successful run.

Before deployment, the launcher verifies that every selected executable is
Android AArch64 and requires only the allowed Android system shared libraries.
The harness links project dependencies and libc++ statically. The launcher
creates a unique directory below `/data/local/tmp/litert-tensor-tests/`, sets
writable temporary directories for GoogleTest (including death tests), and
runs executables sequentially. Each executable has a 120-second timeout;
override it with `--timeout-seconds` when needed.

The local output directory contains console logs, GoogleTest XML, exit statuses,
and `summary.json` with case counts and skip reasons. A failed test, timeout,
missing or invalid result, or deployment error makes the launcher exit nonzero.
Device artifacts remain available for debugging; add `--cleanup` to remove only
that invocation's device directory after collection. Android binaries run through
this launcher rather than directly through the host's CTest.

### Interpreting results

The latest Linux and Android `RelWithDebInfo` runs each reported **652 cases:
626 passed, 26 skipped, and no failures** across 29 executables, with the Gemma4
examples enabled. These comprise 549 core cases and 103 example cases, including
the singleton-KV attention and runtime-flag regressions. Case outcomes matched
across platforms. The 26 skips consist of 24 existing numerical
limitations and the two ordinary debugger tests; the separate debugger-enabled
executable runs those two cases successfully. Earlier core-only CMake runs had
546 cases; the earlier Bazel run had 544 before its separate debugger-enabled
rerun. The new runtime-flag cases were validated with CMake on both platforms;
Bazel was not rerun for this local change.

Review skip reasons as well as exit status. In particular, a backend
initialization failure can cause numerical tests to skip, and newly skipped
cases need investigation. Numerical tests use their existing tolerances; the
suite does not require bitwise equality between x86_64 and arm64 results.

When adding tests or implementation files, update both the relevant `BUILD`
file and `CMakeLists.txt`. Keep the CMake dependency pins aligned with
`MODULE.bazel`; CTest and the Android launcher share the manifest generated from
the CMake test inventory.

### Local Gemma4 model tests

The [local examples](examples/README.md) add a Gemma4 E2B/E4B CPU driver and
synthetic graph/helper/loader tests. Enable them with
`-DLITERT_TENSOR_BUILD_GEMMA4=ON` in either CMake configuration above. They use
CMake targets in this checkout and are not part of the Bazel target wildcard.

```sh
# Add to an existing Linux tensor build, then run the example tests.
cmake -S litert/tensor -B build/tensor-linux -DLITERT_TENSOR_BUILD_GEMMA4=ON
cmake --build build/tensor-linux --parallel 16
ctest --test-dir build/tensor-linux -L gemma4 --output-on-failure
```

For Android, configure the same option with the NDK toolchain. The existing
Android test launcher discovers the additional test binaries automatically;
use `--filter 'gemma4|safetensor_loader'` to select them. These synthetic tests
need no checkpoint. Use an optimized build for actual generation.

The [Gemma4 guide](examples/gemma4/README.md) contains complete Linux/Android
build and model-run commands, links to Google's mobile quantized checkpoints,
offline Hugging Face tokenization, and an independent Transformers logit
comparison. Real model testing requires both weights and adjacent `config.json`;
copying the safetensors file alone omits the mobile quantization scheme.

Both mobile models completed a short prefill and two cached decode steps on
Linux x86_64 and the TECNO Android phone, with matching greedy tokens across
both platforms and the Python reference for that prompt. The 103 synthetic
example test cases pass on both platforms. Full-logit comparisons exceed the
current diagnostic thresholds, and a BOS-only E2B prompt produces different
tokens on Linux and Android; model numerical equivalence remains unverified.
The [BOS-only diagnosis](examples/gemma4/README.md#bos-only-e2b-across-platforms)
traces that mismatch to FP32 rounding crossing a static INT8 boundary in layer
29; the affected FC kernels agree across platforms for identical inputs.
The [earliest FP32 difference](examples/gemma4/README.md#first-fp32-difference-reciprocal-square-root)
is one ULP in layer 0's reciprocal square root: the selected AVX and arm64
kernels use different arithmetic algorithms, and both results are reproducible
on the same Linux CPU.
E2B now uses implicit matrix-multiplication broadcasting for its single KV
head. The driver supports
[`--consistent_arithmetic`](examples/gemma4/README.md#e2b-consistent-arithmetic-diagnostics)
for both prefill and decode; the flag is disabled by default and recorded in
each result manifest. Four-prompt checks confirm that default-mode logits and
all dumped intermediate values are bitwise unchanged by the broadcast fix on
both platforms. The mode is a diagnostic tool, not a guarantee of model parity
or cross-platform equality. Across ten generated positions from four prompts,
strict reference-logit checks pass only the Linux BOS position in either mode;
the TECNO BOS token mismatch remains. The broadcast fix enables the comparison
but does not resolve the remaining numerical differences.
Further [full-model arithmetic controls](examples/gemma4/README.md#e2b-full-model-arithmetic-controls)
replayed all 277 active E2B linear operations with identical inputs and obtained
bitwise-identical Linux/TECNO outputs in both prefill and cached decode.
A separate diagnostic that removes
activation quantization on both sides passes all ten logit comparisons and
tracks all 35 layers closely on both platforms, including cached decode.
This supports the graph's underlying arithmetic, but changes the diagnostic
model; the original mobile checkpoint's strict failures remain unresolved.
A [sliding-window boundary check](examples/gemma4/README.md#e2b-sliding-window-boundary-control)
also passes the diagnostic model's logit checks through positions 511–513.
Cache append checks pass with and without activation quantization; original
quantized-model logits still differ, including one Linux prediction.
See the guide's [validation results](examples/gemma4/README.md#validation-results)
for the tested snapshots, case counts, and measured differences.

### Comparing against LiteRT-LM CPU

To evaluate this example as a replacement, compare it directly with LiteRT-LM's
CPU executor on the same machine or phone. Use identical raw prompt IDs and
teacher-forced continuation IDs, with matching thread counts and affinity.
Cross-platform agreement and comparison with the Transformers reference are
supporting diagnostics; they do not establish replacement quality or speed.

Correctness captures and performance captures serve different purposes.
Linux-host performance testing remains excluded because the host runs other
workloads. The Android CPU comparison below uses separate warmed benchmark
captures; timing fields in full-logit diagnostics are not benchmark results.
For correctness, check complete finite logits,
target-token negative log likelihood, argmax decisions, and distribution
outliers. Use teacher forcing so a different prediction does not change the
subsequent history. Check both prefilled and sequential histories, session reset,
and positions where the sliding attention window moves.

LiteRT-LM reserves the final prompt token for its first `DecodeLogits` call.
Compare its `Prefill` plus that call against the tensor runner's first-logit
pass. A direct executor harness must also apply the normal engine's model
metadata defaults and environment shape configuration. Setting a context limit
in executor settings alone does not configure the published model's cache
dimensions. Verify actual bound KV tensor shapes, rather than relying only on
the requested limit.

The original mobile CT example and the published LiteRT-LM bundle differ in
coefficient precision, per-layer projection quantization, KV-cache storage, CPU
head lowering, and prefill computation. Those original captures remain
unmatched diagnostics. Matching tokenizer IDs and some integer weight codes
does not resolve these differences.

A separate local adapter now imports all active weights, FP32 coefficients and
scales directly from the actual `.litertlm` bundle. It reproduces the quantized
global per-layer projection, dynamic QD8/QC2 head, and actual INT8 K/V caches:
15 owners, 30 tensors, capacity 2048, and 18,874,368 bytes per logical bank. It
quantizes current K/V before attention and uses cache-only prefill followed by
the reserved token's full decode. The original CT example in this checkout is
unchanged by this adapter work.

On Linux, a control that supplies the baseline CPU provider's RoPE values
matches LiteRT-LM bitwise across every full vocabulary logit in 2,322 corpus
predictions, 144 prefilled-tail predictions, an eight-step sequential probe, and
five predictions at positions 509–513. The corpus includes 2,304 scored targets
with identical mean negative log likelihood, 3.0012691498192803; the remaining
18 final predictions are compared without target scores. Tail cases reuse the
same passages with a different prefill schedule. The current XNNPACK cosine
implementation differs from the baseline's historical version, and the native
graph without this RoPE control still produces numerical differences.

On TECNO, matching provider RoPE and attention matrix row layout narrows the
differences. An additional isolated control that disables only XNNPACK's
dequantize/BMM fusion matches LiteRT-LM bitwise on all eight sequential
predictions, all 144 prefilled-tail predictions, and all five predictions at
positions 509–513. Every comparison covers all 262,144 FP32 logits. Both
runners retain the actual INT8 KV cache and all activation quantization.

Operator traces show that the tested historical Android baseline materializes
FP32 cache values before FP32 BMM; current XNNPACK fuses that conversion into
FP32/QCINT8 BMM. Its small FP32 differences can cross a later activation
quantization threshold and produce larger output differences. This is evidence
of different attention arithmetic, with no demonstrated difference in the
quantizer's rounding rule. The baseline's compiled optimizer does not invoke
the fusion pass. These findings concern the recorded builds, not every version
of LiteRT-LM.

The controls provide strong evidence for the re-authored graph on the tested
histories. The separate executable with fusion disabled is a diagnostic;
repository source and the fused candidate remain unchanged by that control.
Fusion avoids materializing the FP32 cache temporary and remains a candidate
for improving decode speed. Those diagnostic captures did not measure its
speed or end-to-end model quality; bitwise agreement with historical arithmetic is not itself a
production requirement. No performance conclusion follows from those captures.

A subsequent isolated LiteRT-LM Android rebuild applies
[LiteRT PR #9918](https://github.com/google-ai-edge/LiteRT/pull/9918), including
the matching TensorFlow dependency update in LiteRT-LM's own WORKSPACE. The
rebuilt baseline actually uses FP32/QCINT8 attention: all 280 BMMs observed
over four traced steps have those operand types, and tracing preserves every
sequential logit vector. It matches the native adapter **with fusion enabled
and matching attention windows** bitwise on all eight sequential, 144
prefilled-tail, and five window-boundary predictions. Each comparison covers
all 262,144 logits; KL and RMSE are zero. This provides correctness evidence
for the matched-bundle window variant while retaining the optimization.

Use that window variant consistently: its head-major rows and local attention
widths match the bundle, while persistent INT8 cache capacity stays 2048.
The separate full-width headfold control still differs on prefilled tails.
The fresh build includes other changes since the historical baseline; PR #9918
did not originally introduce this fusion. Sources, build instructions, exact
revisions and results for the update are retained under
`/data/bt/tmp/gemma4-pr9918/README.md`. The later Android performance evaluation
and its additional numerical qualification are described below.

The local comparison sources, commands, model audit, full-logit captures and
results are retained outside this checkout under
`/tmp/gemma4-local-port-nggiqf9x/replacement-comparison/`. Its `CORRECTNESS.md`
contains the current results, exact capture commands, invalidated diagnostics,
and remaining limitations. `REPORT.md` retains the earlier unmatched campaign.
The earlier baselines use documented historical cached LiteRT-LM builds;
the PR #9918 results use the separate fresh Android build above. These local
artifacts are separate from the
portable CMake/CTest instructions above; no LiteRT-LM replacement acceptance is
implied by the synthetic tests.

### Historical Android CPU performance: frozen native adapter

The local evaluation in
[/data/bt/tmp/gemma4-phone-perf-20260913/README.md](/data/bt/tmp/gemma4-phone-perf-20260913/README.md)
compares the frozen matched-window native adapter with the fresh LiteRT-LM CPU
build above on **TECNO LJ9 and Pixel 8**. These are the measurements before the
live-KV changes documented in the follow-up below. Samsung/S25 and Linux-host model
benchmarks were excluded. The ten-cell main matrix completed 40 process blocks,
120 measured sessions and 7,680 measured decode calls.

Each cell uses identical raw prompt/forced token IDs, thread counts and CPU
affinity for both runners. Four process blocks run in LiteRT-LM, native, native,
LiteRT-LM order. Each has one warmup and three measured sessions, 64 forced decode
calls per session, reused runtimes and no full-logit dumps. The two-thread masks
are TECNO `c0` and Pixel `180`; four-thread masks are TECNO `f0` and Pixel `1e0`.
Temperatures, thermal status, memory and sampled process fault counters are
retained. Clocks and governors were not fixed.

The table reports medians over six measured sessions per backend. Decode uses
inclusive `elapsed_ms`; the adapters' `forward_ms` fields have different scopes.
First-logit time includes logical-session initialization, prefix prefill and the
reserved last token's decode, excluding model loading and runtime construction.
These are runner measurements without tokenization, sampling or rendering.

| Phone | Threads | Prompt tokens | LiteRT-LM decode (tok/s) | Native decode (tok/s) | First logits, LM / native (s) |
| --- | ---: | ---: | ---: | ---: | ---: |
| TECNO LJ9 | 2 | 128 | 11.98 | 8.55 | 1.231 / 1.014 |
| TECNO LJ9 | 2 | 1024 | 12.14 | 8.57 | 11.942 / 10.767 |
| TECNO LJ9 | 4 | 128 | 19.60 | 17.78 | 0.652 / 0.550 |
| TECNO LJ9 | 4 | 1024 | 19.56 | 17.68 | 5.727 / 5.014 |
| Pixel 8 | 2 | 128 | 12.85 | 11.63 | 1.482 / 0.950 |
| Pixel 8 | 2 | 1024 | 13.51 | 11.68 | 10.281 / 8.293 |
| Pixel 8 | 4 | 128 | 17.08 | 15.61 | 0.939 / 0.656 |
| Pixel 8 | 4 | 1024 | 16.79 | 15.55 | 7.763 / 5.224 |

The frozen native adapter in that campaign has lower median decode throughput
in every main cell. First logits arrive sooner at the primary prompt lengths.
At 512 tokens, that adapter pads prefill to 1024 rows, while LiteRT-LM schedules four 128-row
chunks: first logits take 10.87 versus 4.64 seconds on TECNO and 8.32 versus
5.31 seconds on Pixel 8 (native versus LiteRT-LM, two threads).

See the [complete results and session ranges](/data/bt/tmp/gemma4-phone-perf-20260913/analysis/results/SUMMARY.md)
and [throughput chart](/data/bt/tmp/gemma4-phone-perf-20260913/analysis/results/decode-throughput.svg).
Pixel has more variation between and within process blocks, so small differences
need that context. A separate [cooled Pixel short-prompt repeat](/data/bt/tmp/gemma4-phone-perf-20260913/cooled-pixel128t2-v1/README.md)
measured 12.85 versus 11.64 tok/s (LiteRT-LM versus native), with all four
blocks starting at 35°C CPU temperature. It confirms the direction while
preserving the original main matrix.

This is a comparison of complete local adapters. Both retain INT8 KV at capacity
2048, but native uses two banks and local windows while LiteRT-LM uses one
in-place bank. The [source audit](/data/bt/tmp/gemma4-phone-perf-20260913/SOURCE_COST_REVIEW.md)
also confirms that 60 native MLP matrices retain widened QCINT4 weights where
the baseline supports their original QCINT2 representation. This adds 270 MiB
of weight-code payload before packing metadata. The values and scales are
preserved; runtime packing and work are not identical. The native head already
restores QCINT2. Preserving static MLP QCINT2, improving cache updates, and
supporting smaller prefill chunks are concrete optimization candidates; no
profile has assigned a fraction of the measured gap to each.

The longer continuation in that campaign added a **correctness qualification**
to the previous checks. Both phones showed the same repeat-stable argmax mismatch at
position 536 in the 512-token case. A separate TECNO full-logit follow-up finds
63/65 vectors bitwise equal; positions 520 and 536 differ, with maximum KL
0.0172883 and maximum RMSE 0.665209. Position 536 selects token 1024 in LiteRT-LM
and 872 in native. Subsequent vectors match again. The earlier short gates and
157-vector campaign remain valid for their tested histories, but do not establish
unconditional numerical equivalence. The [follow-up comparison](/data/bt/tmp/gemma4-phone-perf-20260913/tecno/followup512/comparison.json)
records full metrics. Its cause was unresolved at that stage; differing prefill
scheduling and weight lowering were not established explanations. The follow-up
below records the subsequent traced arithmetic differences and v4 results.
These historical timing comparisons remain on identical forced histories.

To reproduce captures, use the experiment guide's retained binaries, verified
model/export, raw-ID fixtures, gate/finalization commands and benchmark drivers
in a **new capture namespace**. `ANDROID_HOME` supplies the SDK; every command
selects an authorized serial. Existing capture files are preserved by the
drivers. Re-analyzing the completed main matrix requires no device or inference:

```sh
python3 /data/bt/tmp/gemma4-phone-perf-20260913/analysis/summarize.py

# Generate the standalone charts with an isolated plotting dependency.
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  uv run --no-project --with matplotlib python \
  /data/bt/tmp/gemma4-phone-perf-20260913/analysis/summarize.py --chart
```

Both analysis commands completed successfully. The numerical diagnostics are
excluded from benchmark aggregation. These local comparison tools supplement
the portable CMake/CTest instructions above; they are not checked-in runner APIs.

### Follow-up: live INT8 KV cache and chunked prefill

The subsequent [local Gemma4 E2B experiment](/data/bt/tmp/gemma4-live-kv-20260913/README.md)
replaces the frozen native adapter's alternating cache banks with one persistent
INT8 bank. Both K and V use `[capacity, head_dim]` storage per distinct KV owner.
Execution stages append only the new rows before their attention consumers run;
shared layers borrow their owner's cache. Attention borrows contiguous views of
the live prefix or local window, rounded to 32-position boundaries with the
extra positions masked. This removes the adapter's full-bank update algebra and
local-window gathers. XNNPACK still copies/adapts and packs active INT8 operands
internally.

Prefill now appends reusable 128-row chunks with absolute RoPE positions and
causal masks. Only a final partial chunk pads token rows, so a 512-token prompt
no longer requires a 1024-row prefill signature. Allocation capacity remains
2048 and is independent of the attention operand extent. The single logical KV
bank uses 18 MiB plus per-allocation overread padding.

The frozen v4 Android binary matches **199/199 full-logit vectors bitwise**
against same-phone LiteRT-LM CPU references in the
[final correctness report](/data/bt/tmp/gemma4-live-kv-20260913/FINAL_CORRECTNESS.json).
Coverage includes two- and four-thread gates on TECNO LJ9 and Pixel 8, 512-token
prompts followed by 64 forced decode calls, and histories reaching capacity
2048. The earlier frozen-native differences at positions 520 and 536 are absent
in the tested v4 continuations on both phones. Each phone also passed 323
cache-manager checks and completed 2,584 numerical extent comparisons; those
extent diagnostics include expected shape-dependent rounding differences.
These are empirical results for the recorded histories, not a guarantee of
universal bitwise equivalence or a model-quality evaluation.

The [final-build Linux smoke](/data/bt/tmp/gemma4-live-kv-20260913/linux-final-smoke-comparison.json)
also matches three full-logit vectors against the frozen native adapter. This
is a correctness smoke check, with its timing fields excluded from performance
claims.

The completed [phone performance matrix](/data/bt/tmp/gemma4-live-kv-20260913/analysis/results/SUMMARY.md)
compares v4 with the same LiteRT-LM CPU binary using matched histories, affinity,
and thread counts. It contains 40 process blocks, 120 measured sessions, and
7,680 measured decode calls. Each cell has LiteRT-LM, v4, v4, LiteRT-LM blocks;
each process has one warmup and three measured sessions with 64 forced decode
calls, reused runtimes, and no full-logit dumps. Values below are medians of six
sessions per backend, using inclusive decode `elapsed_ms`. First-logit time
includes session initialization, prefill, and the reserved last token's decode;
it excludes loading, compilation, tokenization, and sampling.

| Phone | Threads | Prompt tokens | LiteRT-LM decode (tok/s) | Native v4 decode (tok/s) | First logits, LM / v4 (s) |
| --- | ---: | ---: | ---: | ---: | ---: |
| TECNO LJ9 | 2 | 128 | 11.95 | 16.66 | 1.237 / 0.875 |
| TECNO LJ9 | 2 | 512 | 12.07 | 13.51 | 4.702 / 3.580 |
| TECNO LJ9 | 2 | 1024 | 12.07 | 12.72 | 12.148 / 7.861 |
| TECNO LJ9 | 4 | 128 | 19.44 | 22.67 | 0.665 / 0.379 |
| TECNO LJ9 | 4 | 1024 | 19.30 | 20.12 | 5.880 / 3.337 |
| Pixel 8 | 2 | 128 | 12.93 | 17.05 | 1.431 / 0.779 |
| Pixel 8 | 2 | 512 | 12.99 | 15.04 | 5.359 / 2.820 |
| Pixel 8 | 2 | 1024 | 13.06 | 14.43 | 10.275 / 6.400 |
| Pixel 8 | 4 | 128 | 17.18 | 20.75 | 0.979 / 0.543 |
| Pixel 8 | 4 | 1024 | 16.98 | 19.22 | 8.101 / 4.050 |

V4 has higher median decode throughput in every cell, by 4.3–39.3%, and lower
first-logit latency throughout. At 512 tokens both runners use four 128-row
prefill calls; the previous native padding penalty is absent. At 1024 tokens
v4 uses eight 128-row calls while LiteRT-LM selects its 1024-row signature.

A separate [allocation-capacity follow-up](/data/bt/tmp/gemma4-live-kv-20260913/capacity/results/SUMMARY.md)
keeps the same 128-token prompt, 64 forced continuation tokens, two threads,
and v4 binary while increasing allocation from 256 to 4096 tokens. Eight
process blocks and 24 measured sessions completed:

| Phone | Decode tok/s, capacity 256 / 4096 | Attention ms/token, capacity 256 / 4096 |
| --- | ---: | ---: |
| TECNO LJ9 | 16.661 / 15.909 | 4.3639 / 4.7238 |
| Pixel 8 | 16.848 / 17.167 | 3.6877 / 3.6568 |

The allocation grows 16× while attention time changes by +8.25% on TECNO and
−0.84% on Pixel. This supports the audited live-extent implementation; it does
not establish perfectly capacity-independent latency under normal DVFS.
Allocation/zeroing before the first logits and total memory still scale with
capacity. Both capacities match all 65 same-phone LiteRT-LM argmax positions
on both phones; these timing captures have no full-logit dumps.

Session ranges and process medians remain relevant: clocks were not fixed,
phones warmed during runs, and three Pixel process blocks recorded increases
in sampled major-fault counters without enough information to assign them to
inference. Median process-lifetime peak RSS across cells remains higher for v4:
2.58–2.72 GiB versus 1.50–2.07 GiB. These figures include setup and warmup rather
than isolating KV memory. The copied adapter still widens 60 INT2 MLP matrices to INT4,
preserving their coefficients and scales but adding 270 MiB of weight-code
payload before packing metadata. Cache layout changes do not remove that
remaining difference from LiteRT-LM CPU.

Sources, frozen binaries, build dependencies, exact capture commands, and
offline correctness reproduction are retained in the experiment guide above.
It also provides saved-capture analysis commands and an illustrative benchmark
rerun in a fresh capture namespace, assuming `ANDROID_HOME` is set. No Linux-host
model benchmark or Samsung S25 test is included. This is local testing code
outside the checkout, not a new supported runner API.

### Follow-up: compact INT2 MLP weights and shared stage scratch

The next [local Gemma4 E2B experiment](/data/bt/tmp/gemma4-memory-20260913/README.md)
addresses two memory costs left by the live-KV v4 adapter. It reconstructs the
original two-bit coefficients for the 60 gate/up/down MLP matrices in layers
15–34 and dispatches them through static QS8/QC2W fully connected operators.
The published activation and per-channel weight scales are preserved. Their
raw coefficient payload changes from 540 MiB to 270 MiB, and their widened
source mappings are released. Independent
[source verification](/data/bt/tmp/gemma4-memory-20260913/static_int2_manifest_verification.json)
matches all 60 reconstructed streams to the original source hashes.
The compact reconstruction happens once during loading. First-logit benchmarks
exclude model loading and compilation, so they do not measure this additional
loading work or establish a cold-start improvement.

The 151 prefill/decode stage runtimes can also share one XNNPACK scratch arena.
Stages execute sequentially; their externally visible outputs remain in
separate buffers for later consumers. XNNPACK grows the arena when necessary
and repairs sharing runtimes' pointers. The driver retains ownership until
all stage runtimes are destroyed. KV storage remains one 18 MiB INT8 bank at
capacity 2048, with the preceding chunked-prefill and live-attention behavior.

The frozen candidate enables both changes with
`--preserve_static_int2=true --share_workspace=true`; both CLI options default
to false. Its [numerical gate](/data/bt/tmp/gemma4-memory-20260913/CORRECTNESS.json)
passes **199/199 full-logit vectors bitwise** against same-phone LiteRT-LM CPU
references on TECNO LJ9 and Pixel 8. Each phone also passes 103 shared-workspace
checks with 4,071,360 compared floats and 73,416 static-QC2/QC4 FC output values.
A separate [Linux correctness smoke](/data/bt/tmp/gemma4-memory-20260913/linux-smoke-comparison.json)
passes three full-logit vectors. These are recorded correctness diagnostics,
not universal numerical-equivalence or model-quality guarantees.

The [completed memory matrix](/data/bt/tmp/gemma4-memory-20260913/analysis/results/MEMORY.md)
contains 18 processes and 36 sessions. It compares all four combinations of
compact weights and shared scratch at prompt 128, plus the combined candidate
at prompt 1024, with preceding native v4 and LiteRT-LM CPU observations.
Current RSS after the second session's last decode is:

| Phone | Prompt | LiteRT-LM RSS (MiB) | Native v4 RSS (MiB) | Combined candidate RSS (MiB) |
| --- | ---: | ---: | ---: | ---: |
| TECNO LJ9 | 128 | 1601.7 | 2634.2 | 1908.1 |
| TECNO LJ9 | 1024 | 2015.7 | 2779.6 | 1998.6 |
| Pixel 8 | 128 | 1516.9 | 2637.5 | 1897.8 |
| Pixel 8 | 1024 | 2004.7 | 2785.3 | 1988.8 |

The combined candidate reduces current RSS by 726–797 MiB relative to v4.
The source payload and recorded packed-weight capacity each fall by 270 MiB.
Unique scratch falls from 197–268 MiB to one 8.75 MiB arena on TECNO or one
9.13 MiB arena on Pixel. The remaining current-RSS gap versus LiteRT-LM is
306–381 MiB at prompt 128; at prompt 1024 the candidate is about 16–17 MiB lower
in these observations. The report keeps PSS and lifetime peak separate and
does not assign every resident byte to one allocation category. All 1820
native argmax rows in the memory captures match the same-phone LM references.
The earlier 60-matrix widening limitation applies to historical v4, not this
combined candidate.

The [completed focused performance report](/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914/perf_results/SUMMARY.md)
contains **24 selected processes and 72 measured sessions**, covering two
threads at prompts 128 and 1024 on both phones. Each cell uses the process
order LiteRT-LM, v4, candidate, candidate, v4, LiteRT-LM, with one warmup and
three measured sessions per process and 64 forced decode calls per session.
Each value below is a median of six measured sessions from two process blocks
per backend/cell, using inclusive `elapsed_ms`.

| Phone | Prompt | LiteRT-LM decode (tok/s) | Native v4 decode (tok/s) | Combined candidate decode (tok/s) | First logits, LM / v4 / candidate (s) |
| --- | ---: | ---: | ---: | ---: | ---: |
| TECNO LJ9 | 128 | 11.98 | 16.45 | 13.40 | 1.243 / 0.840 / 0.842 |
| TECNO LJ9 | 1024 | 12.01 | 13.19 | 11.67 | 11.966 / 7.801 / 7.756 |
| Pixel 8 | 128 | 12.88 | 16.60 | 17.47 | 1.444 / 0.789 / 0.751 |
| Pixel 8 | 1024 | 12.69 | 14.16 | 14.67 | 11.108 / 7.675 / 8.003 |

Relative to native v4, the candidate's median decode throughput is **18.5%
lower at prompt 128 and 11.6% lower at prompt 1024 on TECNO**. Pixel's median
throughput is **5.2% and 3.6% higher**, respectively. Against LiteRT-LM CPU,
the candidate is 11.9% faster on TECNO at 128 tokens but 2.9% slower at 1024;
on Pixel it is 35.6% and 15.6% faster. Its first-logit latency is lower than
LiteRT-LM in all four cells. Against v4, first-logit differences are small on
TECNO; Pixel improves at 128 but takes 4.3% longer at 1024. These are measured
medians under default DVFS, with session and process ranges retained in the
report; small differences are not claims of a universal speedup. Three Pixel
process blocks recorded increases in sampled major-fault counters; the samples
do not identify which execution phase incurred those faults.

First-logit time includes session initialization, prefill, and the final prompt
token's decode. Both first-logit and decode timings include reading logits
and selecting the validation argmax; they exclude loading, compilation,
tokenization, and generation-policy sampling. Memory diagnostics and dumps
are disabled for timing captures. The
[stage/source cost review](/data/bt/tmp/gemma4-memory-20260913/PERFORMANCE_COST_REVIEW.md)
locates most of TECNO's added time in post-attention stages containing the
changed MLP operations. It does not isolate QC2 kernel cost from shared-workspace
effects or other work in those stages. The memory savings have a measured
performance cost on TECNO; this is not a universal speed improvement.

The [selected performance matrix](/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914/)
preserves the completed prompt-128 cells from the original attempt. An
interruption left the final long-prompt processes incomplete; both prompt-1024
cells were rerun as complete six-process sequences in a fresh capture namespace.
The [selection record](/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914/selection.json)
preserves the original hashes and explains the excluded captures. Frozen
executables, models, and protocol are unchanged. No cell combines sessions
from the two attempts. The selected count excludes the preserved long-prompt
captures from the interrupted attempt.

Memory comparisons use `after_last_decode`, while both implementations still
retain KV. Native releases its bank before `after_session`; LiteRT-LM retains
executor-owned KV at that phase. Source-buffer bytes are mapped/owned payload,
not resident pages; allocation counters and RSS/PSS are not additive.
Quantization metadata and general allocator overhead remain outside the
enumerated totals. The output head's 96 MiB reconstruction buffer and retained
external outputs are further costs beyond the shared scratch optimization.

The experiment guide links frozen source/binary hashes, exact build and capture
commands, component tests, and phone rerun instructions assuming `ANDROID_HOME`
is set. These commands regenerate saved numerical and memory reports without
device execution. The numerical comparison requires NumPy; the recorded run
used the converter's existing NumPy environment with one BLAS thread. Use
`python3` below only when that interpreter has NumPy installed:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  python3 /data/bt/tmp/gemma4-memory-20260913/check_correctness.py
python3 /data/bt/tmp/gemma4-memory-20260913/analysis/memory.py --expect-final-matrix
```

Both validations have passed for the completed correctness and memory matrices.
The selected performance report and standalone chart also passed strict
offline analysis. The separate
[independent review](/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914/PERF_REVIEW.json)
passes all 24 selected processes, 72 sessions, and 4608 measured decode calls,
including source hashes, non-overlapping process order, and recomputed medians:

```sh
GEMMA_PERF_ROOT=/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  uv run --no-project --with matplotlib python \
  /data/bt/tmp/gemma4-memory-20260913/perf_analysis.py --root "$GEMMA_PERF_ROOT" --chart
```

The remaining memory difference is within this local experiment's scope;
further memory changes are not part of this campaign. Fresh phone runs require
a new capture namespace. No Samsung/S25 tests
or Linux-host model-performance benchmarks are included. The implementation
remains local testing code outside the checkout.

### Isolating the compact-weight decode cost

The [follow-up ablation](/data/bt/tmp/gemma4-decode-regression-20260914/README.md)
uses the same frozen native executable for all four combinations of compact
static INT2 weights and shared scratch. QC2 stores four two-bit coefficients
per byte with a scale for each output channel; the actual values here are
`[-2, -1, 0, 1]`. QC4 widens those same coefficients to two per byte.
Activations and KV storage remain INT8. At prompt 128 with two threads, median
decode throughput is:

| Phone | Neither change | QC2 only | Shared scratch only | Both changes |
| --- | ---: | ---: | ---: | ---: |
| TECNO LJ9 | 16.61 tok/s | 14.19 tok/s | 16.72 tok/s | 13.93 tok/s |
| Pixel 8 | 17.57 tok/s | 18.16 tok/s | 16.42 tok/s | 17.30 tok/s |

This identifies the QC2 flag as TECNO's main regression: it adds 10.26 ms/token
with private scratch and 11.97 ms/token with shared scratch. Post-attention
stages account for 10.01 and 10.96 ms of those deltas. Sharing scratch alone is
approximately neutral on TECNO. The [source audit](/data/bt/tmp/gemma4-decode-regression-20260914/WORKSPACE_COST_AUDIT.md)
finds no routine stage-switch copy, clearing, or repeated static-weight packing.
The stage timers include other work besides the changed FCs; isolated operator
probes investigate the kernel-level cause separately.

The corrected [operator comparison](/data/bt/tmp/gemma4-decode-regression-20260914/kernel-probe/V3_RESULTS.md)
reproduces QC2's TECNO cost inside invocation; an NR16 kernel experiment does
not provide a repeatable improvement. [Single-core controls](/data/bt/tmp/gemma4-decode-regression-20260914/kernel-probe/SINGLE_CORE_RESULTS.md)
with a null threadpool find QC2 slower on Cortex-A715 in both phones and faster
on Pixel's Cortex-X3. All 11 clean probes pass dispatch and bitwise output
checks. They use the actual weights/scales with fixed synthetic inputs and
both packed formats resident; their sums do not predict full-model throughput.
Clocks and memory conditions remain uncontrolled. These results establish a
core-dependent kernel tradeoff, without attributing exact cycles to unpacking
or memory stalls. The full-model implementation remains unchanged; NR16 has
not been validated in the complete model or adopted as production dispatch.

Pixel benefits from QC2 in both scratch configurations, but sharing lowers
throughput in this sample; BOTH is close to NONE. Session ranges overlap.
This preserves the earlier measured gain against v4: the new ablation uses
a different executable control, fresh sessions, and a different process order.
Neither result supports a uniform Pixel speedup claim under default DVFS.

The [validated report](/data/bt/tmp/gemma4-decode-regression-20260914/analysis/results/SUMMARY.md)
contains 16 processes and 48 measured sessions, each with 64 forced decode
calls. All 4,160 argmax rows, including warmups, agree across variants and
session resets within each phone. An [independent review](/data/bt/tmp/gemma4-decode-regression-20260914/analysis/ROOT_REVIEW.json)
also matches those rows to the earlier same-phone LiteRT-LM CPU reference
with identical prompt and forced tokens. Actual flags, source/binary hashes, histories,
affinity, and chronological non-overlap pass validation. These metadata checks
complement the preceding 199-vector full-logit correctness result. The guide
links the standalone chart, factorial deltas, controller commands, and offline
reproduction instructions. The accepted memory target is unchanged; this
campaign includes no Samsung/S25 or Linux-host performance workloads.
