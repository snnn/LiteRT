# Shared Gemma tokenizer and console utilities

This directory contains the small subset of LiteRT's Gemma3 example utilities
reused by the [Gemma4 executable](../gemma4/README.md). There is no Gemma3 model
graph or executable in this checkout.

| File | Responsibility |
| --- | --- |
| [tokenizer.h](tokenizer.h), [tokenizer.cc](tokenizer.cc) | `GemmaTokenizerSP`, an owning wrapper around a SentencePiece processor. |
| [util.h](util.h) | Lap timers, prefill/decode timing summaries, and buffered token/progress printing. |

`GemmaTokenizerSP::Load` reads a SentencePiece `.model` file and returns a status
on failure. `Encode` optionally prepends the fixed Gemma BOS ID (`2`), while
`Decode` converts a token sequence to text. `DecodeToken` tries one-token decoding
and falls back to the raw piece if it fails. Load logs the tokenizer's special
IDs and warns about BOS/EOS mismatches; it does not remap those IDs. Encoding or
sequence-decoding errors are logged and return an empty result.

`Timer::LapScope` records a lap when its scope ends. `PrefillTiming` and
`DecodeTiming` group these measurements into stages used by the main program;
callers set the count per lap when reporting per-token rates. Named timers are
kept in a process-wide registry, but the individual timer's measurements are
not synchronized for concurrent updates. `TokenPrinter` batches console output
on a short time interval and needs `Flush()` to emit any remaining text.

These files retain the upstream utility interfaces and use local
`litert/tensor/...` includes. The [examples CMake file](../CMakeLists.txt) builds
`litert_gemma_tokenizer` with the pinned SentencePiece dependency. Model loading,
prompt formatting, generation limits, and sampling belong in the
[Gemma4 main program](../gemma4/xnnpack_main.cc), rather than this utility layer.
See the [Gemma4 workflow](../gemma4/README.md) and
[tensor build instructions](../../README.md#build-and-test) for integration and
validation.
