# Local tensor-runner examples

This directory contains a local copy of the Gemma4 CPU example from LiteRT's
`tensor/examples` tree, adapted to the tensor API in this XNNPACK checkout.
It constructs expression graphs and executes them through `XnnpackRunner`.
The sources were copied from a LiteRT working tree at commit
`08cc9adcade8da5d996e3f68e184a5498482fa19`; local adaptations are described below.
This experiment is intended for local development and testing.

| Component | Responsibility |
| --- | --- |
| [gemma4](gemma4/README.md) | E2B/E4B text graph, CPU generation driver, quantized checkpoint integration, numerical references, and host/device run instructions. |
| [gemma3](gemma3/README.md) | Reused SentencePiece tokenizer and timing/printing utilities; this is not a complete Gemma3 example. |
| [ops/transformer](ops/transformer/README.md) | Composite RMSNorm and split-half RoPE operations, plus XNNPACK implementations of mask and positional-constant generators. |
| [utils](utils/README.md) | Safetensors parsing, mapped storage, weight-name translation, and mobile compressed-tensors decoding. |
| [CMakeLists.txt](CMakeLists.txt) | Optional example libraries, `gemma4_xnnpack_main`, and model/helper/loader test targets. |

Enable this tree with `-DLITERT_TENSOR_BUILD_GEMMA4=ON` in the standalone
[tensor CMake build](../README.md#build-and-test). It defaults to OFF. The
examples have no Bazel targets in this checkout. The CMake option adds pinned
SentencePiece 0.2.0, using its bundled protobuf sources, and includes the new
GoogleTest binaries in the Android launcher's generated manifest.

The port uses XNNPACK's in-memory weights cache, held until both prefill and
decode runners are destroyed. The copied example has no dependency on the
LiteRT interpreter, TFLite file-cache utility, or Perfetto tracing library.
The mobile path adds per-module quantization metadata and static activation
scales; the original helper tests continue to exercise floating-point graphs.

Start with the [Gemma4 run guide](gemma4/README.md) for actual checkpoints.
The default unit tests use synthetic tensors and require no model download.
