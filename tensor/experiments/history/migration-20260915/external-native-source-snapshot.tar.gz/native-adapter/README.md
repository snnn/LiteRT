# Native XNNPACK Gemma4 adapter for the three-runtime phone comparison

This is an isolated copy of the latest validated compact-memory native
candidate from `/data/bt/tmp/gemma4-memory-20260913/variants/v1`. Its algorithms
are unchanged. The single change in [capacity-8448.patch](capacity-8448.patch)
raises the driver's accepted `--cache_capacity` ceiling from 4096 to 8448.
The original executable therefore cannot run this campaign at capacity 8448,
or consume a 4096-token prompt followed by 64 forced tokens.
[source-provenance.json](source-provenance.json) records all copied hashes.

[build-native-android.py](build-native-android.py) compiled the copied driver
and unchanged INT8 helper against the 97 retained static archives. The build
uses the original Android NDK r27d, API 24, and static libc++.
[android-build-manifest.json](android-build-manifest.json) records exact
commands, source/archive hashes, and ELF validation. The rebuilt executable
SHA256 is `fbe9897ce1e6bf05ca00536077dbad255b57204d4bf9d5ce666bb38064df6f74`.
Its only dynamic dependencies are Android's libm, liblog, libdl, and libc.

## Implementation and model identity

[memory-main.cc](memory-main.cc) builds the re-authored Gemma4 graph using the
XNNPACK tensor API. Its staged graph borrows one persistent pthreadpool and
one packed-weight cache. With `--share_workspace=true`, all serialized stages
also share one XNNPACK scratch arena. The owner destroys stages before the
arena, pool, and cache. No LiteRT-LM executor runs inside this adapter.

[matched_bundle_loader.h](matched_bundle_loader.h) loads the retained export
at `/tmp/gemma4-local-port-nggiqf9x/replacement-comparison/matched-bundle`.
That export comes from the same published `.litertlm` file as this campaign's
LiteRT-LM baseline, SHA256
`ab7838cdfc8f77e54d8ca45eadceb20452d9f01e4bfade03e5dce27911b27e42`.
Its manifest SHA256 is
`3cdd41d803c05a4b29729a9892451122987675867ae1841709b2b480ddd826bf`.
The export contains the original coefficient codes, scales, FP32 constants,
quantized projection, dynamic QD8/QC2 head, and INT8 KV quantization metadata.
It is not loaded from the separate Hugging Face CT safetensors checkpoint.

`--preserve_static_int2=true` reconstructs the original two-bit code streams
of 60 MLP tensors, retaining their exact coefficients and scales. The driver
checks that all 60 compact tensors and QS8/QC2W operators are present. This
campaign uses that flag together with shared scratch, matching the preceding
memory candidate. The subsequent NR16 experiment was an isolated operator
probe and was never adopted into this full-model implementation. Compact
QC2 previously had device-dependent speed tradeoffs; its memory benefit does
not imply a speed improvement on every phone.

The regular Gemma4 examples in `/data/bt/os/xnnpack/litert/tensor/examples`
and `~/src/LiteRT/tensor/examples` do not themselves contain this entire
matched-bundle, live-INT8, shared-stage implementation. The external adapter
and overlay are the relevant native candidate for this comparison.

## Capacity and execution flow

[active_kv_bank.h](active_kv_bank.h) owns one INT8 bank with 15 distinct KV
owners and 30 buffers. Both K and V use `[capacity, head_dim]` storage. At 8448
the logical payload is 77,856,768 bytes, plus per-buffer XNNPACK overread
padding. Each session creates and zeroes a fresh bank; compiled stages and
packed weights are reused. Only newly produced rows are appended.

Attention views use the live global prefix or local window, with endpoints
aligned to 32 positions and unused positions masked. Allocation capacity does
not become the attention operand extent. RoPE uses absolute FP32 positions
computed for each chunk; it has no fixed 4096-position lookup table. Allocation
and view bounds use the requested capacity, with overflow and range checks.
8448 is divisible by the default alignment of 32. Source inspection found no
additional 4096 limit in the active graph, bank, masks, or RoPE path.

The default 128-row prefill graph processes all prompt tokens except the last.
It stops after the last distinct KV-producing layer, without output logits.
The one-row decode graph consumes the last prompt token and returns the first
full-vocabulary logits. The fixture's 64 forced IDs then produce 64 additional
logit rows. A final partial prefill chunk pads rows but commits only real
tokens. The three prompt lengths therefore use 1, 8, and 32 prefill invocations,
respectively, followed by the reserved last-token decode.

The previous numerical gates covered histories through capacity 2048; the
older allocation-capacity follow-up used a short history at capacity 4096.
Neither establishes correctness beyond position 4095. The new campaign
adds short smoke checks at capacity 8448 and full-logit comparisons at
positions 4095, 4096, and 4097 against same-phone LiteRT-LM references before
accepting long-context timing results. All of those checks passed as recorded
below; this is evidence for the tested histories, not universal equivalence.

## CLI and timing contract

Use the controller's explicit device serial and four-core affinity, with
unique output directories whose parents already exist:

```sh
adb -s "$SERIAL" shell "taskset $MASK $NATIVE_REMOTE \
  --bundle_dir=$BUNDLE_REMOTE \
  --cases_file=$FIXTURE_REMOTE --output_dir=$OUTPUT_REMOTE \
  --num_threads=4 --cache_capacity=8448 \
  --prefill_chunk_rows=128 --kv_alignment=32 \
  --preserve_static_int2=true --share_workspace=true \
  --reuse_runtimes=true --warmup_runs=1 --measured_runs=3 \
  --dump_full_logits=false --dump_cache=false \
  --memory_report=false --fixed_attention_extent=false --trace_position=-1"
```

The native capacity flag is `--cache_capacity`, not `--max_num_tokens`.
The two optimization flags default to false and must be set explicitly.
Normal arithmetic and the weight cache are required. For correctness captures,
use zero warmups, one measured run, and `--dump_full_logits=true`; attention
operator audits execute in this mode, so its timing fields are diagnostic.

Prefill `elapsed_ms` starts before bank allocation/zeroing and includes all
prefix chunks, reserved last-token decode, output access, the complete-logit
finite check, and argmax. Each decode elapsed timer includes embedding lookup,
mask/position preparation, cache appends, stage binding, synchronous execution,
and output validation. Dump and report writing follow the timer. Model loading,
runtime compilation, and static weight packing are excluded. This matches the
comparison's inclusive first-logit and forced-decode boundaries, while charging
native session initialization through its actual fresh-bank allocation.

The narrower `forward_ms` sums stage `Run()` calls, including their reshape/setup
work; it excludes embedding lookup, mask construction, and inter-stage binding.
It is not directly equivalent to the other adapters' `forward_ms`. Compare
inclusive `elapsed_ms`. `--memory_report=true` introduces diagnostic `/proc`
reads, including inside prefill, and marks results ineligible for benchmarking.

## Output schema

Per-case files use `CASE.warmup_000.json` and `CASE.run_000.json` naming. Each
contains `runner: "xnnpack_tensor_live_int8"`, raw prompt/forced IDs, thread and
reuse settings, `kv_capacity`, `kv_dtype: "int8"`,
`kv_layout: "owner_position_channel"`, optimization flags and audited counts,
`compiled_this_run`, `timings_valid_for_benchmark`, peak process RSS, and the
65-entry `passes` array. Pass indices are 0 through 64; index 0 has kind
`prefill`, the others `decode`. Each pass records `input_ids`, context length,
logit position, argmax, inclusive/forward timing, and optional dump filename.

This unchanged native schema has no per-run `status` or `max_num_tokens` field
and no manifest listing. Only after every requested case/repetition succeeds,
the driver writes `run.json` with `status: "completed"`, case count, and peak
RSS. Validation must combine that completion marker with the exact expected
warmup/run filenames, token histories, pass count, and configuration fields.

## Phone correctness gate

[validate_native.py](../validate_native.py) passes **15/15 complete vocabulary
vectors bitwise** against the same-phone LiteRT-LM CPU references. Each of
TECNO, Pixel 8, and Samsung S25 passed two vectors from the 8+1 smoke and three
vectors at positions 4095, 4096, and 4097 from the 4096+2 boundary fixture.
Every vector contains 262,144 finite FP32 values. Maximum absolute error and
RMSE are zero. Fixture histories, consumed positions, raw/metadata argmax,
four-thread affinity, capacity, INT8 formats, compact-weight counts, command
identity, and binary hashes were checked. A separate reviewer independently
rechecked the raw bytes without importing the validator.

[The final report](../correctness/native-validation.json) retains all vector
and metadata hashes. The primary gate remains the preceding candidate's
bitwise requirement. The previous diagnostic thresholds (matching argmax,
cosine at least 0.999, RMSE at most 0.05) are also reported unchanged and do not
replace that primary gate. The command records and full-logit dumps are in
[smokes](../smokes) and [boundary captures](../correctness/native-boundary),
with the corresponding [LiteRT-LM references](../correctness/native-boundary-reference).

These are correctness captures with dumps and operator audits enabled; their
timing fields are excluded from performance summaries. No host model inference
or host benchmark was run. Subsequent benchmark commands and measurements are
managed by the campaign controller.
