#!/usr/bin/env python3
"""Build the isolated capacity-adjusted native driver with retained Android archives.

Compiles two translation units serially; never invokes a host model or writes
inside source repositories or the historical CMake build directory.
"""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

root = Path(__file__).resolve().parent
frozen = Path('/data/bt/tmp/gemma4-memory-20260913/variants/v1')
original_root = '/data/bt/tmp/gemma4-memory-20260913'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
provenance = json.loads((root / 'source-provenance.json').read_text())
assert sha(root / 'memory-main.cc') == provenance['new_source_sha256']
for name, expected in provenance['copied_original_hashes'].items():
    if name != 'memory-main.cc':
        assert sha(root / name) == expected, name
    assert sha(frozen / name) == expected, name
original_source = (frozen / 'memory-main.cc').read_text()
assert original_source.count('capacity>4096') == 1
assert (root / 'memory-main.cc').read_text() == original_source.replace('capacity>4096', 'capacity>8448')
original_commands = json.loads((frozen / 'memory-main.android.commands.json').read_text())
def adapt(argv):
    return [value.replace(original_root, str(root)) for value in argv]
commands = {
    'compile': adapt(original_commands['compile']),
    'extra_compile_commands': [adapt(argv) for argv in original_commands['extra_compile_commands']],
    'link': adapt(original_commands['link']),
    'cwd': original_commands['cwd'],
    'source_sha256': sha(root / 'memory-main.cc'),
    'frozen_commands_sha256': sha(frozen / 'memory-main.android.commands.json'),
    'overlay_sha256': {str(path.relative_to(root / 'overlay')): sha(path) for path in sorted((root / 'overlay').rglob('*')) if path.is_file()},
}
(root / 'memory-main.android.commands.json').write_text(json.dumps(commands, indent=2) + '\n')
cwd = Path(commands['cwd'])
archives = []
for value in commands['link']:
    if value.endswith('.a'):
        path = Path(value)
        if not path.is_absolute():
            path = cwd / path
        assert path.is_file(), path
        archives.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)})
assert '-static-libstdc++' in commands['link']
assert '-O2' in commands['compile'] and '-DNDEBUG' in commands['compile']
manifest = {
    'schema_version': 1,
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'building',
    'build_scope': 'Two copied-driver/helper translation units and relink against 97 retained static archives. No source repository rebuild or changes.',
    'source_provenance': str(root / 'source-provenance.json'),
    'source_provenance_sha256': sha(root / 'source-provenance.json'),
    'frozen_source_root': str(frozen),
    'frozen_source_manifest_sha256': sha(frozen / 'manifest.json'),
    'original_binary_sha256': sha(frozen / 'memory-main.android'),
    'commands_sha256': sha(root / 'memory-main.android.commands.json'),
    'source_sha256': commands['source_sha256'],
    'static_archives': archives,
    'host_inference_executed': False,
    'phone_inference_executed_by_build_script': False,
    'algorithm_or_schema_changes': False,
    'capacity_ceiling_change': {'before': 4096, 'after': 8448},
    'optimization': {'build_type': 'RelWithDebInfo', 'optimization_flag': '-O2', 'ndebug': True, 'fp_contract': 'off'},
    'android': {'abi': 'arm64-v8a', 'minimum_api': 24, 'ndk_version': '27.3.13750724', 'stl': 'c++_static'},
}
manifest_path = root / 'android-build-manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
start = time.monotonic()
with (root / 'memory-main.android.build.log').open('w') as log:
    for name, argv in [('compile_main', commands['compile']), *[(f'compile_extra_{i}', argv) for i, argv in enumerate(commands['extra_compile_commands'])], ('link', commands['link'])]:
        print(name, flush=True)
        result = subprocess.run(argv, cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
        if result.returncode:
            manifest.update(status='failed', failed_step=name, returncode=result.returncode)
            manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
            raise SystemExit(result.returncode)
binary = root / 'memory-main.android'
readelf = Path(commands['compile'][0]).with_name('llvm-readelf')
outputs = {}
for flag, name in [('--file-header', 'header'), ('--dynamic', 'dynamic'), ('--notes', 'notes'), ('--program-headers', 'program_headers')]:
    outputs[name] = subprocess.check_output([str(readelf), flag, str(binary)], text=True)
    (root / f'memory-main.android.{name}.txt').write_text(outputs[name])
needed = re.findall(r'\(NEEDED\).*\[(.+?)\]', outputs['dynamic'])
assert 'AArch64' in outputs['header'] and 'ELF64' in outputs['header']
assert set(needed) == {'libm.so', 'liblog.so', 'libdl.so', 'libc.so'}, needed
assert '/system/bin/linker64' in outputs['program_headers']
assert '(RPATH)' not in outputs['dynamic'] and '(RUNPATH)' not in outputs['dynamic']
manifest.update(
    status='built_and_elf_validated',
    completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    compile_link_elapsed_seconds=time.monotonic() - start,
    compiler_version=subprocess.check_output([commands['compile'][0], '--version'], text=True).strip(),
    executable={'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': sha(binary), 'machine': 'AArch64', 'elf_class': 'ELF64', 'interpreter': '/system/bin/linker64', 'needed_shared_libraries': needed, 'non_system_shared_libraries': [], 'build_id': re.search(r'Build ID: (\w+)', outputs['notes']).group(1)},
    build_log_sha256=sha(root / 'memory-main.android.build.log'),
    source_after_build_sha256=sha(root / 'memory-main.cc'),
)
assert manifest['source_after_build_sha256'] == manifest['source_sha256']
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest['executable'], indent=2), flush=True)
