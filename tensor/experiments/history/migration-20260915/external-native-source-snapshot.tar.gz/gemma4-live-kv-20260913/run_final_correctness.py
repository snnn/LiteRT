import sys,json
from pathlib import Path
from phone_runs import ROOT,REMOTE,run_capture,adb
phone=sys.argv[1]
for local,remote in [('live-main.android','live-int8-v4.android'),('active_kv_bank_test.android','active_kv_bank_test_v4.android'),('active_extent_rounding_test.android','active_extent_rounding_test.android')]:
 adb(phone,['push',str(ROOT/local),REMOTE+'/'+remote])
for name in ['active_kv_bank_test_v4.android','active_extent_rounding_test.android']:
 r=adb(phone,['shell',REMOTE+'/'+name],check=False)
 (ROOT/(phone+'-'+name+'.log')).write_text(r.stdout+r.stderr)
 if r.returncode:raise RuntimeError('Unit test failed: '+name)
 print(json.dumps({'device':phone,'unit':name,'status':'passed'}),flush=True)
for fixture,tag,threads,warmups in [('gate.tsv','final_gate_reuse_t2',2,1),('gate.tsv','final_gate_reuse_t4',4,1),('performance_512_64.tsv','final_long512_t2',2,0),('long_boundary.tsv','final_long_boundary_t2',2,0),('boundary.tsv','final_boundary_t2',2,0)]:
 run_capture(phone,'final',ROOT/'fixtures'/fixture,tag,threads=threads,reuse=True,warmups=warmups,runs=1,dump=True)
# Matched LiteRT-LM CPU references where historical full vectors were absent.
if phone=='pixel8':
 run_capture(phone,'litertlm',ROOT/'fixtures/performance_512_64.tsv','reference_long512_t2',threads=2,reuse=True,warmups=0,runs=1,dump=True)
run_capture(phone,'litertlm',ROOT/'fixtures/long_boundary.tsv','reference_long_boundary_t2',threads=2,reuse=True,warmups=0,runs=1,dump=True)
