from pathlib import Path
import importlib.util,json,sys
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('compare', '/tmp/gemma4-local-port-nggiqf9x/replacement-comparison/compare_runs.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
OLD=Path('/data/bt/tmp/gemma4-phone-perf-20260913')
manifest=ROOT/'validation/fixtures/manifest.json'
report={'status':'passed','comparisons':{},'unavailable':[]}
for device in ['tecno','pixel8']:
 pairs=[]
 for t in [2,4]:pairs.append((f'gate_t{t}',OLD/device/f'runs/gate_litertlm_reuse_t{t}',ROOT/device/f'runs/final_gate_reuse_t{t}'))
 ref=OLD/'tecno/runs/followup512_litertlm_t2' if device=='tecno' else ROOT/device/'runs/reference_long512_t2'
 pairs.append(('long512',ref,ROOT/device/'runs/final_long512_t2'))
 pairs.append(('long_boundary',ROOT/device/'runs/reference_long_boundary_t2',ROOT/device/'runs/final_long_boundary_t2'))
 # Historical boundary capture is updated LiteRT-LM CPU on TECNO.
 if device=='tecno':pairs.append(('boundary',Path('/data/bt/tmp/gemma4-pr9918/results/android/litertlm/boundary-pr9918-v1'),ROOT/device/'runs/final_boundary_t2'))
 for name,a,b in pairs:
  key=device+'_'+name
  if not (a/'run.json').exists() or not (b/'run.json').exists():report['unavailable'].append(key);continue
  result=c.compare(a,b,manifest)
  (ROOT/(key+'-final-comparison.json')).write_text(json.dumps(result,indent=2)+'\n')
  report['comparisons'][key]=result['overall']
  print(key,json.dumps(result['overall']))
  if result['overall']['bitwise_equal_rows']!=result['overall']['prediction_rows']:report['status']='failed'
if report['unavailable'] and report['status']=='passed':report['status']='incomplete'
report['prediction_rows']=sum(r['prediction_rows'] for r in report['comparisons'].values())
report['bitwise_equal_rows']=sum(r['bitwise_equal_rows'] for r in report['comparisons'].values())
(ROOT/'FINAL_CORRECTNESS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='comparisons'}))
sys.exit(1 if report['status']=='failed' else 0)
