# Live KV correctness fixtures and comparison

These tools compare saved Gemma4 E2B outputs. They perform no inference and use
no devices. They preserve the captures they read. Numerical comparisons are
diagnostics; they do not establish model quality or replacement readiness.

## Fixtures

[fixtures/manifest.json](fixtures/manifest.json) records token histories,
source hashes, and file hashes. Existing cases retain their original IDs and
exact token histories.

| File | Cases and prediction rows | Purpose |
| --- | --- | --- |
| [quick.tsv](fixtures/quick.tsv) | `gate_128`, 3 rows | Initial subset of the existing gate capture. |
| [gate.tsv](fixtures/gate.tsv) | `gate_128`, `gate_512`, `gate_1024`, `gate_128_reset`; 12 rows | Short/long prefill and long-to-short session sequence. |
| [sequential.tsv](fixtures/sequential.tsv) | `france_sequential`, 8 rows | Existing short decode chain; historical cache dumps are available. |
| [boundary.tsv](fixtures/boundary.tsv) | `boundary_510`, 5 rows | Existing histories of lengths 510 through 514 cross the local-window boundary. |
| [performance_512_64.tsv](fixtures/performance_512_64.tsv) | `performance_512_64`, 65 rows | Exact continuation that exposed the earlier frozen native divergence. |
| [long_boundary.tsv](fixtures/long_boundary.tsv) | `live_boundary_1023`, 5 rows; `live_boundary_2046`, 3 rows | Repeated-text cases cross 1024 tokens and reach capacity 2048. References were added in the final v4 campaign below. |

`gate_128_reset` uses the same history as `gate_128`, after the longer cases in
the full gate file. Whether this exercises buffer reuse or newly allocated
session state depends on the driver. The fixture alone does not prove that
`ActiveKvBank::Reset()` was called.

The repeated-text fixtures are synthetic numerical workloads. No accuracy or
language-quality claim should be based on their target likelihoods.

## Reusing frozen captures

[frozen_captures.json](frozen_captures.json) is the original inventory of 24 saved captures,
including case IDs, exact history matches, thread counts, full-logit file
availability, cache-manifest counts, and metadata hashes. It remains a historical
snapshot; the final v4 campaign added references listed in the next section.

| Reference | Location | Available evidence |
| --- | --- | --- |
| Updated LiteRT-LM, TECNO and Pixel 8 gate | `/data/bt/tmp/gemma4-phone-perf-20260913/{tecno,pixel8}/runs/gate_litertlm_{fresh_t2,reuse_t2,reuse_t4}` | All 12 full-logit vectors; two- or four-thread configuration as named. |
| Updated LiteRT-LM, TECNO 512+64 | `/data/bt/tmp/gemma4-phone-perf-20260913/tecno/runs/followup512_litertlm_t2` | All 65 full-logit vectors. |
| Updated LiteRT-LM, TECNO boundary | `/data/bt/tmp/gemma4-pr9918/results/android/litertlm/boundary-pr9918-v1` | All 5 full-logit vectors. |
| Updated LiteRT-LM, TECNO sequential | `/data/bt/tmp/gemma4-pr9918/results/android/litertlm/sequential-pr9918-v1` | All 8 full-logit vectors. |
| Updated LiteRT-LM, Pixel 8 sequential | `/data/bt/tmp/gemma4-phone-perf-20260913/pixel8/correctness-litertlm-sequential` | All 8 full-logit vectors. |
| Historical LiteRT-LM, Linux | `/tmp/gemma4-local-port-nggiqf9x/replacement-comparison/results/linux/litertlm/{boundary-configured,sequential-configured,sequential-cache-trace-v2}` | Exact boundary/sequential histories; the trace capture includes raw KV. This is the historical binary, not an updated PR9918 host reference. |

Pixel 8's original 512+64 performance runs contain argmax values but no full-logit
dumps; the final campaign captured a separate full-logit reference. Updated phone
references have no raw KV dumps. No saved host outputs were found for the exact
phone gate or 512+64 fixtures. Do not replace a missing same-device reference
with a different backend/version silently.

## Final v4 same-phone comparisons

[FINAL_CORRECTNESS.json](../FINAL_CORRECTNESS.json) records **199/199 full-logit
vectors bitwise equal** between frozen v4 and LiteRT-LM CPU on the same phone.
The gate uses the original same-phone two- and four-thread references above.
The 65-vector TECNO long continuation and five-vector TECNO local boundary also
reuse their original references. The final campaign adds:

| Reference | LiteRT-LM CPU capture | v4 capture |
| --- | --- | --- |
| Pixel 8, 512-token prompt plus 64 forced decode calls | [reference_long512_t2](../pixel8/runs/reference_long512_t2/run.json) | [final_long512_t2](../pixel8/runs/final_long512_t2/run.json) |
| TECNO, eight vectors around 1024 and capacity 2048 | [reference_long_boundary_t2](../tecno/runs/reference_long_boundary_t2/run.json) | [final_long_boundary_t2](../tecno/runs/final_long_boundary_t2/run.json) |
| Pixel 8, eight vectors around 1024 and capacity 2048 | [reference_long_boundary_t2](../pixel8/runs/reference_long_boundary_t2/run.json) | [final_long_boundary_t2](../pixel8/runs/final_long_boundary_t2/run.json) |

The final report covers 102 TECNO vectors and 97 Pixel vectors. Complete logit
vectors at the previously differing positions 520 and 536 match on both phones.
This is evidence for the recorded histories and configurations, not universal
numerical equivalence. It does not compare final-reference K/V bytes because
those references contain no cache dumps.

[check_final_correctness.py](../check_final_correctness.py) reproduces the nine
comparisons without inference and rewrites the report and per-comparison JSON
files. The [experiment guide](../README.md#build-and-correctness-reproduction)
provides the command and analysis environment. This final report supersedes
the earlier missing-reference status without changing `frozen_captures.json`.

## Comparing captures

Use the existing NumPy environment, with analysis thread counts restricted:

```bash
validation=/data/bt/tmp/gemma4-live-kv-20260913/validation
python=/data/home/chasun/src/litert-converter/.venv/bin/python
baseline=/data/bt/tmp/gemma4-phone-perf-20260913/tecno/runs/gate_litertlm_fresh_t2
candidate=/data/bt/tmp/gemma4-live-kv-20260913/tecno/runs/live_gate_t2_v1
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 "$python" "$validation/compare_live.py" \
  "$baseline" "$candidate" --output "$validation/tecno_gate_comparison.json"
```

Add `--case gate_128` to compare only the quick case against an existing full
gate capture. The comparator creates temporary metadata views and symlinks raw
vectors; it does not edit or copy the source capture. The default case set is
the candidate's first measured runs, which must all exist in the baseline.

The tool imports the existing frozen `compare_runs.py`, retaining checks for
completed captures, exact token histories, thread counts, pass positions,
262144-element little-endian FP32 dumps, finite values, and raw/JSON argmax
agreement. It reports bitwise equality, KL, RMSE, maximum absolute error, cosine,
argmax agreement and margins. Arbitrary diagnostic-threshold counts are removed.
Default exit success means **the comparison completed**. `--require-bitwise`
requests failure on any logit difference or any compared cache-code difference.
Missing cache dumps remain explicitly unavailable and cannot count as a cache
pass. `--no-cache` skips cache analysis entirely.

### Cache layouts

`compare_live.py` automatically recognizes:

* Live dumps named `<logits_file>.owner<N>.{k,v}.i8`, both `[logical_tokens,D]`.
* Historical LiteRT-LM `*.kv.json` manifests.
* Historical native `*.pass_NNNN.json` cache manifests.

Historical K is `[1,1,capacity,D]`; historical V is `[1,1,D,capacity]`. The
comparator restricts both to the logical history and transposes the V view to
`[logical_tokens,D]`. Unused capacity and overread padding are excluded. It
checks owner sets, dimensions, byte counts and available history metadata, and
reports code mismatch counts and the first differing position/channel for each
owner. Live dumps do not currently include quantization scales; their absence
is reported rather than inferred from code equality. Published owner metadata is
recorded separately in [owner_specs.json](owner_specs.json).

The live report schema must emit per-pass `kind` (`prefill` or `decode`). A
field named `phase` alone is insufficient for the frozen comparator. All other
required fields are already emitted by the inspected `WriteLiveRun`.

## Tool validation

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 "$python" "$validation/compare_live_test.py"
```

Nine synthetic tests passed, covering subset reuse/source preservation,
nonzero numerical differences with unchanged argmax, invalid histories and
thread counts, missing fields, nonfinite/wrong-sized dumps, argmax integrity,
V-layout conversion, stale-capacity exclusion, missing cache owners, and cache
history errors. The comparator also reproduced the saved TECNO live gate result:
9/12 vectors bitwise equal, 12/12 argmax matches, with differences only in the
1024-token case. The quick case is 3/3 bitwise equal. A historical native cache
self-comparison read 240 owner tensors and matched all 331776 logical INT8 codes;
that verifies parsing/layout handling, not equivalence between implementations.

`prepare.py` regenerates the fixture copies and inventory from existing local
artifacts. At the time of these original tooling checks, long-boundary fixtures
had only been prepared. Their completed v4 model comparisons are recorded above;
they are separate from the nine synthetic comparator tests.

## TECNO chunk-size cache trace

[tecno_chunk1024_vs_chunk128_cache.json](tecno_chunk1024_vs_chunk128_cache.json)
compares the completed `trace_cache_1024_chunk1024_v2` and
`trace_cache_1024_chunk128_v2` captures under `../tecno/runs/`. Both use the live
token-major layout and identical histories. Differences therefore isolate the
prefill chunk configuration within the live implementation.

Owners 0 and 1 have identical K and V over all three captured passes. Owner 2
is the first owner with different stored codes, exclusively at token positions
580 and 780: 127 K codes and 203 V codes differ, with absolute deltas at most 2.
At position 580/channel 0, K changes from -1 with chunk1024 to 0 with chunk128,
and V changes from 22 to 23.

Owner 3's prefill differences begin earlier, at position 553, and cover 393
positions. Its first K mismatch is channel 1 (-1 to 0); its first V mismatch
is channel 2 (18 to 16). Later owners show broader differences. Every owner
matches through position 552. Across all three passes, 7547253 of 28339200
compared INT8 codes differ; repeated prefix data is counted again in later
passes, so this is not a count of unique state elements.

[tecno_chunk_cache_exact_deltas.json](tecno_chunk_cache_exact_deltas.json)
contains per-owner/per-pass mismatch positions, counts, signed delta
histograms, the first 16 exact code pairs, and raw-file hashes. These are the
earliest **stored KV-code** differences. Earlier FP32 hidden states or Q
projections could already differ, since quantization can conceal smaller
upstream activation differences. The cause is still under investigation.
