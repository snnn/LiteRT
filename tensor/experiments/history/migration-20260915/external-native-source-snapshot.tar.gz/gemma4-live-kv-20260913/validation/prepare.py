#!/usr/bin/env python3
"""Prepare exact local correctness fixtures and an inventory of saved captures.

Reads existing artifacts only; does not run inference or contact devices.
"""
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
PERF = Path('/data/bt/tmp/gemma4-phone-perf-20260913')
OLD = Path('/tmp/gemma4-local-port-nggiqf9x/replacement-comparison')
PR = Path('/data/bt/tmp/gemma4-pr9918')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')


def prepare():
    destination = HERE / 'fixtures'
    destination.mkdir(parents=True, exist_ok=True)
    manifests = [PERF / 'fixtures/manifest.json', OLD / 'fixtures/manifest.json']
    source = {}
    for path in manifests:
        for case in json.loads(path.read_text())['cases']:
            if case['id'] in source and case != source[case['id']]:
                raise ValueError('Conflicting source fixture: ' + case['id'])
            source[case['id']] = case
    copies = {'gate.tsv': PERF / 'fixtures/gate.tsv',
              'performance_512_64.tsv': PERF / 'fixtures/performance_512_64.tsv',
              'boundary.tsv': OLD / 'fixtures/boundary.tsv',
              'sequential.tsv': OLD / 'fixtures/sequential.tsv'}
    selected = {}
    for name, path in copies.items():
        (destination / name).write_bytes(path.read_bytes())
        for line in path.read_text().splitlines():
            if not line or line.startswith('#'):
                continue
            case_id, prompt, forced = line.split('\t')
            case = dict(source[case_id])
            assert list(map(int, prompt.split(','))) == case['prompt_token_ids']
            assert ([int(x) for x in forced.split(',')] if forced else []) == case['forced_token_ids']
            case['fixture_file'] = name
            selected[case_id] = case
    quick = next(line for line in copies['gate.tsv'].read_text().splitlines()
                 if line.startswith('gate_128\t')) + '\n'
    (destination / 'quick.tsv').write_text(quick)
    # Preserve the old cases exactly. Only these additional cases extend the
    # repeated-text stream to new positions; they have no frozen reference.
    stream_case = source['performance_1024_64']
    stream = stream_case['prompt_token_ids'] + stream_case['forced_token_ids']
    body = stream[1:]
    stream = [2] + (body * 3)[:2047]
    additional = [('live_boundary_1023', 1023, 4),
                  ('live_boundary_2046', 2046, 2)]
    lines = []
    for case_id, length, count in additional:
        case = dict(id=case_id, prompt_token_ids=stream[:length],
                    forced_token_ids=stream[length:length + count],
                    kind='synthetic_repeated_text_boundary',
                    fixture_file='long_boundary.tsv', frozen_reference_available=False)
        selected[case_id] = case
        lines.append('\t'.join([case_id, ','.join(map(str, case['prompt_token_ids'])),
                                ','.join(map(str, case['forced_token_ids']))]))
    (destination / 'long_boundary.tsv').write_text('\n'.join(lines) + '\n')
    write(destination / 'manifest.json', dict(
        schema_version=1,
        protocol='Identical raw teacher-forced token histories; no generated tokens fed back.',
        interpretation='Numerical diagnostics, not a quality dataset or acceptance threshold.',
        source_manifests={str(p): sha(p) for p in manifests},
        exact_copies={name: dict(source=str(path), sha256=sha(path))
                      for name, path in copies.items()},
        quick_subset_of='gate.tsv; exact gate_128 case, unchanged history',
        long_boundary_extension='Repeat performance_1024_64 body excluding its initial BOS.',
        cases=list(selected.values()),
        files_sha256={p.name: sha(p) for p in sorted(destination.glob('*.tsv'))}))
    spec_path = HERE.parent / 'overlay/litert/tensor/examples/gemma4/helpers/published_kv_specs.inc'
    pattern = r'\{(\d+),\s*(\d+),\s*([\d.eE+-]+)f,\s*([\d.eE+-]+)f\}'
    specs = [dict(owner=int(o), head_dim=int(d), key_scale=float(k), value_scale=float(v))
             for o, d, k, v in re.findall(pattern, spec_path.read_text())]
    assert len(specs) == 15 and len({s['owner'] for s in specs}) == 15
    write(HERE / 'owner_specs.json', dict(source=str(spec_path), source_sha256=sha(spec_path),
                                        specs=specs))

    candidates = []
    for device in ['tecno', 'pixel8']:
        for backend in ['litertlm', 'native']:
            for mode in ['fresh_t2', 'reuse_t2', 'reuse_t4']:
                candidates.append((device, 'updated_phone_baseline' if backend == 'litertlm'
                                    else 'frozen_window_candidate',
                                    PERF / device / 'runs' / f'gate_{backend}_{mode}'))
        for backend in ['litertlm', 'xnnpack']:
            candidates.append((device, 'updated_phone_baseline' if backend == 'litertlm'
                                else 'frozen_window_candidate',
                                PERF / device / f'correctness-{backend}-sequential'))
        for backend in ['litertlm', 'native']:
            candidates.append((device, 'updated_phone_baseline' if backend == 'litertlm'
                                else 'frozen_window_candidate',
                                PERF / device / 'runs' / f'followup512_{backend}_t2'))
        candidates.append((device, 'argmax_only_performance_capture',
                           PERF / device / 'runs/p512_t2_b0_litertlm'))
    for fixture in ['boundary', 'sequential']:
        candidates.append(('tecno', 'updated_phone_baseline',
                           PR / 'results/android/litertlm' / f'{fixture}-pr9918-v1'))
        candidates.append(('linux', 'historical_litertlm_baseline',
                           OLD / 'results/linux/litertlm' / f'{fixture}-configured'))
    for backend, name in [('litertlm', 'sequential-cache-trace-v2'),
                          ('xnnpack-matched', 'sequential-cache-trace-rope-v2')]:
        candidates.append(('linux', 'historical_cache_trace',
                           OLD / 'results/linux' / backend / name))
    records = []
    for device, role, directory in candidates:
        if not (directory / 'run.json').is_file():
            continue
        completion = json.loads((directory / 'run.json').read_text())
        reports = [json.loads(p.read_text()) for p in sorted(directory.glob('*.run_000.json'))]
        if not reports:
            continue
        cases = []
        for report in reports:
            fixture = selected.get(report['case_id'])
            histories_match = bool(fixture and report['prompt_token_ids'] == fixture['prompt_token_ids']
                                   and report['forced_decode_token_ids'] == fixture['forced_token_ids'])
            raw = [p for p in report['passes'] if isinstance(p.get('logits_file'), str)
                   and (directory / p['logits_file']).is_file()
                   and (directory / p['logits_file']).stat().st_size == 262144 * 4]
            cases.append(dict(id=report['case_id'], exact_fixture_history=histories_match,
                              prompt_tokens=len(report['prompt_token_ids']),
                              forced_tokens=len(report['forced_decode_token_ids']),
                              prediction_rows=len(report['passes']), full_logit_files=len(raw),
                              num_threads=report['num_threads']))
        records.append(dict(device=device, role=role, directory=str(directory),
                            complete=completion.get('status') == 'completed',
                            first_report_runner=reports[0].get('runner'), cases=cases,
                            full_logits_available=all(c['prediction_rows'] == c['full_logit_files'] for c in cases),
                            legacy_cache_manifest_files=len(list(directory.glob('*.kv.json'))) +
                                len(list(directory.glob('*.pass_*.json'))),
                            first_report_sha256={p.name: sha(p) for p in sorted(directory.glob('*.run_000.json'))},
                            completion_sha256=sha(directory / 'run.json')))
    write(HERE / 'frozen_captures.json', dict(
        schema_version=1, captures=records,
        limitations=[
            'No host capture of the phone gate or performance_512_64 histories was found.',
            'The saved Linux LiteRT-LM captures use the historical binary, not the updated Android baseline.',
            'Pixel 8 performance_512_64 has saved argmax values but no full-logit follow-up.',
            'Updated phone baseline captures have no raw KV dumps; historical host sequential traces do.',
            'New live_boundary_1023/live_boundary_2046 cases have no frozen baseline.']))
    print(f'Prepared {len(selected)} fixture cases and {len(records)} frozen capture records in {HERE}')


if __name__ == '__main__':
    prepare()
