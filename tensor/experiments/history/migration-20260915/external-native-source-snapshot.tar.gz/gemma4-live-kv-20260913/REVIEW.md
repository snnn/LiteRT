# Independent staged-runner source review

Reviewed the E2B staged graph and aligned live KV path. No blocking semantic,
buffer-lifetime, cache-ordering, or destruction-order defect was found in the
reviewed configuration. This is a bounded source review, not a numerical
acceptance result or a performance measurement. No models or devices were run
for this review. The separate StageRunner smoke test was run previously.

## Dependency cuts

- [Graph authoring](overlay/litert/tensor/examples/gemma4/gemma4_graph.h)
  retains the original scaled embedding as `initial_hidden`. The full global
  PLE projection is computed before layer cuts and every selected per-layer
  PLE output remains dependent on that embedding and its token embedding.
- Every layer gets a new external `hidden_input`. The original transformer
  consumes it both for the pre-attention norm and residual addition. In
  [RunLiveTokens](live-main.cc), that same preceding-layer output is bound to
  both the projection and post-attention stages. The post stage also receives
  the matching preprocess PLE output and attention context. Its FFN, PLE gate,
  residuals, norms, and final layer scalar remain in the original graph.
- The [attention cut](overlay/litert/tensor/examples/gemma4/helpers/attention.h)
  preserves Q projection, Q norm and RoPE; owners additionally preserve K
  projection/norm/RoPE and V projection/unit norm before original INT8
  quantization. Q/context use the same head-major folding and inverse folding.
  Both token-major K/V inputs feed QK with transposed RHS and PV with ordinary
  RHS. Metadata-only cache handles provide the original scalar quantization.
- The tail receives the final post-stage hidden state. Final norm and the
  explicit dynamic INT2 head remain part of that tail.

## Owner ordering and cache-only prefill

- E2B has owners 0–14, with later shared layers consuming owners 13/14. Each
  owner appends before its own attention and before any shared consumer.
  [ActiveKvBank](active_kv_bank.h) validates each owner's pending visibility,
  disallows duplicate appends, and commits only after every owner appends.
- A failed pass aborts the transaction. Partial writes lie beyond committed
  length; the next attempt overwrites its new valid rows, and any remaining
  stale tail stays masked.
- Cache-only prefill selects the latest owner, 14, as its last layer. That
  layer's projection roots contain K/V only, so its Q, attention, post stage,
  and PLE branch are correctly pruned. Layers 0–13 retain their complete post
  stages to produce layer 14's input. Later shared layers have no new K/V to
  populate. The full global PLE FC still preserves its quantization boundary.
- Chunked prefill processes all prompt tokens except the reserved final token,
  commits each valid chunk, then runs the reserved token with the decode
  signature. Partial chunks append only their real rows. Remaining query rows
  are padded and do not contribute cache rows; FCs/norms and attention operate
  per query row, so these unused rows do not mix into real rows.

## Alignment, masks, and reshape

For a chunk starting at `start` with `count` valid rows, let `end=start+count`.
For local attention, the borrowed start is the alignment-rounded-down value of
`max(0,start-window+1)`; global attention starts at zero. The end is rounded up.
For each real query row `r`, the only unmasked positions are
`max(0,start+r-window+1)..start+r` (or `0..start+r` globally).

Consequently both the added left prefix and padded right tail remain masked.
Every real query retains its current token. The borrowed span contains the
entire required interval, and the mask index is within its extent. Capacity
must divide by the configured alignment and `end` cannot exceed capacity, so
rounding the end up stays within the allocation. `PaddedKeys/PaddedValues`
validate the logical prefix and allocation bound independently; padding may
contain initialized stale codes and must not be interpreted as valid history.

The stage reshapes K, V, and mask together before every invocation. Q has the
fixed signature's head-folded row count. NnpackRunner then propagates runtime
shapes and grows owning output buffers before binding the external values.
The fixed-width diagnostic requires alignment 1 and zero-fills its copied
suffix; its maximum local width is `window+rows-1`.

This proves the intended visibility intervals, not bitwise equality between
different attention widths. Softmax reduction rounding can change with the
extent. Alignment 32 must retain its empirical numerical qualification; this
review does not establish bitwise parity for all positions and configurations.

## Buffer and resource lifetimes

- `BindFrom` deliberately stores a non-owning view. The source runner retains
  its owning output allocation, and it is neither rerun nor reshaped before
  all consumers finish. In particular, the previous hidden output remains
  live across the projection, attention, and post stages.
- Preprocess outputs live through the whole layer loop. Projection Q lives
  through its attention; new K/V are copied into the bank before proceeding.
  Attention output lives through the post stage. The final post output lives
  through the tail. Fixed-width temporary buffers and mask vectors surround
  the synchronous attention invocation. Embedding, PLE and position vectors
  surround all invocations that borrow them.
- Bank allocations never resize. Their pointers remain allocated throughout
  the case. Dangling input views may remain stored after a case finishes, but
  every required input is rebound before a subsequent successful Run. Teardown
  does not invoke those graphs or read their external data.
- [StageRunner](stage_runner.h) destroys its runtime before its graph/buffers
  and never destroys borrowed resources. `LiveRuntime` declares cache, then
  pool, then signatures; reverse destruction destroys both signatures before
  the pool/cache. The loaded coefficient owner outlives the LiveRuntime.

## Diagnostic limitations worth preserving

1. `TraceStage` filenames contain absolute position and tensor tag, but no
   case/run identity. Multiple cases, warmups or repeats hitting the same
   position overwrite earlier traces. Use one case, zero warmups and one
   measured run per trace directory, or extend the filenames before relying on
   traces from a broader invocation.
2. Per-run JSON records `prefill_rows` and capacity, but does not record
   `kv_alignment`, `fixed_attention_extent`, or `trace_position`. Keep the
   launch arguments and source/binary hashes with captures. Traced/audited
   runs are correctness captures, not timing evidence.
3. The graph cuts assume the validated E2B configuration and producer ordering;
   they are not a generic implementation for arbitrary Gemma sharing patterns
   or a configuration without PLE. No such generality is claimed here.

## Reviewed source identities

| File | SHA-256 |
| --- | --- |
| `live-main.cc` | `2afc28de0eb0a711ae2dbbdea0c045530fcfa68fcbac36c0f248c6ae68ef162a` |
| `stage_runner.h` | `0397f878f7d7a84347ef9b9f0afa524f6966128c23dde56e11a64095869dcc2f` |
| `active_kv_bank.h` | `54bbe04e22a6e6ca2152569cddaee4969f8a749da1573d85609244ee458c16eb` |
| `active_runtime_audit.h` | `12a0d1f351c4053c7ed6592c257466f2c13b70f1b260f0662821a3ea5769bd22` |
| `helpers/active_graph_context.h` | `0217bd253a54bc1eb99ab06ca3f4a25af0ec583203c68c83964d63a06c45b119` |
| `helpers/attention.h` | `bc7c3717cac50bbc58836d46968268a8416b4d9a39106e7e7384030483419c8f` |
| `gemma4_graph.h` | `8f6c5da80ba2b13f415ec1514b3dc0d1b84f4905e639f6368a40d5782083f846` |

The final three entries are under `overlay/litert/tensor/examples/gemma4/`.
