# Gemma4 E2B with active KV extents

This local experiment replaces the frozen native adapter's full-capacity KV
updates with persistent token-major INT8 storage and attention over the active
history. It uses the same published Gemma4 E2B weights and KV scales as the
LiteRT-LM CPU comparison. It runs through the XNNPACK tensor API without linking
LiteRT-LM into the candidate executable.

The frozen v4 Android binary, with 32-position KV alignment and 128-row prefill
chunks, matches **199/199 full-logit vectors bitwise** against same-phone
LiteRT-LM CPU references in the [final correctness report](FINAL_CORRECTNESS.json).
This covers the tested histories and configurations, not universal numerical
equivalence or model quality. The completed ten-cell phone benchmark finds
higher median decode throughput and lower first-logit latency with v4 in every
cell. A separate completed follow-up increases allocation capacity by 16× while
holding live history fixed; attention time changes by +8.25% on TECNO and
−0.84% on Pixel, rather than scaling with allocation size.
Correctness-capture timings include diagnostics and must not be presented as
benchmark results. Linux was used for builds, focused
correctness tests, and a three-logit
smoke test. No Linux host performance tests or Samsung S25 commands are part of
this experiment. Authorized phones are TECNO LJ9 and Pixel 8 only.

## What changes

Prefill token rows and attention KV columns are separate dimensions. The
previous native adapter chose a 128-row or 1024-row prefill signature, so a
512-token prompt used the larger signature. This implementation supports
repeated 128-row prefill chunks, while separately reshaping attention to the
live KV extent. Only the final partial chunk pads its unused token rows.

Both K and V now use `[capacity,D]` INT8 storage. Previously V used
`[D,capacity]`, which prevented a contiguous prefix view of the active tokens.
The new layout lets both tensors expose `[active_tokens,D]` by borrowing their
existing storage. It removes the adapter's full-bank mask algebra, alternating
full-cache output banks, and separate local-window gathers. It does not remove
all XNNPACK-internal cache copying and packing.

## Implementation map

| Component | Responsibility |
| --- | --- |
| [live-main.cc](live-main.cc) | Loads matched weights, constructs staged prefill/decode signatures, schedules layer execution, appends KV, builds attention masks, and writes captures. |
| [active_kv_bank.h](active_kv_bank.h) | Owns one K and one V allocation per distinct KV owner, tracks logical length, and exposes checked active or padded views. |
| [stage_runner.h](stage_runner.h) | Derives from `NnpackRunner` to execute stages using one borrowed thread pool and weights cache. Propagates external input shapes through XNNPACK on each invocation. |
| [active_graph_context.h](overlay/litert/tensor/examples/gemma4/helpers/active_graph_context.h) | Records explicit graph boundaries for hidden states, Q, newly quantized K/V, attention outputs, and post-attention outputs. Its thread-local context is used only while authoring a graph. |
| [gemma4_graph.h](overlay/litert/tensor/examples/gemma4/gemma4_graph.h), [attention.h](overlay/litert/tensor/examples/gemma4/helpers/attention.h) | Local overlays that author the original model operations with the recorded stage boundaries. |
| [matched_bundle_loader.h](matched_bundle_loader.h), [published_kv_specs.inc](overlay/litert/tensor/examples/gemma4/helpers/published_kv_specs.inc) | Load the actual bundle export and preserve the published integer coefficients and FP32 quantization metadata. |
| [active_runtime_audit.h](active_runtime_audit.h) | Checks executed attention operand types and extents during captures: FP32 activations, INT8 KV, and FP32/QC8W BMM without materialized FP32 KV. |
| [build-probe.py](build-probe.py) | Reuses existing archived compile/link commands and libraries, placing local overlays first in the include path. |
| [phone_runs.py](phone_runs.py) | Captures only the two allowlisted phones, checks binary/fixture hashes, pins CPU affinity, and preserves command and device-state records. |
| [validation/](validation/README.md) | Exact token fixtures, frozen-reference inventory, full-logit comparison, and cache-layout comparison tools. |

[benchmark-main.cc](benchmark-main.cc) is the copied frozen-window driver kept
as a reference. The live experiment's entry point is `live-main.cc`.

## Execution and ownership

`CreateLiveRuntime` creates one thread pool and one XNNPACK weights cache,
prepares the prefill/decode stages, then finalizes the weights cache. All stages
borrow these resources; stages are destroyed before the pool or cache. Model
weight storage stays alive until all runtimes have finished using it.

For each token chunk, `RunLiveTokens` performs the following sequence:

1. Begin a KV append transaction and prepare token embeddings, per-layer
   embeddings, and absolute RoPE positions.
2. Run each layer's projection stage to produce Q and, for KV owner layers,
   the new quantized K/V rows. Append only the valid new rows to that owner.
3. Reshape and bind attention's active K/V views and mask. Compute
   `softmax(Q Kᵀ + mask) V`, including the model's soft-cap operations.
4. Run the layer's output projection, residual, feed-forward, and per-layer
   embedding work. Feed its hidden state to the next stage through borrowed
   output storage.
5. Commit the KV length after every owner has appended. A failure aborts the
   pending transaction, preserving the previously committed prefix.

Prefill reserves the prompt's final token for a decode invocation that produces
the first logits. Cache-only prefill stops after producing the last distinct
owner's K/V; shared-KV consumer layers need no additional persistent cache
state. Decode executes all layers and the logits head. The authored-work audit
expects 129 FC/28 BMM nodes for cache-only prefill and 277 FC/70 BMM for decode.

There are 15 distinct KV owners. One logical bank at capacity 2048 holds
18874368 INT8 bytes, plus `XNN_EXTRA_BYTES` after each of its 30 allocations.
Shared consumer layers reference their owner's storage without appending a
second copy. New rows become visible to that owner's attention immediately
after `Append`, before the global `Commit`.

`Reset` invalidates history without clearing its bytes. `Abort` similarly
invalidates pending rows. Previously returned logical views must not be reused
after these changes. The current full-model driver allocates a new bank per
case/repetition; `--reuse_runtimes=true` reuses compiled stages, not session KV
storage. Cache reset/abort reuse is covered separately by the cache-manager
tests. The bank's initial allocation and zeroing still contribute to the
first-logit pass.

### Aligned active views

With alignment `A`, global attention uses `ceil(T/A)*A` positions at logical
history length `T`. Local attention rounds its window start down and its end
up, then masks all positions outside each query's actual causal window. For
single-token decode after 512 tokens and `A=32`, the local operand width is 512
when `T` is a multiple of 32, otherwise 544. This remains independent of the
2048-position allocation capacity.

`PaddedKeys` and `PaddedValues` return borrowed storage through the aligned end.
The extra positions can contain stale codes from earlier sessions or aborted
appends. **Every extra position must be masked.** The views neither clear the
tail nor make it valid history. No full-prefix copy is needed for this aligned
mode. Alignment must be a power of two from 1 through 128 and divide capacity.

## Variants and evidence

Keep binary hashes and capture commands with every result. Rebuilding the
unversioned executable does not recreate an older frozen binary.

| Variant | Behavior | Evidence and remaining scope |
| --- | --- | --- |
| v1: [source](live-main.v1.cc), [manifest](v1-source-manifest.json) | Exact active extents; default 128-row prefill chunks. | Three Linux smoke vectors match the frozen native adapter. Both phone gates match 9/12 vectors; all three 1024-token-case vectors differ. |
| v1 with `--prefill_chunk_rows=1024` | Same active-cache implementation with the larger prefill signature. | [TECNO gate](tecno-gate-chunk1024.json) matches updated LiteRT-LM 12/12 bitwise. |
| v2 tracing and `--fixed_attention_extent=true` | Exposes stage-boundary traces. The diagnostic width option copies active INT8 rows into zero-filled temporary fixed-width operands. | [Pixel 8 long-continuation comparison](pixel-fixed512-vs-tecno-native.json) matches the frozen TECNO native adapter 65/65 bitwise. It still matches the saved LiteRT-LM reference only [63/65](pixel-fixed512-vs-tecno-litertlm.json), reproducing the pre-existing frozen-native discrepancy. This diagnostic is not the efficient active-view path. |
| v3: [source](live-main.v3.cc) | Borrowed views with aligned start/end and mandatory masking; flag default remains 1 in this frozen version. Tested with `--kv_alignment=32`. | [TECNO gate](aligned32-gate.json) matches updated LiteRT-LM 12/12 bitwise. [Pixel 8 512+64](aligned32-long512.json) matches the saved TECNO LiteRT-LM reference 65/65 bitwise, including the earlier differing rows. This historical comparison used a different phone's reference; the v4 campaign below adds the same-phone comparison. |
| v4: [source](live-main.v4.cc), [manifest](v4-source-manifest.json) | Makes alignment 32 the default and preserves the aligned-view implementation. This is also the current `live-main.cc` default. | [Final correctness](FINAL_CORRECTNESS.json): 199/199 full-logit vectors bitwise equal to same-phone LiteRT-LM CPU references. [Phone benchmark](analysis/results/SUMMARY.md): higher median decode throughput and lower first-logit latency in all ten cells. |

The [original Linux smoke comparison](linux-smoke-comparison.json) and the
[final-build Linux smoke](linux-final-smoke-comparison.json) each match three
logit vectors against the frozen native adapter. These are correctness checks,
not host benchmarks or broad model evaluations. The isolated attention test
passed 84 cases on [TECNO](active_attention_test.tecno.log) and
[Pixel 8](active_attention_test.pixel8.log), with old/new V layouts bitwise equal
at otherwise matched arithmetic shapes. It also tests grow/shrink, local/global
attention, dimensions 256/512, and allocation capacities 2048/4096. Some
folded-versus-broadcast head-shape comparisons have small ARM rounding
differences; the layout result does not imply all arithmetic shapes are bitwise
equivalent.

The current cache-manager test passes 323 checks on Linux, including padded-view
bounds and stale-tail contracts. The same extended test also passes on
[TECNO](tecno-active_kv_bank_test_v4.android.log) and
[Pixel 8](pixel8-active_kv_bank_test_v4.android.log). Older unversioned phone test
logs retain the earlier 285-check result.

### Final v4 correctness

[FINAL_CORRECTNESS.json](FINAL_CORRECTNESS.json) aggregates nine comparisons:

| Coverage | TECNO vectors | Pixel 8 vectors |
| --- | ---: | ---: |
| 128/512/1024-token gate and repeated short case, two threads | 12 | 12 |
| Same gate, four threads | 12 | 12 |
| 512-token prompt plus 64 forced decode calls | 65 | 65 |
| Boundaries crossing 1024 and reaching capacity 2048 | 8 | 8 |
| Historical local-window boundary, lengths 510 through 514 | 5 | — |
| **Total, all bitwise equal** | **102** | **97** |

All references use LiteRT-LM CPU on the candidate's phone. The Pixel 8 long
continuation and both phones' long-boundary references were captured for this
campaign. The earlier positions 520 and 536 that differed in the frozen native
adapter now match the complete LiteRT-LM logit vectors on both phones. This is
an observed result of the v4 configuration; alignment is not a promise that
every untested history or arithmetic shape will be bitwise equal.

Both phones also completed 2,584 numerical extent comparisons in
[active_extent_rounding_test.cc](active_extent_rounding_test.cc), with records
for [TECNO](tecno-active_extent_rounding_test.android.log) and
[Pixel 8](pixel8-active_extent_rounding_test.android.log). Those diagnostics
include configurations that deliberately expose small shape-dependent rounding
differences; a successful diagnostic run does not mean all 2,584 cases are
bitwise equal. Each phone separately passed all 323 cache-manager checks.
The full-model report compares logits, not captured K/V bytes from the final
LiteRT-LM reference. Cache-manager tests and runtime INT8/extent audits provide
separate evidence about storage and execution.

### Traced numerical differences

[rounding-boundary-traces.json](rounding-boundary-traces.json) records concrete
FP32 attention differences of at most `3.5762786865234375e-7` at the investigated
boundaries. These straddle subsequent activation-quantization thresholds:

* Pixel 8, position 528/layer 29/channel 2551: scaled values around 7.5 produce
  INT8 codes 8 versus 7.
* TECNO, position 553/layer 2/channel 897: scaled values around 9.5 produce
  codes 10 versus 9.

The JSON initially describes a reconstructed rounding calculation. The
[actual XNNPACK quantization test](quantization_boundary_test.tecno.log)
subsequently reproduced both code pairs on TECNO. This explains the inspected
amplification points; it does not establish that every untested context or
configuration is correct. The [cache trace analysis](validation/README.md)
records how these differences spread through later owners.

## Build and correctness reproduction

This is an artifact build, not a standalone checkout. It requires the existing
Linux and Android build trees at `/tmp/gemma4-local-port-nggiqf9x/{linux,android}`,
their `compile_commands.json`, Ninja build descriptions, and archived libraries,
plus the source checkout at `/data/bt/os/xnnpack`. The Android commands currently
use NDK `27.3.13750724` from the path recorded in the build metadata.
`build-probe.py` does not download dependencies or reconfigure the SDK/NDK.
`ANDROID_HOME` supplies the SDK path for ADB operations.

```bash
experiment=/data/bt/tmp/gemma4-live-kv-20260913
python3 "$experiment/build-probe.py" android "$experiment/live-main.cc"
python3 "$experiment/build-probe.py" linux "$experiment/active_kv_bank_test.cc"
python3 "$experiment/build-probe.py" android "$experiment/active_kv_bank_test.cc"
"$experiment/active_kv_bank_test.linux"
```

These commands compile a local driver and helper object against the existing
archives. They write adjacent executables, objects, `.build.log`, and
`.commands.json` files, including source/overlay hashes. The recorded builds
and Linux cache test completed successfully. The unversioned Linux full-model
executable has also been rebuilt with the final implementation, and its three
smoke vectors match the frozen native reference bitwise. Consult each platform's
build metadata and hashes when identifying binaries; a shared base name alone
does not establish matching sources.

The phones already hold the verified bundle export at
`/data/local/tmp/gemma4-phone-perf-20260913/matched-bundle`. The local export is
`/tmp/gemma4-local-port-nggiqf9x/replacement-comparison/matched-bundle`.
Use raw token fixtures, zero warmups, one measured run, and full logits for
focused correctness captures. The final reused-runtime gate additionally uses
one warmup per case. The following illustrates the frozen v4 capture protocol with a
fresh output tag; do not run it concurrently with another workload on that phone:

```bash
adb="$ANDROID_HOME/platform-tools/adb"
serial=144512553T000099
remote=/data/local/tmp/gemma4-phone-perf-20260913
"$adb" -s "$serial" push "$experiment/live-main.v4.android" "$remote/live-int8-v4.android"
"$adb" -s "$serial" shell chmod 755 "$remote/live-int8-v4.android"
cd "$experiment"
python3 - <<'PY'
from pathlib import Path
import phone_runs
phone_runs.EXTRA_FLAGS['final'] = ['--kv_alignment=32', '--prefill_chunk_rows=128']
phone_runs.run_capture('tecno', 'final', Path('fixtures/gate.tsv'),
                       'readme_gate_v4', threads=2, reuse=True,
                       warmups=0, runs=1, dump=True)
PY
```

The driver/controller combination was exercised in the saved capture records;
the fresh `readme_gate_v4` tag is an illustrative rerun, not a claim
that another run was performed. For Pixel 8, use serial `3A111FDJH005A0` and
device `pixel8`; the controller applies mask `180` instead of TECNO's `c0`.
The controller rejects existing output tags and binaries with unexpected hashes.
Its backend-to-binary mapping must match the intended frozen version when
repeating v4 or later captures.

Compare saved results without running a model:

```bash
analysis_python=/data/home/chasun/src/litert-converter/.venv/bin/python
baseline=/data/bt/tmp/gemma4-phone-perf-20260913/tecno/runs/gate_litertlm_fresh_t2
candidate="$experiment/tecno/runs/aligned32_gate_v3"
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 "$analysis_python" \
  "$experiment/validation/compare_live.py" "$baseline" "$candidate" \
  --output "$experiment/validation/aligned_gate_comparison.json"
```

[validation/README.md](validation/README.md) lists exact fixtures, the historical
reference inventory, subset comparison, and cache layouts. The final v4 report
above supersedes that inventory's missing Pixel long-continuation and
long-boundary references. Comparison success means the diagnostic completed; it is not a model
quality acceptance result. Add `--require-bitwise` only when exact equality is
the intended check. `--dump_cache=true` and `--trace_position=N` provide optional
state/stage captures; keep these disabled for any later benchmark.

Recheck the saved final campaign, without model execution or devices:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 "$analysis_python" \
  "$experiment/check_final_correctness.py"
```

This command completed with 199/199 bitwise-equal vectors. It rewrites the nine
comparison JSON files and `FINAL_CORRECTNESS.json` from the saved captures.

## Phone performance

[run_perf.py](run_perf.py) requires a passed final correctness report, then runs
five cells per phone: prompt lengths 128, 512, and 1024 at two threads, plus 128
and 1024 at four threads. Each cell has four process blocks in LiteRT-LM, v4,
v4, LiteRT-LM order. Each process uses one warmup and three measured sessions,
64 forced decode calls, reused runtimes, and disabled full-logit dumps. The
completed matrix totals 40 process blocks, 120 measured sessions, and 7,680
measured decode calls across TECNO and Pixel 8. The
[analysis validation](analysis/results/validation.json) passed with every cell
complete and no partial-results option.

The [capture controller](phone_runs.py) records commands, hashes, CPU affinity,
thermal state, and process memory/fault samples. Compare inclusive `elapsed_ms`
for decode and the complete first-logit pass; the two adapters' internal
`forward_ms` fields have different scopes. The first-logit measurement includes
session allocation, chunked prefill, and the reserved final token's decode; it
excludes model loading, runtime construction, tokenization, and sampling.

The table reports medians of six measured sessions per backend. Each session's
decode rate is `64 * 1000 / sum(decode elapsed_ms)`. V4 retains INT8 KV at
capacity 2048, with alignment 32 and 128-row prefill chunks.

| Phone | Threads | Prompt tokens | LiteRT-LM decode (tok/s) | Native v4 decode (tok/s) | First logits, LM / v4 (s) |
| --- | ---: | ---: | ---: | ---: | ---: |
| TECNO LJ9 | 2 | 128 | 11.95 | 16.66 | 1.237 / 0.875 |
| TECNO LJ9 | 2 | 512 | 12.07 | 13.51 | 4.702 / 3.580 |
| TECNO LJ9 | 2 | 1024 | 12.07 | 12.72 | 12.148 / 7.861 |
| TECNO LJ9 | 4 | 128 | 19.44 | 22.67 | 0.665 / 0.379 |
| TECNO LJ9 | 4 | 1024 | 19.30 | 20.12 | 5.880 / 3.337 |
| Pixel 8 | 2 | 128 | 12.93 | 17.05 | 1.431 / 0.779 |
| Pixel 8 | 2 | 512 | 12.99 | 15.04 | 5.359 / 2.820 |
| Pixel 8 | 2 | 1024 | 13.06 | 14.43 | 10.275 / 6.400 |
| Pixel 8 | 4 | 128 | 17.18 | 20.75 | 0.979 / 0.543 |
| Pixel 8 | 4 | 1024 | 16.98 | 19.22 | 8.101 / 4.050 |

V4's median decode advantage ranges from 4.3% to 39.3% in these cells. At 512
tokens both runners now use four 128-row prefill calls. At 1024 tokens v4 uses
eight 128-row calls while LiteRT-LM selects its 1024-row signature. Both reserve
the final prompt token for decode, leaving one unused row in their last prefill
call. This compares complete adapters, including their different scheduling.

See the [complete results](analysis/results/SUMMARY.md),
[machine-readable report](analysis/results/summary.json), and
[throughput chart](analysis/results/decode-throughput.svg) for session ranges,
process medians, and telemetry. Process blocks are the independent repetition
unit; token timings within a session are correlated. Frequencies were not fixed
and phones warmed during captures despite passive cooling before each block.
Three Pixel blocks show increased major-fault counters over sampled process
intervals, which include setup and warmup as well as inference; their exact
phase is unknown. Small differences need that variability context.

Memory remains a limitation: median process-lifetime peak RSS across the cells
is about 2.58–2.72 GiB for v4 versus 1.50–2.07 GiB for LiteRT-LM. This includes
weights, runtime construction, and warmup, rather than measuring KV storage
alone. The new single bank does not remove the copied adapter's widened weights
or all runtime allocation and packing costs.

### Reproduce the performance analysis

These commands analyze saved captures only. Both the summary and chart command
completed successfully for the main matrix:

```bash
python3 "$experiment/analysis/summarize.py"
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  uv run --no-project --with matplotlib python \
  "$experiment/analysis/summarize.py" --chart
```

The original controller is retained as
[phone_runs.v4-main-capture.py](phone_runs.v4-main-capture.py); all 40 capture
records contain its hash. The current `phone_runs.py` pins its expected final
binary hash to `live-main.v4.android`, so later unversioned rebuilds cannot
silently change the v4 reference.

To repeat the matrix, use a fresh host directory and unique remote capture
tags. The following is an illustrative rerun, not an additional executed
benchmark. It assumes the verified LiteRT-LM/v4 executables, model, and matched
bundle already occupy the recorded remote directory on both allowlisted phones.
`ANDROID_HOME` must identify the SDK. Run it only when those phones are free:

```bash
capture=$(mktemp -d /data/bt/tmp/gemma4-live-kv-rerun.XXXXXX)
cp "$experiment/phone_runs.py" "$experiment/FINAL_CORRECTNESS.json" "$capture/"
cp -R "$experiment/fixtures" "$capture/fixtures"
for version in 1 2 3 4; do
  ln -s "$experiment/live-main.v$version.android" "$capture/"
done
cd "$capture"
python3 - <<'PY'
import json
import phone_runs as r

assert json.loads((r.ROOT / 'FINAL_CORRECTNESS.json').read_text())['status'] == 'passed'
namespace = r.ROOT.name.replace('.', '_')
for device in ('tecno', 'pixel8'):
    for length, threads in ((128, 2), (512, 2), (1024, 2), (128, 4), (1024, 4)):
        cell = f'p{length}_t{threads}'
        for block, backend in enumerate(('litertlm', 'final', 'final', 'litertlm')):
            r.run_capture(device, backend, r.ROOT / 'fixtures' / f'performance_{length}_64.tsv',
                          f'{namespace}_{cell}_b{block}_{backend}', threads=threads,
                          phase='benchmark', reuse=True, warmups=1, runs=3, dump=False,
                          cell=cell, block_index=block)
PY
python3 "$experiment/analysis/summarize.py" --root "$capture"
```

The fresh controller borrows the frozen local executables only for hash checks;
it uses the verified remote executables for inference. It preserves original
captures and does not mix two repetitions into one analysis root. The example's
40 capture argument sets and copied fixture manifest were checked with ADB
intercepted before execution; no extra model or device run was performed. The
[dry-validation record](README_RERUN_VALIDATION.json) preserves the checked
snippet/controller hashes and the limits of that check.

### Allocation-capacity follow-up

The separate [capacity driver](capacity/run.py) holds the 128-token prompt,
64-token forced continuation, two-thread configuration, and v4 binary fixed.
It compares allocation capacities 256 and 4096 in four blocks ordered 256,
4096, 4096, 256, with one warmup and three measured sessions per block on each
phone. All eight process blocks, 24 measured sessions, and 1,536 measured decode
calls completed and passed [validation](capacity/results/validation.json).

| Phone | Allocated tokens | Decode (tok/s) | Attention (ms/token) |
| --- | ---: | ---: | ---: |
| TECNO LJ9 | 256 | 16.661 | 4.3639 |
| TECNO LJ9 | 4096 | 15.909 | 4.7238 |
| Pixel 8 | 256 | 16.848 | 3.6877 |
| Pixel 8 | 4096 | 17.167 | 3.6568 |

Values are medians of six sessions per capacity. Live history advances from
128 to 192 tokens in both allocations. The attention metric includes runtime
reshape/setup, INT8 adapters, and packing; it is not an isolated kernel timer.
Increasing allocation by 16× changes median decode throughput by −4.51% on
TECNO and +1.89% on Pixel. Attention time changes by +8.25% and −0.84%,
respectively. These descriptive repetitions under normal DVFS do not establish
perfectly capacity-independent latency. Together with the checked live operand
extents, they show that this path avoids work proportional to the unused
allocation for the tested history. Allocation/zeroing before the first logits
and total memory still scale with capacity.

Both capacities match all 65 same-phone LiteRT-LM argmax positions on each
phone; this follow-up has no full-logit dumps. The
[complete capacity results](capacity/results/SUMMARY.md) retain process medians,
session ranges, first-logit measurements, memory, and thermal observations.
Reanalyze them without inference or devices:

```bash
python3 "$experiment/capacity/analysis.py"
```

This analysis command completed successfully on the saved eight-process set.

## Remaining work and costs

The executed attention graphs still include QS8-to-QC8 adapters, which copy
active INT8 bytes and attach channelwise scale metadata. Both dynamic BMMs also
pack their right-hand operands. Shared KV owners can therefore be repacked for
multiple consumer layers. The runtime audit proves the selected INT8 operand
extents and excludes materialized FP32 KV; it does not prove zero cache traffic.

Staged execution also introduces repeated external binding/reshape/setup,
mask creation, and stage invocation costs. Fixed prefill signatures still
compute their last chunk's padded token rows. Session allocation still clears
the full-capacity backing storage once, and the copied weight adapter still
widens some published INT2 weights to INT4. None of these costs has been removed
merely by changing the cache layout.

The final same-phone correctness gate and ten-cell performance matrix are
complete. The recorded results support this v4 configuration as a promising
replacement candidate; broader quality evaluation and memory optimization
remain separate work. The allocation-capacity follow-up also completed, with
the measured variation and setup-cost qualifications described above.
