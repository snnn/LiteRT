#!/usr/bin/env python3
"""Controlled Gemma4 captures on the explicitly authorized Android phones."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shlex
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REMOTE = '/data/local/tmp/gemma4-phone-perf-20260913'
DEVICES = {
    'tecno': {'serial': '144512553T000099', 'masks': {2: 'c0', 4: 'f0'}, 'policies': [0, 4, 7]},
    'pixel8': {'serial': '3A111FDJH005A0', 'masks': {2: '180', 4: '1e0'}, 'policies': [0, 4, 8]},
}
EXTRA_FLAGS = {}
BINARIES = {'litertlm': 'litertlm-pr9918.android', 'native': 'xnnpack-window.android', 'live': 'live-int8-v1.android', 'trace': 'live-int8-trace.android', 'aligned': 'live-int8-v3.android', 'final': 'live-int8-v4.android'}
EXPECTED_BINARY_SHA = {
    'final': hashlib.sha256((ROOT / 'live-main.v4.android').read_bytes()).hexdigest(),
    'aligned': __import__('hashlib').sha256((ROOT / 'live-main.v3.android').read_bytes()).hexdigest(),
    'trace': __import__('hashlib').sha256((ROOT / 'live-main.v2.android').read_bytes()).hexdigest(),
    'live': __import__('hashlib').sha256((ROOT / 'live-main.v1.android').read_bytes()).hexdigest(),
    'litertlm': 'fdfbd3dee9ff4ee409319486a4c3874797a7ee8a173fa76fe7322d636efd29a1',
    'native': 'a74cce7cbd50eaa400a00cbda3c11b21d54b194b33338b05556233da802c447b',
}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def adb(device, arguments, check=True):
    spec = DEVICES[device]
    sdk = Path(os.environ.get('ANDROID_HOME', '/data/bt/os/android_sdk'))
    command = [str(sdk / 'platform-tools/adb'), '-s', spec['serial'], *arguments]
    result = subprocess.run(command, text=True, capture_output=True)
    if check and result.returncode:
        raise RuntimeError(shlex.join(command) + '\n' + result.stdout + result.stderr)
    return result


def telemetry(device):
    data = {'host_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    for name, command in [('battery', ['dumpsys', 'battery']),
                          ('thermal', ['dumpsys', 'thermalservice']),
                          ('memory', ['cat', '/proc/meminfo'])]:
        result = adb(device, ['shell', *command], check=False)
        data[name + '_raw'] = result.stdout
        data[name + '_returncode'] = result.returncode
    match = re.search(r'^\s*Thermal Status:\s*(\d+)', data['thermal_raw'], re.M)
    data['thermal_status'] = int(match.group(1)) if match else None
    live = data['thermal_raw'].split('Current temperatures from HAL:', 1)
    live = live[1].split('Current cooling devices', 1)[0] if len(live) == 2 else ''
    temperatures = []
    for value, kind, name, status in re.findall(
        r'Temperature\{mValue=([^,]+), mType=(\d+), mName=([^,]+), mStatus=(\d+)\}', live):
        value = float(value)
        if math.isfinite(value):
            temperatures.append({'celsius': value, 'type': int(kind), 'name': name, 'status': int(status)})
    data['current_hal_temperatures'] = temperatures
    for field, kind in [('cpu_c', 0), ('battery_c', 2), ('skin_c', 3)]:
        values = [row['celsius'] for row in temperatures if row['type'] == kind]
        data[field] = max(values) if values else None
    for field in ['level', 'temperature']:
        match = re.search(r'^\s*' + field + r':\s*(\d+)', data['battery_raw'], re.M)
        data['battery_' + field] = int(match.group(1)) if match else None
    paths = [f'/sys/devices/system/cpu/cpufreq/policy{n}/scaling_cur_freq' for n in DEVICES[device]['policies']]
    result = adb(device, ['shell', 'cat', *paths], check=False)
    data['frequency_policies'] = DEVICES[device]['policies']
    data['frequency_raw'] = result.stdout
    return data


def ready(data):
    if data['thermal_status'] not in (None, 0):
        return False
    for field, limit in [('cpu_c', 50), ('skin_c', 35), ('battery_c', 35)]:
        value = data[field]
        if field == 'battery_c' and value is None and data.get('battery_temperature') is not None:
            value = data['battery_temperature'] / 10
        if value is not None and value > limit:
            return False
    return True


def run_capture(device, backend, fixture, tag, threads=2, phase='correctness',
                reuse=False, warmups=0, runs=1, dump=True, cell=None, block_index=None):
    if device not in DEVICES or backend not in BINARIES or threads not in (2, 4):
        raise ValueError('Unsupported device/backend/thread configuration')
    if not re.fullmatch(r'[A-Za-z0-9_-]+', tag):
        raise ValueError('Unsafe capture tag')
    fixture = Path(fixture).resolve(strict=True)
    if fixture.parent != (ROOT / 'fixtures').resolve():
        raise ValueError('Fixture must belong to this experiment')
    rows = [line.split('\t') for line in fixture.read_text().splitlines() if line and not line.startswith('#')]
    if phase == 'benchmark' and (len(rows) != 1 or not reuse or warmups != 1 or runs != 3 or dump):
        raise ValueError('Benchmark requires one case, reused runtimes, one warmup, three runs, no dumps')
    directory = ROOT / device / 'runs'
    directory.mkdir(parents=True, exist_ok=True)
    output = directory / tag
    record_path = directory / (tag + '.command.json')
    if output.exists() or record_path.exists():
        raise RuntimeError('Refusing to replace a previous capture')
    remote_output = REMOTE + '/runs/' + tag
    remote_log = REMOTE + '/logs/' + tag + '.log'
    remote_pid = REMOTE + '/logs/' + tag + '.pid'
    remote_fixture = REMOTE + '/fixtures/' + fixture.name
    binary = REMOTE + '/' + BINARIES[backend]
    record = {'status': 'preparing', 'device': device, 'serial': DEVICES[device]['serial'],
              'backend': backend, 'phase': phase, 'tag': tag, 'cell': cell,
              'block_index': block_index, 'order': ['litertlm', 'final', 'final', 'litertlm'],
              'num_threads': threads, 'affinity': DEVICES[device]['masks'][threads],
              'warmup_runs': warmups, 'measured_runs': runs, 'reuse_runtimes': reuse,
              'dump_full_logits': dump, 'timings_valid_for_benchmark': phase == 'benchmark',
              'fixture_file': str(fixture), 'fixture_sha256': sha(fixture),
              'controller_sha256': sha(Path(__file__).resolve()),
              'output_directory': str(output), 'remote_output_directory': remote_output,
              'prompt_length': len(rows[0][1].split(',')) if len(rows) == 1 else None,
              'forced_tokens': len(rows[0][2].split(',')) if len(rows) == 1 else None,
              'cooldown_samples': [], 'process_samples': []}
    def save():
        record_path.write_text(json.dumps(record, indent=2) + '\n')
    try:
        adb(device, ['shell', 'test ! -e ' + shlex.quote(remote_output)])
        adb(device, ['shell', 'mkdir', '-p', REMOTE + '/runs', REMOTE + '/logs', REMOTE + '/fixtures'])
        adb(device, ['push', str(fixture), remote_fixture])
        actual = adb(device, ['shell', 'sha256sum', binary]).stdout.split()[0]
        if actual != EXPECTED_BINARY_SHA[backend]:
            raise RuntimeError('Executable differs from the frozen correctness build')
        record['binary_sha256'] = actual
        actual = adb(device, ['shell', 'sha256sum', remote_fixture]).stdout.split()[0]
        if actual != record['fixture_sha256']:
            raise RuntimeError('Fixture transfer hash mismatch')
        if phase == 'benchmark':
            # Passive cooling; no governor, charging, display or thermal overrides.
            time.sleep(10)
            for attempt in range(21):
                state = telemetry(device)
                record['cooldown_samples'].append(state)
                save()
                if ready(state):
                    break
                if attempt == 20:
                    raise RuntimeError('Phone did not reach the recorded passive-cooling criteria')
                print(json.dumps({'device': device, 'tag': tag, 'status': 'cooling',
                                  'cpu_c': state['cpu_c'], 'skin_c': state['skin_c']}), flush=True)
                time.sleep(30)
        record['telemetry_before'] = telemetry(device)
        flags = ['taskset', record['affinity'], binary,
                 '--cases_file=' + remote_fixture, '--output_dir=' + remote_output,
                 '--num_threads=' + str(threads), '--warmup_runs=' + str(warmups),
                 '--measured_runs=' + str(runs), '--reuse_runtimes=' + str(reuse).lower(),
                 '--dump_full_logits=' + str(dump).lower()]
        if backend == 'litertlm':
            flags += ['--model_path=' + REMOTE + '/gemma-4-E2B-it.litertlm', '--max_num_tokens=2048']
        else:
            flags += ['--bundle_dir=' + REMOTE + '/matched-bundle']
        flags += EXTRA_FLAGS.get(backend, [])
        shell = ('echo $$ > ' + shlex.quote(remote_pid) + '; exec env LD_LIBRARY_PATH=' +
                 shlex.quote(REMOTE) + ' ' + shlex.join(flags) + ' > ' + shlex.quote(remote_log) + ' 2>&1')
        sdk = Path(os.environ.get('ANDROID_HOME', '/data/bt/os/android_sdk'))
        command = [str(sdk / 'platform-tools/adb'), '-s', DEVICES[device]['serial'], 'shell', shell]
        record['command'] = command
        record['status'] = 'running'
        save()
        print(json.dumps({'device': device, 'backend': backend, 'tag': tag, 'status': 'running'}), flush=True)
        start = time.monotonic()
        with (directory / (tag + '.transport.log')).open('w') as transport:
            process = subprocess.Popen(command, stdout=transport, stderr=subprocess.STDOUT)
            pid = None
            while True:
                try:
                    code = process.wait(timeout=10)
                    break
                except subprocess.TimeoutExpired:
                    if pid is None:
                        result = adb(device, ['shell', 'cat', remote_pid], check=False)
                        if result.stdout.strip().isdigit():
                            pid = result.stdout.strip()
                    if pid:
                        result = adb(device, ['shell', 'cat', '/proc/' + pid + '/stat', '/proc/' + pid + '/status'], check=False)
                        record['process_samples'].append({'elapsed_wall_seconds': time.monotonic() - start,
                                                         'pid': pid, 'returncode': result.returncode,
                                                         'proc_stat_and_status_raw': result.stdout})
                        save()
        record['process_returncode'] = code
        record['process_wall_seconds_including_setup_and_io'] = time.monotonic() - start
        record['telemetry_after'] = telemetry(device)
        adb(device, ['pull', remote_log, str(directory / (tag + '.log'))], check=False)
        if code:
            raise RuntimeError('Device process failed; inspect saved log')
        adb(device, ['pull', remote_output, str(output)])
        summary = json.loads((output / 'run.json').read_text())
        if summary.get('status') != 'completed':
            raise RuntimeError('Capture is incomplete')
        if phase == 'benchmark' and list(output.glob('*.f32')):
            raise RuntimeError('Logit dumps are forbidden in benchmark captures')
        record['status'] = 'completed'
        print(json.dumps({'device': device, 'backend': backend, 'tag': tag, 'status': 'completed'}), flush=True)
        return output
    except Exception as error:
        record['status'] = 'failed'
        record['error'] = str(error)
        raise
    finally:
        save()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('device', choices=DEVICES)
    parser.add_argument('backend', choices=BINARIES)
    parser.add_argument('fixture', type=Path)
    parser.add_argument('tag')
    parser.add_argument('--threads', type=int, choices=[2, 4], default=2)
    parser.add_argument('--reuse', action='store_true')
    parser.add_argument('--warmups', type=int, default=0)
    args = parser.parse_args()
    run_capture(args.device, args.backend, args.fixture, args.tag,
                threads=args.threads, reuse=args.reuse, warmups=args.warmups)
