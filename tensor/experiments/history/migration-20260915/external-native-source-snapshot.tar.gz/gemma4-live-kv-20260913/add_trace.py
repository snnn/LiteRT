from pathlib import Path
p=Path(__file__).parent/'live-main.cc';s=p.read_text()
s=s.replace('#include "stage_runner.h"','#include "stage_runner.h"\n#include "active_runtime_audit.h"',1)
s=s.replace('namespace litert::tensor::examples::gemma4 {','ABSL_FLAG(int, trace_position, -1, "Dump a selected absolute token position at existing stage boundaries.");\nABSL_FLAG(bool, fixed_attention_extent, false, "Diagnostic: restore fixed attention widths while retaining token-major caches.");\n\nnamespace litert::tensor::examples::gemma4 {',1)
anchor='struct StageTimes {'
helper='''absl::Status TraceStage(StageRunner& runner,const TensorHandle& handle,const std::string& tag,
    int rows,int row,int heads=1) {
  if(row<0||row>=rows)return absl::OkStatus();
  LRT_TENSOR_ASSIGN_OR_RETURN(auto data,runner.ReadOutput(handle));
  LRT_TENSOR_ASSIGN_OR_RETURN(auto index,runner.graph().Lookup(handle));
  const auto& info=runner.graph().values()[index].info;
  size_t elements=1;for(auto d:info.shape)elements*=d;
  size_t element_bytes=handle.GetType()==Type::kI8?1:4;
  size_t dim=elements/(rows*heads);
  const auto file=absl::GetFlag(FLAGS_output_dir)+"/trace."+std::to_string(absl::GetFlag(FLAGS_trace_position))+"."+tag;
  std::ofstream out(file,std::ios::binary);
  for(int h=0;h<heads;++h)out.write(reinterpret_cast<const char*>(data.data())+(size_t(h)*rows+row)*dim*element_bytes,dim*element_bytes);
  return out?absl::OkStatus():absl::InternalError("Trace write failed");
}
'''
s=s.replace(anchor,helper+anchor,1)
s=s.replace('  std::vector<float> positions(rows);','  const int trace_row=absl::GetFlag(FLAGS_trace_position)-start;\n  std::vector<float> positions(rows);',1)
anchor='    if(i==cut.owner) {\n      at=BenchClock::now();'
s=s.replace(anchor,'''    if(trace_row>=0&&trace_row<count) {
      if(sig.decode||i<sig.last_layer)LRT_TENSOR_RETURN_IF_ERROR(TraceStage(*stage.projection,cut.query,absl::StrCat("layer",i,".q.f32"),rows,trace_row,config.num_heads));
      if(i==cut.owner) {
        LRT_TENSOR_RETURN_IF_ERROR(TraceStage(*stage.projection,cut.new_key,absl::StrCat("layer",i,".k.i8"),rows,trace_row));
        LRT_TENSOR_RETURN_IF_ERROR(TraceStage(*stage.projection,cut.new_value,absl::StrCat("layer",i,".v.i8"),rows,trace_row));
      }
    }
'''+anchor,1)
s=s.replace('    int extent=end-begin;','''    int extent=end-begin;
    if(absl::GetFlag(FLAGS_fixed_attention_extent))extent=cut.global?bank.capacity():config.sliding_window_size+rows-1;''',1)
s=s.replace('    LRT_TENSOR_RETURN_IF_ERROR(attention.runner->SetInput(attention.k,kview));\n    LRT_TENSOR_RETURN_IF_ERROR(attention.runner->SetInput(attention.v,vview));','''    std::vector<int8_t> fixed_k,fixed_v;
    if(absl::GetFlag(FLAGS_fixed_attention_extent)) {
      fixed_k.resize(size_t(extent)*cut.dim);fixed_v.resize(fixed_k.size());
      std::copy(kview.begin(),kview.end(),fixed_k.begin());std::copy(vview.begin(),vview.end(),fixed_v.begin());
      kview=absl::MakeConstSpan(fixed_k);vview=absl::MakeConstSpan(fixed_v);
    }
    LRT_TENSOR_RETURN_IF_ERROR(attention.runner->SetInput(attention.k,kview));
    LRT_TENSOR_RETURN_IF_ERROR(attention.runner->SetInput(attention.v,vview));''',1)
anchor='    elapsed=Milliseconds(at);times.forward+=elapsed;times.attention+=elapsed;'
s=s.replace(anchor,anchor+'''
    if(absl::GetFlag(FLAGS_dump_full_logits))LRT_TENSOR_RETURN_IF_ERROR(AuditActiveAttention(attention.runner->runtime(),config.num_heads*rows,extent,cut.dim));
    if(trace_row>=0&&trace_row<count)LRT_TENSOR_RETURN_IF_ERROR(TraceStage(*attention.runner,attention.output,absl::StrCat("layer",i,".attention.f32"),rows,trace_row,config.num_heads));''',1)
anchor='    elapsed=Milliseconds(at);times.forward+=elapsed;times.post+=elapsed;'
s=s.replace(anchor,anchor+'''
    if(trace_row>=0&&trace_row<count)LRT_TENSOR_RETURN_IF_ERROR(TraceStage(*stage.post,cut.output,absl::StrCat("layer",i,".hidden.f32"),rows,trace_row));''',1)
p.write_text(s)
