// Local experiment only: XNNPACK tensor stages borrowing one pool/cache.
// This header adds a derived runner; it does not change existing library ABIs.
#ifndef GEMMA4_LIVE_KV_STAGE_RUNNER_H_
#define GEMMA4_LIVE_KV_STAGE_RUNNER_H_

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <utility>
#include <vector>

#include <pthreadpool.h>
#include "absl/container/flat_hash_map.h"
#include "absl/status/status.h"
#include "absl/status/statusor.h"
#include "absl/strings/str_format.h"
#include "absl/types/span.h"
#include "include/xnnpack.h"
#include "litert/tensor/backends/xnnpack/conversion.h"
#include "litert/tensor/backends/xnnpack/graph.h"
#include "litert/tensor/backends/xnnpack/utils.h"
#include "litert/tensor/buffer.h"
#include "litert/tensor/runners/common_nnpack/runner.h"
#include "litert/tensor/tensor.h"
#include "litert/tensor/utils/macros.h"

namespace litert::tensor {

// All stages may borrow the same caller-owned pthreadpool and weights cache.
// The caller must destroy every StageRunner before destroying either resource.
// nullptr means serial execution / no weights cache, respectively. The caller
// also controls cache finalization after preparing all runtimes that add weights.
// This class never creates, resizes, finalizes, or destroys those resources.
// Stage invocations and cache population are expected to be serialized.
//
// SetInput, ReadOutput, ReshapeInput, and Run retain NnpackRunner's contracts:
// non-copy inputs must remain live through Run; owning-output locks retain their
// storage, while caller-provided outputs retain the caller's lifetime obligation;
// external-value locks remain live through the synchronous runtime invocation.
class StageRunner final : public NnpackRunner {
 public:
  static absl::StatusOr<std::unique_ptr<StageRunner>> Create(
      std::vector<TensorHandle> outputs, pthreadpool_t pool,
      xnn_weights_cache_t weights, uint32_t runtime_flags = 0) {
    LRT_TENSOR_ASSIGN_OR_RETURN(auto graph,
                               BuildXnnpackGraph(std::move(outputs)));
    return std::unique_ptr<StageRunner>(
        new StageRunner(std::move(graph), pool, weights, runtime_flags));
  }

  // runtime_ is destroyed before the NnpackRunner graph/buffers. Borrowed
  // handles have no deleters, and remain valid for other stages afterward.
  ~StageRunner() override = default;
  StageRunner(const StageRunner&) = delete;
  StageRunner& operator=(const StageRunner&) = delete;
  StageRunner(StageRunner&&) = delete;
  StageRunner& operator=(StageRunner&&) = delete;

  // Compatibility with the runner API, without mutating the borrowed pool.
  // A count other than the supplied pool's count causes runtime creation or Run
  // to return FailedPrecondition. Create already records the correct pool count.
  void SetNumThreads(size_t num_threads) override {
    NnpackRunner::SetNumThreads(num_threads);
  }

  pthreadpool_t threadpool() const { return threadpool_; }
  xnn_weights_cache_t weights_cache() const { return weights_cache_; }
  xnn_runtime_t runtime() const { return runtime_.get(); }
  uint32_t runtime_flags() const { return runtime_flags_; }

 protected:
  uint32_t FlagExternalInput() const override {
    return XNN_VALUE_FLAG_EXTERNAL_INPUT;
  }
  uint32_t FlagExternalOutput() const override {
    return XNN_VALUE_FLAG_EXTERNAL_OUTPUT;
  }

  absl::Status CreateRuntime(size_t /*num_threads*/) override {
    LRT_TENSOR_RETURN_IF_ERROR(CheckThreadCount());
    xnn_subgraph_t subgraph =
        static_cast<XnnpackGraph&>(*graph_).GetSubgraph();
    xnn_runtime_t raw_runtime = nullptr;
    LRT_TENSOR_RETURN_IF_ERROR(XnnStatusToAbsl(
        xnn_create_runtime_v3(subgraph, weights_cache_, threadpool_,
                              runtime_flags_, &raw_runtime),
        "xnn_create_runtime_v3"));
    runtime_.reset(raw_runtime);
    return absl::OkStatus();
  }

  absl::Status SetExternalValueShape(
      uint32_t id, absl::Span<const size_t> dims) override {
    return XnnStatusToAbsl(
        xnn_reshape_external_value(runtime_.get(), id, dims.size(),
                                   dims.empty() ? nullptr : dims.data()),
        "xnn_reshape_external_value");
  }

  absl::Status ReshapeRuntime() override {
    LRT_TENSOR_RETURN_IF_ERROR(CheckThreadCount());
    return XnnStatusToAbsl(xnn_reshape_runtime(runtime_.get()),
                           "xnn_reshape_runtime");
  }

  absl::Status GetExternalValueShape(
      uint32_t id, std::vector<size_t>& dims) override {
    size_t num_dims = 0;
    std::array<size_t, XNN_MAX_TENSOR_DIMS> shape{};
    LRT_TENSOR_RETURN_IF_ERROR(XnnStatusToAbsl(
        xnn_get_external_value_shape(runtime_.get(), id, &num_dims,
                                      shape.data()),
        "xnn_get_external_value_shape"));
    dims.assign(shape.begin(), shape.begin() + num_dims);
    return absl::OkStatus();
  }

  absl::Status SetupExternalValues(
      absl::Span<NnpackValue> values,
      const absl::flat_hash_map<uint32_t, std::shared_ptr<Buffer>>& buffers,
      std::vector<LockedBufferSpan<const std::byte>>& locks) override {
    std::vector<xnn_external_value> externals;
    externals.reserve(values.size());
    locks.reserve(values.size());
    for (NnpackValue& value : values) {
      if (value.flags == 0) continue;
      const auto it = buffers.find(value.id);
      if (it == buffers.end() || it->second == nullptr) {
        return absl::FailedPreconditionError(absl::StrFormat(
            "External value %u missing host buffer", value.id));
      }
      LockedBufferSpan<const std::byte> lock = it->second->Lock();
      if (lock.data() == nullptr) {
        return absl::FailedPreconditionError(absl::StrFormat(
            "External value %u could not be locked", value.id));
      }
      xnn_external_value external{};
      external.id = value.id;
      external.data = const_cast<std::byte*>(lock.data());
      externals.push_back(external);
      locks.push_back(std::move(lock));
    }
    return XnnStatusToAbsl(
        xnn_setup_runtime_v2(runtime_.get(), externals.size(), externals.data()),
        "xnn_setup_runtime_v2");
  }

  absl::Status InvokeRuntime() override {
    return XnnStatusToAbsl(xnn_invoke_runtime(runtime_.get()),
                           "xnn_invoke_runtime");
  }

 private:
  struct RuntimeDeleter {
    void operator()(::xnn_runtime* runtime) const {
      if (runtime != nullptr) xnn_delete_runtime(runtime);
    }
  };

  StageRunner(std::unique_ptr<XnnpackGraph> graph, pthreadpool_t pool,
              xnn_weights_cache_t weights, uint32_t runtime_flags)
      : NnpackRunner(std::move(graph)), threadpool_(pool),
        weights_cache_(weights), runtime_flags_(runtime_flags) {
    num_threads_ = BorrowedThreadCount();
  }

  size_t BorrowedThreadCount() const {
    return threadpool_ == nullptr ? 1 : pthreadpool_get_threads_count(threadpool_);
  }

  absl::Status CheckThreadCount() const {
    const size_t actual = BorrowedThreadCount();
    if (num_threads_ != actual) {
      return absl::FailedPreconditionError(absl::StrFormat(
          "StageRunner borrows a %u-thread pool; requested %u threads. "
          "Configure the shared pool before creating stages.",
          actual, num_threads_));
    }
    return absl::OkStatus();
  }

  pthreadpool_t const threadpool_;          // Borrowed; never destroyed here.
  xnn_weights_cache_t const weights_cache_;  // Borrowed; never finalized here.
  uint32_t const runtime_flags_;
  std::unique_ptr<::xnn_runtime, RuntimeDeleter> runtime_;
};

}  // namespace litert::tensor
#endif  // GEMMA4_LIVE_KV_STAGE_RUNNER_H_
