### Follow-up: live INT8 KV cache and chunked prefill

The subsequent [local Gemma4 E2B experiment](/data/bt/tmp/gemma4-live-kv-20260913/README.md)
replaces the frozen native adapter's alternating cache banks with one persistent
INT8 bank. Both K and V use `[capacity, head_dim]` storage per distinct KV owner.
Execution stages append only the new rows before their attention consumers run;
shared layers borrow their owner's cache. Attention borrows contiguous views of
the live prefix or local window, rounded to 32-position boundaries with the
extra positions masked. This removes the adapter's full-bank update algebra and
local-window gathers. XNNPACK still copies/adapts and packs active INT8 operands
internally.

Prefill now appends reusable 128-row chunks with absolute RoPE positions and
causal masks. Only a final partial chunk pads token rows, so a 512-token prompt
no longer requires a 1024-row prefill signature. Allocation capacity remains
2048 and is independent of the attention operand extent. The single logical KV
bank uses 18 MiB plus per-allocation overread padding.

The frozen v4 Android binary matches **199/199 full-logit vectors bitwise**
against same-phone LiteRT-LM CPU references in the
[final correctness report](/data/bt/tmp/gemma4-live-kv-20260913/FINAL_CORRECTNESS.json).
Coverage includes two- and four-thread gates on TECNO LJ9 and Pixel 8, 512-token
prompts followed by 64 forced decode calls, and histories reaching capacity
2048. The earlier frozen-native differences at positions 520 and 536 are absent
in the tested v4 continuations on both phones. Each phone also passed 323
cache-manager checks and completed 2,584 numerical extent comparisons; those
extent diagnostics include expected shape-dependent rounding differences.
These are empirical results for the recorded histories, not a guarantee of
universal bitwise equivalence or a model-quality evaluation.

The [final-build Linux smoke](/data/bt/tmp/gemma4-live-kv-20260913/linux-final-smoke-comparison.json)
also matches three full-logit vectors against the frozen native adapter. This
is a correctness smoke check, with its timing fields excluded from performance
claims.

The completed [phone performance matrix](/data/bt/tmp/gemma4-live-kv-20260913/analysis/results/SUMMARY.md)
compares v4 with the same LiteRT-LM CPU binary using matched histories, affinity,
and thread counts. It contains 40 process blocks, 120 measured sessions, and
7,680 measured decode calls. Each cell has LiteRT-LM, v4, v4, LiteRT-LM blocks;
each process has one warmup and three measured sessions with 64 forced decode
calls, reused runtimes, and no full-logit dumps. Values below are medians of six
sessions per backend, using inclusive decode `elapsed_ms`. First-logit time
includes session initialization, prefill, and the reserved last token's decode;
it excludes loading, compilation, tokenization, and sampling.

| Phone | Threads | Prompt tokens | LiteRT-LM decode (tok/s) | Native v4 decode (tok/s) | First logits, LM / v4 (s) |
| --- | ---: | ---: | ---: | ---: | ---: |
| TECNO LJ9 | 2 | 128 | 11.95 | 16.66 | 1.237 / 0.875 |
| TECNO LJ9 | 2 | 512 | 12.07 | 13.51 | 4.702 / 3.580 |
| TECNO LJ9 | 2 | 1024 | 12.07 | 12.72 | 12.148 / 7.861 |
| TECNO LJ9 | 4 | 128 | 19.44 | 22.67 | 0.665 / 0.379 |
| TECNO LJ9 | 4 | 1024 | 19.30 | 20.12 | 5.880 / 3.337 |
| Pixel 8 | 2 | 128 | 12.93 | 17.05 | 1.431 / 0.779 |
| Pixel 8 | 2 | 512 | 12.99 | 15.04 | 5.359 / 2.820 |
| Pixel 8 | 2 | 1024 | 13.06 | 14.43 | 10.275 / 6.400 |
| Pixel 8 | 4 | 128 | 17.18 | 20.75 | 0.979 / 0.543 |
| Pixel 8 | 4 | 1024 | 16.98 | 19.22 | 8.101 / 4.050 |

V4 has higher median decode throughput in every cell, by 4.3–39.3%, and lower
first-logit latency throughout. At 512 tokens both runners use four 128-row
prefill calls; the previous native padding penalty is absent. At 1024 tokens
v4 uses eight 128-row calls while LiteRT-LM selects its 1024-row signature.

A separate [allocation-capacity follow-up](/data/bt/tmp/gemma4-live-kv-20260913/capacity/results/SUMMARY.md)
keeps the same 128-token prompt, 64 forced continuation tokens, two threads,
and v4 binary while increasing allocation from 256 to 4096 tokens. Eight
process blocks and 24 measured sessions completed:

| Phone | Decode tok/s, capacity 256 / 4096 | Attention ms/token, capacity 256 / 4096 |
| --- | ---: | ---: |
| TECNO LJ9 | 16.661 / 15.909 | 4.3639 / 4.7238 |
| Pixel 8 | 16.848 / 17.167 | 3.6877 / 3.6568 |

The allocation grows 16× while attention time changes by +8.25% on TECNO and
−0.84% on Pixel. This supports the audited live-extent implementation; it does
not establish perfectly capacity-independent latency under normal DVFS.
Allocation/zeroing before the first logits and total memory still scale with
capacity. Both capacities match all 65 same-phone LiteRT-LM argmax positions
on both phones; these timing captures have no full-logit dumps.

Session ranges and process medians remain relevant: clocks were not fixed,
phones warmed during runs, and three Pixel process blocks recorded increases
in sampled major-fault counters without enough information to assign them to
inference. Median process-lifetime peak RSS across cells remains higher for v4:
2.58–2.72 GiB versus 1.50–2.07 GiB. These figures include setup and warmup rather
than isolating KV memory. The copied adapter still widens 60 INT2 MLP matrices to INT4,
preserving their coefficients and scales but adding 270 MiB of weight-code
payload before packing metadata. Cache layout changes do not remove that
remaining difference from LiteRT-LM CPU.

Sources, frozen binaries, build dependencies, exact capture commands, and
offline correctness reproduction are retained in the experiment guide above.
It also provides saved-capture analysis commands and an illustrative benchmark
rerun in a fresh capture namespace, assuming `ANDROID_HOME` is set. No Linux-host
model benchmark or Samsung S25 test is included. This is local testing code
outside the checkout, not a new supported runner API.
