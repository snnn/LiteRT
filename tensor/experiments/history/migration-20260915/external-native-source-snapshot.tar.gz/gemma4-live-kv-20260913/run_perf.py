"""Phone-only replacement benchmark after the final numerical gate."""
import argparse,json
from phone_runs import ROOT,run_capture
p=argparse.ArgumentParser();p.add_argument('device',choices=['tecno','pixel8']);a=p.parse_args()
report=json.loads((ROOT/'FINAL_CORRECTNESS.json').read_text())
if report['status']!='passed':raise RuntimeError('Final correctness gate is not complete/passed')
# One fixture per process, ABBA, identical forced histories and affinity.
for length,threads in [(128,2),(512,2),(1024,2),(128,4),(1024,4)]:
 cell=f'p{length}_t{threads}'
 for block,backend in enumerate(['litertlm','final','final','litertlm']):
  tag=f'perf_{cell}_b{block}_{backend}'
  record=ROOT/a.device/'runs'/(tag+'.command.json')
  if record.exists():
   if json.loads(record.read_text())['status']!='completed':raise RuntimeError('Prior capture incomplete: '+tag)
   continue
  run_capture(a.device,backend,ROOT/'fixtures'/f'performance_{length}_64.tsv',tag,
    threads=threads,phase='benchmark',reuse=True,warmups=1,runs=3,dump=False,cell=cell,block_index=block)
