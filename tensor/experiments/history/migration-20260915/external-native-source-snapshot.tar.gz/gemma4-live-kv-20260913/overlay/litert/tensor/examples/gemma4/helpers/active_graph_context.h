// Local experiment: explicit graph cuts for ordered persistent INT8 appends.
#ifndef GEMMA4_ACTIVE_GRAPH_CONTEXT_H_
#define GEMMA4_ACTIVE_GRAPH_CONTEXT_H_
#include <vector>
#include "litert/tensor/tensor.h"
namespace litert::tensor::examples::gemma4 {
struct ActiveLayerGraph {
  int owner = -1;
  int dim = 0;
  bool global = false;
  TensorHandle hidden_input, ple_input;
  TensorHandle query, new_key, new_value, context_input, output;
};
struct ActiveGraphContext {
  int layer = 0;
  std::vector<int> owners;
  std::vector<ActiveLayerGraph> layers;
  TensorHandle initial_hidden;
  std::vector<TensorHandle> ple_outputs;
  TensorHandle final_hidden;
};
// Scoped only during graph authoring; execution owns all recorded handles.
inline thread_local ActiveGraphContext* active_graph_context = nullptr;
}
#endif
