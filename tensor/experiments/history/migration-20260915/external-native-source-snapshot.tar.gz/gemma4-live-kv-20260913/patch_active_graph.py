from pathlib import Path
base=Path(__file__).parent/'overlay/litert/tensor/examples/gemma4'
p=base/'helpers/attention.h'
s=p.read_text().replace('#include <string>','#include <string>\n#include "litert/tensor/examples/gemma4/helpers/active_graph_context.h"',1)
anchor='  Tensor<Mixins...> k_for_attn;'
assert s.count(anchor)==1
s=s.replace(anchor,'''  if (active_graph_context) {
    auto& ctx = *active_graph_context;
    auto& cut = ctx.layers[ctx.layer];
    cut.owner = ctx.owners[ctx.layer];
    cut.dim = head_dim;
    cut.global = is_global;
    cut.query = Reshape(q, {batch_size, 1, config.num_heads * seq_len, head_dim});
    Tensor<Mixins...> nk = TensorHandle::Invalid(), nv = TensorHandle::Invalid();
    if (cut.owner == ctx.layer) {
      auto k = MobileFullyConnected(input, k_proj, &weights);
      k = Transpose(Reshape(k, {batch_size, seq_len, config.num_kv_heads, head_dim}), {0,2,1,3});
      k = RoPE(RmsNorm(k, k_norm_scale, rmsnorm_eps), cos, sin);
      auto v = MobileFullyConnected(input, v_proj, &weights);
      v = Transpose(Reshape(v, {batch_size, seq_len, config.num_kv_heads, head_dim}), {0,2,1,3});
      v = RmsNorm(v, Tensor<Mixins...>(TensorHandle::Invalid()), rmsnorm_eps);
      nk = QuantizeInt8Kv(k, key_cache);
      nv = QuantizeInt8Kv(v, value_cache);
      cut.new_key = nk;
      cut.new_value = nv;
    }
    Tensor<Mixins...> context({.name=absl::StrCat(name,".active_context"), .type=Type::kFP32,
                              .shape={batch_size,1,config.num_heads*seq_len,head_dim}});
    cut.context_input = context;
    context = Reshape(context, {batch_size,config.num_heads,seq_len,head_dim});
    context = Transpose(context, {0,2,1,3});
    context = Reshape(context, {batch_size,seq_len,q_out_dim});
    auto output = MobileFullyConnected(context, o_proj, &weights);
    return {output,nk,nv,nk,nv};
  }

'''+anchor,1)
p.write_text(s)
p=base/'gemma4_graph.h';s=p.read_text()
anchor='  for (int layer_idx = 0; layer_idx < config.num_layers; ++layer_idx) {'
assert s.count(anchor)==1
s=s.replace(anchor,'''  if (active_graph_context) {
    active_graph_context->initial_hidden = hidden_states;
    active_graph_context->layers.resize(config.num_layers);
    active_graph_context->ple_outputs.resize(config.num_layers);
  }

'''+anchor+'''
    if (active_graph_context) {
      active_graph_context->layer = layer_idx;
      hidden_states = Tensor<Mixins...>({.name=absl::StrCat("active_hidden_",layer_idx),
                      .type=Type::kFP32,.shape=hidden_states.GetShape()});
      active_graph_context->layers[layer_idx].hidden_input = hidden_states;
    }
''',1)
anchor='    TransformerLayerOutput<Mixins...> layer_out ='
assert s.count(anchor)==1
s=s.replace(anchor,'''    if (active_graph_context) {
      active_graph_context->ple_outputs[layer_idx] = per_layer_input;
      per_layer_input = Tensor<Mixins...>({.name=absl::StrCat("active_ple_",layer_idx),
                       .type=Type::kFP32,.shape=per_layer_input.GetShape()});
      active_graph_context->layers[layer_idx].ple_input = per_layer_input;
    }

'''+anchor,1)
s=s.replace('    hidden_states = layer_out.output;','    hidden_states = layer_out.output;\n    if (active_graph_context) active_graph_context->layers[layer_idx].output = hidden_states;',1)
s=s.replace('  // Final RMSNorm','''  if (active_graph_context) {
    hidden_states = Tensor<Mixins...>({.name="active_final_hidden",.type=Type::kFP32,.shape=hidden_states.GetShape()});
    active_graph_context->final_hidden = hidden_states;
  }
  // Final RMSNorm''',1)
p.write_text(s)
