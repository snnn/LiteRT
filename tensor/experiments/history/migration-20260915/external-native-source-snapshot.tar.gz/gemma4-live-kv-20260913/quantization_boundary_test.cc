#include <iostream>
#include "litert/tensor/backends/xnnpack/arithmetic.h"
#include <vector>
#include "litert/tensor/examples/gemma4/helpers/int8_kv_cache.h"
#include "litert/tensor/runners/xnnpack/runner.h"
using namespace litert::tensor;
using namespace litert::tensor::examples::gemma4;
absl::Status Test(float scale,std::vector<float> values,std::vector<int8_t> expected) {
  Tensor<XnnpackMixinTag> in({.type=Type::kFP32,.shape={1,int(values.size())}});
  auto out=Cast(in,Type::kI8);out.SetQuantization(KvQuantization(scale));
  LRT_TENSOR_ASSIGN_OR_RETURN(auto runner,XnnpackRunner::Create({out}));
  LRT_TENSOR_RETURN_IF_ERROR(runner.SetInput(in,values));LRT_TENSOR_RETURN_IF_ERROR(runner.Run());
  LRT_TENSOR_ASSIGN_OR_RETURN(auto result,runner.ReadOutputAs<int8_t>(out));
  for(size_t i=0;i<expected.size();++i){std::cout<<int(result.data()[i])<<' ';if(result.data()[i]!=expected[i])return absl::InternalError("Unexpected actual quantize code");}
  std::cout<<'\n';return absl::OkStatus();
}
int main(){xnn_initialize(nullptr);
  auto a=Test(0.017962608486413956f,{0.134719580411911f,0.13471955060958862f},{8,7});
  auto b=Test(0.0216535534709692f,{0.20570877194404602f,0.20570874214172363f},{10,9});
  if(!a.ok()||!b.ok()){std::cerr<<a<<' '<<b<<'\n';return 1;}
  std::cout<<"PASS: actual XNNPACK FP32-to-INT8 reproduces both full-model boundaries\n";
}
