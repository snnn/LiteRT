#!/usr/bin/env python3
"""Compile an artifact driver against the matched overlay and existing archives.

Uses the same compile/link commands as fp32-trace/build-probe.py, with overlay
headers first and one driver-specific INT8 cache helper object. Never writes
inside either existing CMake build tree or modifies production sources.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('arch', choices=['linux', 'android'])
parser.add_argument('source', type=Path)
a = parser.parse_args()
root = Path('/tmp/gemma4-local-port-nggiqf9x')
build = root / a.arch
source = a.source.resolve(strict=True)
overlay = Path(__file__).resolve().parent / 'overlay'
cache_source = overlay / 'litert/tensor/examples/gemma4/helpers/int8_kv_cache.cc'
if not cache_source.is_file():
    raise FileNotFoundError(cache_source)
obj = source.with_suffix('.' + a.arch + '.o')
exe = source.with_suffix('.' + a.arch)
cache_obj = exe.with_name(exe.name + '.int8_kv_cache.o')
entry = next(x for x in json.loads((build / 'compile_commands.json').read_text())
             if x['file'].endswith('/gemma4/xnnpack_main.cc'))

def strip_depflags(args):
    out = []
    i = 0
    while i < len(args):
        flag = args[i]
        if flag in ('-MF', '-MT', '-MQ', '--dependency-file'):
            i += 2
            continue
        if flag in ('-MD', '-MMD', '-MP') or flag.startswith(
                ('-MF', '-MT', '-MQ', '--dependency-file=', '-Wl,--dependency-file=')):
            i += 1
            continue
        if flag == '-Xlinker' and i + 1 < len(args) and args[i+1].startswith('--dependency-file='):
            i += 2
            continue
        if (flag == '-Xlinker' and i + 3 < len(args) and
                args[i+1] == '--dependency-file' and args[i+2] == '-Xlinker'):
            i += 4
            continue
        out.append(flag)
        i += 1
    return out

compile_main = strip_depflags(shlex.split(entry['command']))
compile_main.insert(1, '-I' + str(overlay))
compile_main[compile_main.index('-o') + 1] = str(obj)
compile_main[-1] = str(source)
compile_cache = list(compile_main)
compile_cache[compile_cache.index('-o') + 1] = str(cache_obj)
compile_cache[-1] = str(cache_source)
commands = subprocess.run(
    ['ninja', '-C', str(build), '-t', 'commands', 'bin/gemma4_xnnpack_main'],
    capture_output=True, text=True, check=True)
link = shlex.split(commands.stdout.splitlines()[-1])
if link[:2] == [':', '&&']:
    link = link[2:]
if link[-2:] == ['&&', ':']:
    link = link[:-2]
link = strip_depflags(link)
indices = [i for i, value in enumerate(link)
           if value.endswith('/gemma4/xnnpack_main.cc.o')]
if len(indices) != 1:
    raise RuntimeError('Expected exactly one original driver object in link command')
link[indices[0]] = str(obj)
link.insert(indices[0] + 1, str(cache_obj))
link[link.index('-o') + 1] = str(exe)
record = {
    'compile': compile_main,
    'extra_compile_commands': [compile_cache],
    'link': link,
    'cwd': str(build),
    'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'overlay_sha256': {
        str(path.relative_to(overlay)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(overlay.rglob('*')) if path.is_file()
    },
}
exe.with_suffix(exe.suffix + '.commands.json').write_text(
    json.dumps(record, indent=2) + '\n')
log_path = exe.with_suffix(exe.suffix + '.build.log')
with log_path.open('w') as log:
    for cmd in [compile_main, compile_cache, link]:
        result = subprocess.run(cmd, cwd=build, stdout=log, stderr=subprocess.STDOUT)
        if result.returncode:
            print(log_path.read_text())
            raise SystemExit(result.returncode)
print(exe)
