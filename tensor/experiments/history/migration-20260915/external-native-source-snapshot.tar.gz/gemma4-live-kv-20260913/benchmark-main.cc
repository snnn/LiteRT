// Artifact-only adapter using actual published-bundle coefficients and INT8 KV.
#define main unused_production_driver_main
#include "/data/bt/os/xnnpack/litert/tensor/examples/gemma4/xnnpack_main.cc"
#undef main

#include <chrono>
#include <filesystem>
#include <iomanip>
#include <set>
#include <sstream>
#include <sys/resource.h>
#include "litert/tensor/examples/gemma4/helpers/int8_kv_cache.h"
#include "matched_bundle_loader.h"
#include "src/xnnpack/subgraph.h"

ABSL_FLAG(std::string, bundle_dir, "", "Verified actual-bundle export directory.");

ABSL_FLAG(std::string, cases_file, "", "TSV: case ID, prompt CSV, forced decode-input CSV (or -).");
ABSL_FLAG(std::string, output_dir, "", "New, nonexisting artifact directory.");
ABSL_FLAG(int, warmup_runs, 1, "Discarded warmup repetitions for each case.");
ABSL_FLAG(int, measured_runs, 3, "Measured repetitions for each case.");
ABSL_FLAG(bool, reuse_runtimes, false, "Reuse the case's compiled runtimes; otherwise compile fresh per repetition.");
ABSL_FLAG(bool, dump_full_logits, false, "Write each pass's full final-position vocabulary logits after timing in the first measured repetition only.");

namespace litert::tensor::examples::gemma4 {
namespace {
using BenchClock = std::chrono::steady_clock;
double Milliseconds(BenchClock::time_point start) {
  return std::chrono::duration<double, std::milli>(BenchClock::now() - start).count();
}
long PeakRssKiB() {
  struct rusage usage {};
  return getrusage(RUSAGE_SELF, &usage) == 0 ? usage.ru_maxrss : -1;
}

struct BenchCase {
  std::string id;
  std::vector<int32_t> prompt;
  std::vector<int32_t> forced;
};

absl::StatusOr<std::vector<BenchCase>> ReadCases(const std::string& path) {
  std::ifstream file(path);
  if (!file) return absl::InvalidArgumentError("Cannot open --cases_file");
  std::vector<BenchCase> cases;
  std::set<std::string> seen;
  std::string line;
  while (std::getline(file, line)) {
    if (!line.empty() && line.back() == '\r') line.pop_back();
    if (line.empty()) continue;
    const auto first = line.find('\t');
    const auto second = first == std::string::npos ? first : line.find('\t', first + 1);
    if (first == std::string::npos || second == std::string::npos ||
        line.find('\t', second + 1) != std::string::npos)
      return absl::InvalidArgumentError("Cases require exactly three tab-separated fields");
    BenchCase item;
    item.id = line.substr(0, first);
    if (item.id.empty() || item.id.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-") != std::string::npos ||
        !seen.insert(item.id).second)
      return absl::InvalidArgumentError("Unsafe or duplicate case ID");
    LRT_TENSOR_ASSIGN_OR_RETURN(item.prompt, ParseTokenIds(line.substr(first + 1, second - first - 1)));
    const std::string forced = line.substr(second + 1);
    if (!forced.empty() && forced != "-") {
      LRT_TENSOR_ASSIGN_OR_RETURN(item.forced, ParseTokenIds(forced));
    }
    if (item.prompt.empty() || item.prompt.front() != 2 ||
        item.prompt.size() + item.forced.size() >= std::numeric_limits<int>::max())
      return absl::InvalidArgumentError("Prompt must begin with BOS2 and total length must fit int");
    for (const auto& ids : {item.prompt, item.forced})
      for (int32_t token : ids)
        if (token < 0 || token >= 262144)
          return absl::InvalidArgumentError("Token outside E2B vocabulary");
    cases.push_back(std::move(item));
  }
  if (!file.eof() || cases.empty()) return absl::InvalidArgumentError("Empty or invalid cases file");
  return cases;
}

struct SetupTimes { double graph_ms=0, compile_pack_ms=0, total_ms=0; };
struct BenchRuntime {
  WeightsCache cache;
  BuiltGraphs graphs;
  CompiledRunners runners;
  SetupTimes times;
  int prefill_rows;
};
constexpr int kMatchedCapacity=2048;
using Inputs=Gemma4Inputs<XnnpackMixinTag>;
using Outputs=Gemma4Outputs<XnnpackMixinTag>;
std::vector<TensorHandle> Handles(const std::vector<XnnTensor>& tensors) {
  return std::vector<TensorHandle>(tensors.begin(),tensors.end());
}
absl::StatusOr<Inputs> MakeMatchedInputs(const Config& config,int rows,bool decode,
    const LoadedTensors& loaded,const std::vector<KvOwnerSpec>& specs) {
  LRT_TENSOR_ASSIGN_OR_RETURN(auto inputs,CreateGemma4Inputs(config,rows,decode?1:0,loaded.weights_handle,false));
  inputs.bundle_dynamic_qd8_head=true;
  auto positions=XnnTensor({.name="matched_rope_positions",.type=Type::kFP32,.shape={1,1,rows,1}});
  inputs.weights["matched.rope.positions"]=positions;
  auto make_rope=[&](int dimension,float base,float proportion){
    const int half=dimension/2;
    std::vector<float> inverse(half,0.0f);
    for(int i=0;i<static_cast<int>(proportion*half);++i)inverse[i]=1.0f/std::pow(base,2.0f*i/dimension);
    auto frequency=XnnTensor({.type=Type::kFP32,.shape={1,1,1,half},.buffer=OwningCpuBuffer::Copy<Type::kFP32>(inverse)});
    auto angles=Mul(positions,frequency);
    auto cosine=Cos(angles),sine=Sin(angles);
    return std::make_pair(Concatenation({cosine,cosine},3),Concatenation({sine,sine},3));
  };
  std::tie(inputs.rope_global_cos,inputs.rope_global_sin)=make_rope(config.global_key_size,config.global_base_frequency,config.global_rope_proportion);
  std::tie(inputs.rope_local_cos,inputs.rope_local_sin)=make_rope(config.head_dim,config.local_base_frequency,config.local_rope_proportion);

  inputs.global_attention_mask=XnnTensor({.name="global_attention_mask",.type=Type::kFP32,.shape={1,1,rows,kMatchedCapacity}});
  inputs.sliding_attention_mask=XnnTensor({.name="sliding_attention_mask",.type=Type::kFP32,.shape={1,1,rows,config.sliding_window_size+rows-1}});
  const auto sharing=GetKvCacheSharingPatterns(config);
  for(int layer=0;layer<config.num_layers;++layer){
    auto it=std::find_if(specs.begin(),specs.end(),[&](const auto& spec){return spec.owner==sharing[layer];});
    if(it==specs.end())return absl::InvalidArgumentError("Missing KV owner scale");
    inputs.key_caches[layer]=MakeInt8KeyCache<XnnpackMixinTag>(absl::StrCat("key_cache_",layer),kMatchedCapacity,it->head_dim,it->key_scale);
    inputs.value_caches[layer]=MakeInt8ValueCache<XnnpackMixinTag>(absl::StrCat("value_cache_",layer),kMatchedCapacity,it->head_dim,it->value_scale);
  }
  if(decode){
    inputs.weights[kKvKeepMaskName]=MakeInt8KvMask<XnnpackMixinTag>(kKvKeepMaskName,kMatchedCapacity);
    inputs.weights[kKvWriteMaskName]=MakeInt8KvMask<XnnpackMixinTag>(kKvWriteMaskName,kMatchedCapacity);
    inputs.weights[kLocalKvKeepMaskName]=MakeInt8KvMask<XnnpackMixinTag>(kLocalKvKeepMaskName,config.sliding_window_size);
    inputs.weights[kLocalKvWriteMaskName]=MakeInt8KvMask<XnnpackMixinTag>(kLocalKvWriteMaskName,config.sliding_window_size);
    for(const auto& spec:specs){
      if(config.GetLayerType(spec.owner)!=Config::LayerType::kLocalSliding)continue;
      const auto module=absl::StrCat("model.layers.",spec.owner,".self_attn");
      const auto kn=LocalKvKeyName(module),vn=LocalKvValueName(module);
      inputs.weights[kn]=MakeInt8KeyCache<XnnpackMixinTag>(kn,config.sliding_window_size,spec.head_dim,spec.key_scale);
      inputs.weights[vn]=MakeInt8ValueCache<XnnpackMixinTag>(vn,config.sliding_window_size,spec.head_dim,spec.value_scale);
    }

  }
  return inputs;
}
std::vector<TensorHandle> OwnerRoots(const Outputs& outputs,const std::vector<KvOwnerSpec>& specs,bool logits){
  std::vector<TensorHandle> roots;
  if(logits)roots.push_back(outputs.logits);
  for(const auto& spec:specs){roots.push_back(outputs.key_caches[spec.owner]);roots.push_back(outputs.value_caches[spec.owner]);}
  return roots;
}
absl::Status AuditCompiledGraph(XnnpackRunner& runner,bool decode){
  const auto* sg=static_cast<const XnnpackGraph&>(runner.graph()).GetSubgraph();
  int fc=0,bmm=0;
  for(size_t i=0;i<sg->num_nodes;++i){
    fc+=sg->nodes[i].type==xnn_node_type_fully_connected;
    bmm+=sg->nodes[i].type==xnn_node_type_batch_matrix_multiply;
  }
  std::cerr << (decode?"Decode":"Cache-only prefill") << " lowered FC=" << fc << ", BMM=" << bmm << "\n";
  if(fc!=(decode?277:129)||bmm!=(decode?70:28))return absl::InternalError("Unexpected graph work: expected published bundle FC/attention counts");
  for(const auto& value:runner.graph().values()){
    if((value.flags&XNN_VALUE_FLAG_EXTERNAL_INPUT)&&value.info.name.find("weight")!=std::string::npos)
      return absl::InternalError("An unbound weight became an external input: "+value.info.name);
  }
  return absl::OkStatus();
}
absl::StatusOr<std::unique_ptr<BenchRuntime>> CreateBenchRuntime(
    const Config& config,int prompt_length,const LoadedTensors& loaded,
    const std::vector<KvOwnerSpec>& specs,int threads){
  const auto total=BenchClock::now();
  if(prompt_length<1||prompt_length>1024)return absl::InvalidArgumentError("Matched pilot supports one 128/1024 prefill chunk, up to 1024 prompt IDs");
  const int rows=prompt_length<=128?128:1024;
  xnn_weights_cache_t raw=nullptr;
  LRT_TENSOR_RETURN_IF_ERROR(xnn_create_weights_cache(&raw));
  WeightsCache cache(raw);
  auto start=BenchClock::now();
  LRT_TENSOR_ASSIGN_OR_RETURN(auto prefill_inputs,MakeMatchedInputs(config,rows,false,loaded,specs));
  auto prefill_outputs=BuildGemma4Graph(prefill_inputs,config);
  LRT_TENSOR_ASSIGN_OR_RETURN(auto decode_inputs,MakeMatchedInputs(config,1,true,loaded,specs));
  auto decode_outputs=BuildGemma4Graph(decode_inputs,config);
  SetupTimes times;times.graph_ms=Milliseconds(start);
  auto prefill_roots=OwnerRoots(prefill_outputs,specs,false);
  auto decode_roots=OwnerRoots(decode_outputs,specs,true);
  for(const auto& roots:{prefill_roots,decode_roots})for(const auto& root:roots)LRT_TENSOR_RETURN_IF_ERROR(root.GetStatus());
  start=BenchClock::now();
  LRT_TENSOR_ASSIGN_OR_RETURN(auto prefill_runner,XnnpackRunner::Create(prefill_roots));
  LRT_TENSOR_ASSIGN_OR_RETURN(auto decode_runner,XnnpackRunner::Create(decode_roots));
  LRT_TENSOR_RETURN_IF_ERROR(AuditCompiledGraph(prefill_runner,false));
  LRT_TENSOR_RETURN_IF_ERROR(AuditCompiledGraph(decode_runner,true));
  for(auto* runner:{&prefill_runner,&decode_runner}){
    runner->SetNumThreads(threads);runner->SetWeightsCache(cache.get());
    LRT_TENSOR_RETURN_IF_ERROR(runner->PrepareRuntime());
  }
  LRT_TENSOR_RETURN_IF_ERROR(xnn_finalize_weights_cache(cache.get(),xnn_weights_cache_finalization_kind_hard));
  times.compile_pack_ms=Milliseconds(start);times.total_ms=Milliseconds(total);
  std::cerr << "Matched runtimes ready; prefill rows=" << rows << ", roots=" << prefill_roots.size() << ", decode roots=" << decode_roots.size() << "\n";
  return std::make_unique<BenchRuntime>(BenchRuntime{
    std::move(cache),{std::move(prefill_inputs),std::move(prefill_outputs),std::move(decode_inputs),std::move(decode_outputs)},
    {std::move(prefill_runner),std::move(decode_runner)},times,rows});
}
// Bind only live graph inputs. Cache-only prefill prunes tail-layer PLE inputs.
template<class T>
absl::Status BindIfLive(XnnpackRunner& runner,const TensorHandle& handle,const T& data){
  if(!runner.graph().Lookup(handle).ok())return absl::OkStatus();
  return runner.SetInput(handle,data);
}
absl::Status RunMatchedTokens(BenchRuntime& runtime,const Config& config,const LoadedTensors& loaded,
    Int8KvCacheBank& bank,Int8KvLocalWindows& windows,absl::Span<const int32_t> tokens,bool decode,double& forward_ms){
  auto& runner=decode?runtime.runners.decode_runner:runtime.runners.prefill_runner;
  auto& inputs=decode?runtime.graphs.decode_inputs:runtime.graphs.prefill_inputs;
  auto& outputs=decode?runtime.graphs.decode_outputs:runtime.graphs.prefill_outputs;
  const int rows=decode?1:runtime.prefill_rows;
  if(tokens.empty()||tokens.size()>rows||(decode&&tokens.size()!=1)||(!decode&&bank.length()!=0))
    return absl::InvalidArgumentError("Invalid fixed-signature invocation");
  const int start_position=bank.length(),valid_tokens=start_position+tokens.size();
  std::vector<int32_t> padded(rows,0);std::copy(tokens.begin(),tokens.end(),padded.begin());
  std::vector<float> embeddings(static_cast<size_t>(rows)*config.embed_dim);
  std::vector<std::vector<float>> ple(config.num_layers,std::vector<float>(static_cast<size_t>(rows)*config.per_layer_input_dim));
  LRT_TENSOR_RETURN_IF_ERROR(loaded.token_embedding->Lookup(padded,absl::MakeSpan(embeddings)));
  LRT_TENSOR_RETURN_IF_ERROR(loaded.emb_per_layer_table->LookupPerLayer(padded,config.num_layers,config.per_layer_input_dim,absl::MakeSpan(ple)));
  LRT_TENSOR_RETURN_IF_ERROR(runner.SetInput(inputs.embedded_input,embeddings));
  for(int layer=0;layer<config.num_layers;++layer)LRT_TENSOR_RETURN_IF_ERROR(BindIfLive(runner,inputs.per_layer_token_embeddings[layer],ple[layer]));
  std::vector<float> global_mask(static_cast<size_t>(rows)*kMatchedCapacity),local_mask(static_cast<size_t>(rows)*(config.sliding_window_size+rows-1));
  LRT_TENSOR_RETURN_IF_ERROR(FillFixedInt8KvAttentionMask(absl::MakeSpan(global_mask),rows,kMatchedCapacity,start_position,valid_tokens,false,config.sliding_window_size));
  LRT_TENSOR_RETURN_IF_ERROR(FillLocalInt8KvAttentionMask(absl::MakeSpan(local_mask),rows,kMatchedCapacity,start_position,valid_tokens,config.sliding_window_size));
  LRT_TENSOR_RETURN_IF_ERROR(runner.SetInput(inputs.global_attention_mask,global_mask));
  LRT_TENSOR_RETURN_IF_ERROR(runner.SetInput(inputs.sliding_attention_mask,local_mask));
  std::vector<float> positions(rows);
  for(int row=0;row<rows;++row)positions[row]=static_cast<float>(start_position+row);
  LRT_TENSOR_RETURN_IF_ERROR(runner.SetInput(inputs.weights.at("matched.rope.positions"),positions));
  if(decode){
    LRT_TENSOR_RETURN_IF_ERROR(bank.BindInputs(runner,Handles(inputs.key_caches),Handles(inputs.value_caches)));
    LRT_TENSOR_RETURN_IF_ERROR(bank.BindDecodeMasks(runner,inputs.weights.at(kKvKeepMaskName),inputs.weights.at(kKvWriteMaskName)));
    std::vector<TensorHandle> window_keys(config.num_layers,TensorHandle::Invalid()),window_values(config.num_layers,TensorHandle::Invalid());
    for(const auto& spec:bank.specs()){
      if(config.GetLayerType(spec.owner)!=Config::LayerType::kLocalSliding)continue;
      const auto module=absl::StrCat("model.layers.",spec.owner,".self_attn");
      window_keys[spec.owner]=inputs.weights.at(LocalKvKeyName(module));
      window_values[spec.owner]=inputs.weights.at(LocalKvValueName(module));
    }
    LRT_TENSOR_RETURN_IF_ERROR(windows.BindDecode(runner,bank,window_keys,window_values,inputs.weights.at(kLocalKvKeepMaskName),inputs.weights.at(kLocalKvWriteMaskName)));

  }
  LRT_TENSOR_RETURN_IF_ERROR(bank.BindOutputs(runner,Handles(outputs.key_caches),Handles(outputs.value_caches)));
  auto start=BenchClock::now();
  LRT_TENSOR_RETURN_IF_ERROR(runner.Run());
  forward_ms+=Milliseconds(start);
  return bank.Commit(tokens.size());
}
struct PassResult {
  int index = 0;
  int input_token = -1;
  int context_length = 0;
  int argmax = -1;
  double elapsed_ms = 0;
  double forward_ms = 0;
  double cache_ms = 0;
  std::string logits_file;
};

absl::Status DumpPass(BenchRuntime& runtime, const Config& config,
                     const BenchCase& item, int index,
                     const std::string& directory, PassResult& result) {
  auto& runner = runtime.runners.decode_runner;
  const auto& output = runtime.graphs.decode_outputs.logits;
  LRT_TENSOR_ASSIGN_OR_RETURN(auto data, runner.ReadOutputAs<float>(output));
  const size_t rows=1;
  if(data.size()!=config.vocab_size)return absl::InternalError("Unexpected matched logits dimensions");
  result.logits_file = item.id + (index == 0 ? ".prefill.f32" : absl::StrFormat(".decode_%04d.f32", index));
  return WriteRawFloats(directory + "/" + result.logits_file,
                       absl::MakeConstSpan(data.data() + (rows - 1) * config.vocab_size, config.vocab_size));
}

absl::Status WriteRun(const BenchCase& item, int run_index, bool warmup,
                     int threads, bool reuse, bool compiled_this_run,
                     const SetupTimes& setup, double load_ms,
                     const std::vector<PassResult>& passes,
                     const std::string& directory) {
  const std::string file = directory + "/" + item.id +
      (warmup ? ".warmup_" : ".run_") + absl::StrFormat("%03d.json", run_index);
  std::ofstream out(file);
  if (!out) return absl::InternalError("Cannot open run JSON");
  double inference_ms = 0;
  for (const auto& pass : passes) inference_ms += pass.elapsed_ms;
  out << std::setprecision(17)
      << "{\n\"schema_version\":1,\n\"runner\":\"xnnpack_tensor_bundle_matched_window\",\n"
      << "\"case_id\":\"" << item.id << "\",\n"
      << "\"prompt_token_ids\":[" << absl::StrJoin(item.prompt, ",") << "],\n"
      << "\"forced_decode_token_ids\":[" << absl::StrJoin(item.forced, ",") << "],\n"
      << "\"run_index\":" << run_index << ",\"warmup\":" << (warmup ? "true" : "false") << ",\n"
      << "\"num_threads\":" << threads << ",\"vocab_size\":262144,\n"
      << "\"runtime_flags\":0,\"activation_qdq\":\"actual bundle static scales + dynamic QD8 head\",\n"
      << "\"bound_kv_cache_capacity_verified\":2048,\"kv_owner_count\":15,\"kv_logical_bytes_per_bank\":18874368,\"kv_host_bank_count\":2,\"kv_key_layout\":\"1,1,2048,D\",\"kv_value_layout\":\"1,1,D,2048\",\"kv_dtype\":\"int8\",\"weights_cache\":\"shared in-memory between prefill/decode only\",\n"
      << "\"reused_runtimes\":" << (reuse ? "true" : "false") << ",\n"
      << "\"compiled_this_run\":" << (compiled_this_run ? "true" : "false") << ",\n"
      << "\"logical_session_reset\":\"both INT8 host banks zeroed; all live K/V rebound; reserved-last-token schedule\",\n"
      << "\"logits_dtype\":\"float32-little-endian\",\n"
      << "\"cold_process_model_load_and_prepare_ms\":" << load_ms << ",\n"
      << "\"runtime_setup_ms\":" << (compiled_this_run ? setup.total_ms : 0) << ",\n"
      << "\"graph_build_ms\":" << (compiled_this_run ? setup.graph_ms : 0) << ",\n"
      << "\"compile_pack_ms\":" << (compiled_this_run ? setup.compile_pack_ms : 0) << ",\n"
      << "\"inference_work_ms\":" << inference_ms << ",\n"
      << "\"peak_process_rss_kib\":" << PeakRssKiB() << ",\n"
      << "\"timing_scope\":\"steady-clock; first logits includes cache reset, prefix cache-only prefill128/1024 plus reserved-last-token decode; each pass includes embedding, bindings, full INT8 bank update, compact INT8 local-window gather/update, compact softmax, argmax/finite; excludes dumps/report I/O and setup\",\n"
      << "\"eos_policy\":\"forced history consumed completely; predicted stop IDs do not stop execution\",\n"
      << "\"passes\":[\n";
  for (size_t i = 0; i < passes.size(); ++i) {
    const auto& pass = passes[i];
    out << (i ? ",\n" : "") << "{\"kind\":\"" << (i == 0 ? "prefill" : "decode")
        << "\",\"decode_index\":" << pass.index << ",\"input_ids\":[";
    if (i == 0) out << absl::StrJoin(item.prompt, ",");
    else out << pass.input_token;
    out << "],\"context_length_after\":" << pass.context_length
        << ",\"logits_position\":" << pass.context_length - 1
        << ",\"argmax_id\":" << pass.argmax << ",\"elapsed_ms\":" << pass.elapsed_ms
        << ",\"forward_ms\":" << pass.forward_ms << ",\"cache_handoff_or_update_ms\":" << pass.cache_ms
        << ",\"logits_file\":";
    if (pass.logits_file.empty()) out << "null";
    else out << "\"" << pass.logits_file << "\"";
    out << "}";
  }
  out << "\n]}\n";
  if (!out) return absl::InternalError("Cannot write run JSON");
  return absl::OkStatus();
}

absl::Status RunOne(BenchRuntime& runtime,const Config& config,const LoadedTensors& loaded,
    const std::vector<KvOwnerSpec>& specs,const BenchCase& item,int run_index,bool warmup,
    int threads,bool reuse,bool compiled_this_run,bool dump,double load_ms,const std::string& directory){
  std::vector<PassResult> results;
  auto start=BenchClock::now();
  LRT_TENSOR_ASSIGN_OR_RETURN(auto bank,Int8KvCacheBank::Create(specs,kMatchedCapacity));
  bank.Reset();
  LRT_TENSOR_ASSIGN_OR_RETURN(auto windows,Int8KvLocalWindows::Create(specs,kMatchedCapacity,config.sliding_window_size));
  double forward=0;
  if(item.prompt.size()>1)LRT_TENSOR_RETURN_IF_ERROR(RunMatchedTokens(runtime,config,loaded,bank,windows,absl::MakeConstSpan(item.prompt.data(),item.prompt.size()-1),false,forward));
  for(size_t index=0;index<=item.forced.size();++index){
    if(index){start=BenchClock::now();forward=0;}
    const int32_t token=index?item.forced[index-1]:item.prompt.back();
    LRT_TENSOR_RETURN_IF_ERROR(RunMatchedTokens(runtime,config,loaded,bank,windows,absl::MakeConstSpan(&token,1),true,forward));
    LRT_TENSOR_ASSIGN_OR_RETURN(auto data,runtime.runners.decode_runner.ReadOutputAs<float>(runtime.graphs.decode_outputs.logits));
    if(data.size()!=config.vocab_size)return absl::InternalError("Wrong matched logits size");
    LRT_TENSOR_ASSIGN_OR_RETURN(auto predicted,SelectTokenAndDump(absl::MakeConstSpan(data.data(),data.size()),"",index));
    const double elapsed=Milliseconds(start);
    results.push_back(PassResult{static_cast<int>(index),index?token:-1,bank.length(),predicted,elapsed,forward,0,""});
    if(dump)LRT_TENSOR_RETURN_IF_ERROR(DumpPass(runtime,config,item,index,directory,results.back()));
  }
  return WriteRun(item,run_index,warmup,threads,reuse,compiled_this_run,runtime.times,load_ms,results,directory);
}
absl::Status BenchmarkMain() {
  const auto program_start = BenchClock::now();
  const int threads = absl::GetFlag(FLAGS_num_threads);
  const int warmups = absl::GetFlag(FLAGS_warmup_runs);
  const int measurements = absl::GetFlag(FLAGS_measured_runs);
  const bool reuse = absl::GetFlag(FLAGS_reuse_runtimes);
  if (threads <= 0 || warmups < 0 || measurements <= 0 ||
      warmups > std::numeric_limits<int>::max() - measurements)
    return absl::InvalidArgumentError("Invalid thread/repetition count");
  if (absl::GetFlag(FLAGS_consistent_arithmetic) || !absl::GetFlag(FLAGS_weight_cache) ||
      absl::GetFlag(FLAGS_dump_intermediates) || !absl::GetFlag(FLAGS_dump_logits).empty())
    return absl::InvalidArgumentError("Use default arithmetic/cache and adapter --dump_full_logits only");
  LRT_TENSOR_ASSIGN_OR_RETURN(auto cases, ReadCases(absl::GetFlag(FLAGS_cases_file)));
  const std::string directory = absl::GetFlag(FLAGS_output_dir);
  std::error_code error;
  if (directory.empty() || !std::filesystem::create_directory(directory, error))
    return absl::InvalidArgumentError("--output_dir must be new with an existing parent: " + error.message());
  const auto load_start = BenchClock::now();
  LRT_TENSOR_RETURN_IF_ERROR(xnn_initialize(nullptr));
  const auto config = Config::From(ModelVariant::kE2B);
  LRT_TENSOR_ASSIGN_OR_RETURN(auto loaded,LoadPublishedBundle(absl::GetFlag(FLAGS_bundle_dir),config));
  LRT_TENSOR_ASSIGN_OR_RETURN(auto specs,LoadPublishedKvSpecs(absl::GetFlag(FLAGS_bundle_dir),config));
  const double load_ms = Milliseconds(load_start);
  if (loaded.token_embedding->VocabSize() != config.vocab_size ||
      loaded.emb_per_layer_table->VocabSize() != config.vocab_size)
    return absl::InvalidArgumentError("Embedding/config vocabulary mismatch");
  for (const auto& item : cases) {
    if(item.prompt.size()+item.forced.size()>kMatchedCapacity)return absl::InvalidArgumentError("History exceeds fixed KV capacity");
    std::unique_ptr<BenchRuntime> runtime;
    for (int iteration = 0; iteration < warmups + measurements; ++iteration) {
      bool compiled = !runtime;
      if (!runtime) {
        LRT_TENSOR_ASSIGN_OR_RETURN(runtime, CreateBenchRuntime(config, item.prompt.size(), loaded, specs, threads));
      }
      const bool warmup = iteration < warmups;
      const int run_index = warmup ? iteration : iteration - warmups;
      const bool dump = absl::GetFlag(FLAGS_dump_full_logits) && !warmup && run_index == 0;
      LRT_TENSOR_RETURN_IF_ERROR(RunOne(*runtime, config, loaded, specs, item, run_index,
          warmup, threads, reuse, compiled, dump, load_ms, directory));
      if (!reuse) runtime.reset();
    }
  }
  std::ofstream summary(directory + "/run.json");
  if (!summary) return absl::InternalError("Cannot open final summary");
  summary << std::setprecision(17) << "{\"status\":\"completed\",\"cases\":" << cases.size()
          << ",\"warmup_runs\":" << warmups << ",\"measured_runs\":" << measurements
          << ",\"reuse_runtimes\":" << (reuse ? "true" : "false")
          << ",\"warmup_scope\":\"" << (reuse ? "same compiled runtimes, fresh logical sessions" : "fresh runtime each repetition; OS/model-page warming only")
          << "\",\"num_threads\":" << threads << ",\"model_load_prepare_ms\":" << load_ms
          << ",\"process_work_wall_ms_including_io\":" << Milliseconds(program_start)
          << ",\"peak_process_rss_kib\":" << PeakRssKiB() << "}\n";
  if (!summary) return absl::InternalError("Cannot write final summary");
  return absl::OkStatus();
}
}  // namespace
}  // namespace litert::tensor::examples::gemma4

int main(int argc, char** argv) {
  absl::SetFlag(&FLAGS_num_threads, 2);
  absl::ParseCommandLine(argc, argv);
  absl::InitializeLog();
  const auto status = litert::tensor::examples::gemma4::BenchmarkMain();
  if (!status.ok()) {
    std::cerr << status << '\n';
    return 1;
  }
  return 0;
}
