#!/usr/bin/env python3
"""Read-only full code/scale hash verification, no inference or timings."""
import hashlib
import json
from pathlib import Path
import numpy as np
root = Path(__file__).resolve().parent
bundle = Path('/tmp/gemma4-local-port-nggiqf9x/replacement-comparison/matched-bundle')
manifest = json.loads((bundle / 'manifest.json').read_text())
records = {record['name']: record for record in manifest['tensors']}
results = []
for layer in range(15, 35):
    for projection in ('gate', 'up', 'down'):
        name = f'model.layers.{layer}.mlp.{projection}_proj.weight'
        record = records[name]
        assert record['dtype'] == 'int4'
        assert record['encoding'] == 'signed_twos_complement_low_nibble_first'
        source, = record['sources']
        assert source['dtype'] == 'INT2'
        assert source['shape'] == record['shape']
        raw = (bundle / record['file']).read_bytes()
        assert len(raw) == record['bytes']
        assert hashlib.sha256(raw).hexdigest() == record['sha256']
        a = np.frombuffer(raw, dtype=np.uint8)
        low, high = a & 15, a >> 4
        assert np.isin(low, [0, 1, 14, 15]).all()
        assert np.isin(high, [0, 1, 14, 15]).all()
        nibble = (low & 3) | ((high & 3) << 2)
        compact = nibble[::2] | (nibble[1::2] << 4)
        compact_hash = hashlib.sha256(compact).hexdigest()
        assert compact_hash == source['source_data_sha256'], name
        assert compact.nbytes == source['source_bytes']
        q = record['quantization']
        assert q['kind'] == 'per_channel' and q['quantized_dimension'] == 0
        assert q['zero_points'] == [0]
        assert q['scales_shape'] == [record['shape'][0]]
        scale_raw = (bundle / q['scales_file']).read_bytes()
        assert hashlib.sha256(scale_raw).hexdigest() == q['scales_sha256']
        scales = np.frombuffer(scale_raw, dtype='<f4')
        assert scales.size == record['shape'][0] and np.isfinite(scales).all() and (scales > 0).all()
        activation_scales = {}
        for side in ('input', 'output'):
            scale_record = records[name.removesuffix('.weight') + f'.{side}_scale']
            data = (bundle / scale_record['file']).read_bytes()
            assert hashlib.sha256(data).hexdigest() == scale_record['sha256']
            value = np.frombuffer(data, dtype='<f4')
            assert len(value) == 1 and np.isfinite(value[0]) and value[0] > 0
            activation_scales[side] = float(value[0])
        results.append({'name': name, 'shape': record['shape'],
                        'widened_bytes': len(raw), 'compact_bytes': compact.nbytes,
                        'reconstructed_sha256': compact_hash,
                        'original_source_sha256': source['source_data_sha256'],
                        'activation_scales': activation_scales})
assert len(results) == 60
output = {'status': 'passed', 'all_original_source_hashes_match': True,
          'tensors': len(results), 'widened_bytes': sum(r['widened_bytes'] for r in results),
          'compact_bytes': sum(r['compact_bytes'] for r in results), 'records': results}
(root / 'static_int2_manifest_verification.json').write_text(json.dumps(output, indent=2) + '\n')
print(f"PASS: all {len(results)} reconstructed INT2 payload hashes equal original source; all codes, shapes, scales and export hashes validated")
