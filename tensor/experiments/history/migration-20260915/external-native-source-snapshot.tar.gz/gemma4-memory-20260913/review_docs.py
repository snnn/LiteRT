"""Validate final local documentation; never executes model or device commands."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

root=Path(__file__).resolve().parent
repo=Path('/data/bt/os/xnnpack/litert/tensor/README.md')
before=(root/'tensor-README.before-memory.md').read_bytes()
draft=root/'repo-memory-followup.draft.md'
assert repo.read_bytes()==before+b'\n'+draft.read_bytes()
perf=json.loads((root/'perf-complete-20260914/perf_results/summary.json').read_text())
independent=json.loads((root/'perf-complete-20260914/PERF_REVIEW.json').read_text())
memory=json.loads((root/'analysis/results/memory.json').read_text())
assert perf['status']=='completed' and independent['status']=='passed' and memory['final_matrix_complete']
assert len(perf['processes'])==24 and len(perf['sessions'])==72
assert independent['processes']==24 and independent['sessions']==72 and independent['measured_decode_calls']==4608
checks=[]
for p in [root/'README.md',draft,repo,root/'analysis/README.md',root/'PERFORMANCE_COST_REVIEW.md']:
 text=p.read_text(); missing=[]; links=0
 for label,target in re.findall(r'\[([^]\n]+)\]\(([^)\n]+)\)',text):
  if target.startswith(('http:','https:','mailto:','#')): continue
  target=target.split('#')[0]
  q=Path(target) if target.startswith('/') else p.parent/target
  links+=1
  if not q.exists(): missing.append({'label':label,'target':target})
 fences=[line for line in text.splitlines() if line.startswith('```')]
 assert len(fences)%2==0,(p,'unbalanced fences')
 assert not missing,(p,missing)
 assert all(line.rstrip()==line for line in text.splitlines()),(p,'trailing whitespace')
 shells=re.findall(r'^```sh\n(.*?)^```',text,re.M|re.S)
 for shell in shells: subprocess.run(['bash','-n'],input=shell,text=True,check=True,capture_output=True)
 checks.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'links_checked':links,'missing_links':missing,'fences_balanced':True,'trailing_whitespace':False,'shell_blocks_syntax_checked_without_execution':len(shells)})

numeric=[]
for p in [root/'README.md',draft]:
 text=p.read_text(); perfrows=[]; memrows=[]
 for device,label in [('tecno','TECNO LJ9'),('pixel8','Pixel 8')]:
  for prompt in [128,1024]:
   c=next(c for c in perf['cells'] if c['device']==device and c['cell']==f'p{prompt}_t2')['backends']
   rates=[c[b]['decode_tokens_per_second']['median'] for b in ['litertlm','v4','candidate_both']]
   first=[c[b]['ttft_ms']['median']/1000 for b in ['litertlm','v4','candidate_both']]
   row=f'| {label} | {prompt} | '+' | '.join(f'{v:.2f}' for v in rates)+' | '+' / '.join(f'{v:.3f}' for v in first)+' |'
   assert row in text,(p,row);perfrows.append(row)
   values=[]
   for backend in ['litertlm_memory','baseline_memory','candidate_both']:
    capture=next(x for x in memory['captures'] if x['device']==device and x['backend']==backend and x['sessions'][0]['prompt_tokens']==prompt)
    event=next(x for x in capture['events'] if x['phase']=='after_last_decode' and x['repetition']==1)
    if p==root/'README.md':
     values.append(f"{event['metrics_bytes']['rss_bytes']/1048576:.1f} / {event['metrics_bytes']['pss_bytes']/1048576:.1f}")
    else:
     values.append(f"{event['metrics_bytes']['rss_bytes']/1048576:.1f}")
   row=f'| {label} | {prompt} | '+' | '.join(values)+' |'
   assert row in text,(p,row);memrows.append(row)
 numeric.append({'path':str(p),'performance_rows_from_raw_medians':perfrows,'memory_rows_from_raw_second_session_last_decode_bytes':memrows})

report={'status':'passed','repository_prefix_preserved_bytes':len(before),'append_starts_at_line':before.count(b'\n')+2,'files':checks,'numeric_tables':numeric,'source_reports':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'perf-complete-20260914/perf_results/summary.json',root/'perf-complete-20260914/PERF_REVIEW.json',root/'analysis/results/memory.json',root/'final-source-verification.json']},'no_commands_or_examples_executed_by_this_review':True}
(root/'DOC_REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'append_starts_at_line':report['append_starts_at_line'],'links_checked':sum(x['links_checked'] for x in checks),'repository_sha256':next(x['sha256'] for x in checks if x['path']==str(repo)),'shell_blocks_syntax_checked':sum(x['shell_blocks_syntax_checked_without_execution'] for x in checks)},indent=2))
