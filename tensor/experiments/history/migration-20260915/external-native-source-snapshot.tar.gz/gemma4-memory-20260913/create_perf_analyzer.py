from pathlib import Path
old=Path('/data/bt/tmp/gemma4-live-kv-20260913/analysis/summarize.py').read_text()
start=old.index('class InvalidCapture')
end=old.index('\ndef aggregate(')
s=old[start:end]
s=s.replace('def validate_process(record_path, cases):','def validate_process(record_path, cases, registry, root):')
s=s.replace("need(backend in BINARY_SHA, tag + ': unexpected backend')", "need(backend in BACKENDS, tag + ': unexpected backend')")
s=s.replace('BINARY_SHA[backend]', "registry[backend]['sha256']")
s=s.replace('BINARIES[backend]', "registry[backend]['remote']")
s=s.replace("threads in (2, 4) and prompt_length in (128, 512, 1024)","threads == 2 and prompt_length in (128, 1024)")
s=s.replace('0 <= block < 4','0 <= block < 6')
s=s.replace("order in (ORDER, ['litertlm', 'native', 'native', 'litertlm'])\n         and order[block] == backend, tag + ': not declared ABBA protocol'", "order == ORDER and order[block] == backend, tag + ': not declared ABC-CBA protocol'")
s=s.replace("comparison = order[1] + '_vs_litertlm'", "comparison = 'candidate_both_vs_litertlm_and_v4'")
s=s.replace("backend != 'final'", "backend == 'litertlm'")
s=s.replace("backend == 'final'", "backend in ('v4', 'candidate_both')")
s=s.replace("backend in ('native', 'final')", "backend in ('v4', 'candidate_both')")
s=s.replace("expected_runner = {'native': 'xnnpack_tensor_bundle_matched_window',\n                           'final': 'xnnpack_tensor_live_int8', 'litertlm': 'litert_lm_cpu'}[backend]", "expected_runner = 'litert_lm_cpu' if backend == 'litertlm' else 'xnnpack_tensor_live_int8'")
# Remove the unused original native-window branch.
a=s.index("        if backend == 'native':")
b=s.index("        elif backend in ('v4', 'candidate_both'):",a)
s=s[:a]+s[b:].replace("        elif backend in ('v4', 'candidate_both'):", "        if backend in ('v4', 'candidate_both'):",1)
# Enforce namespace, real source fixture, unique flags, diagnostics disabled.
a="    output = Path(record.get('output_directory', ''))"
insert="""    expected_tag = f'memperf_{cell}_b{block}_{backend}'
    need(record.get('tag') == expected_tag and record_path.name == expected_tag + '.command.json',
         tag + ': unexpected benchmark namespace/tag')
    need(fixture_file.resolve() == (root / 'fixtures' / f'performance_{prompt_length}_64.tsv').resolve(),
         tag + ': fixture outside this experiment')
    need(record.get('controller_sha256') == sha256(root / 'phone_runs.py'),
         tag + ': capture controller source hash differs; preserve original controller source')
    flag_tokens = [token for token in tokens if token.startswith('--')]
    need(all('=' in token for token in flag_tokens) and len(flag_tokens) == len(flags),
         tag + ': unsupported or duplicate actual command flags')
    allowed = {'cases_file', 'output_dir', 'num_threads', 'warmup_runs', 'measured_runs',
               'reuse_runtimes', 'dump_full_logits', 'trace_position', 'dump_cache',
               'memory_report', 'fixed_attention_extent', 'cache_capacity', 'prefill_chunk_rows',
               'kv_alignment'}
    allowed |= {'model_path', 'max_num_tokens'} if backend == 'litertlm' else {'bundle_dir'}
    if backend == 'candidate_both': allowed |= {'share_workspace', 'preserve_static_int2'}
    need(set(flags) <= allowed, tag + ': unreviewed actual command flag')
    for key, expected in [('memory_report', 'false'), ('fixed_attention_extent', 'false'),
                          ('cache_capacity', '2048'), ('prefill_chunk_rows', '128'), ('kv_alignment', '32')]:
        need(flags.get(key, expected) == expected, tag + ': diagnostic/shape flag mismatch: ' + key)
    if backend == 'candidate_both':
        need(flags.get('share_workspace') == 'true' and flags.get('preserve_static_int2') == 'true',
             tag + ': both candidate optimizations must be explicitly enabled')
    need(Path(flags.get('cases_file', '')).name == fixture_file.name and
         flags.get('output_dir') == record.get('remote_output_directory') and
         Path(flags.get('output_dir', '')).name == expected_tag,
         tag + ': command fixture/output mismatch')
"""
s=s.replace(a,insert+a)
s=s.replace("    need(output.is_absolute() and output.is_dir(), tag + ': missing absolute output directory')", "    need(output.is_absolute() and output.is_dir() and output.resolve() == (record_path.parent / expected_tag).resolve(), tag + ': missing/mismatched output directory')")
s=s.replace("    need(not list(output.rglob('*.f32')), tag + ': logit dumps present')", "    need(not list(output.rglob('*.f32')), tag + ': logit dumps present')\n    need(not (output / 'memory.jsonl').exists(), tag + ': diagnostic memory snapshots present')")
a="        if not warmup:\n            if backend == 'litertlm':"
insert="""        if backend == 'candidate_both':
            for key, expected in [('share_workspace', True), ('preserve_static_int2', True),
                                  ('memory_report', False), ('timings_valid_for_benchmark', True),
                                  ('static_int2_tensor_count', 60), ('static_int2_operator_count', 60),
                                  ('static_int2_compact_bytes', 283115520)]:
                need(run.get(key) == expected, str(path) + ': candidate metadata mismatch: ' + key)
        if warmup:
            need(run.get('run_index') == 0, str(path) + ': wrong warmup index')
"""
s=s.replace(a,insert+a)
s=s.replace("            'command_record': str(record_path), 'command_sha256': sha256(record_path),", "            'command_record': str(record_path), 'command_sha256': sha256(record_path),\n            'raw_files': [{'path': str(path), 'sha256': sha256(path)} for path in [record_path, output / 'run.json', *all_paths]],")
header='''#!/usr/bin/env python3
"""Validate/summarize the focused phone comparison; never runs inference or adb.

Reuse of validation/telemetry logic from the completed live-KV experiment is
recorded by source hash in each validation report. This file is self-contained.
"""
import argparse
import csv
import hashlib
import json
import math
import re
import shlex
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SERIALS = {'tecno': '144512553T000099', 'pixel8': '3A111FDJH005A0'}
MASKS = {'tecno': {2: 'c0'}, 'pixel8': {2: '180'}}
ORDER = ['litertlm', 'v4', 'candidate_both', 'candidate_both', 'v4', 'litertlm']
BACKENDS = ('litertlm', 'v4', 'candidate_both')
LABELS = {'litertlm': 'LiteRT-LM CPU', 'v4': 'Native v4', 'candidate_both': 'Native compact/shared'}
EXPECTED_CELLS = {'p128_t2', 'p1024_t2'}
STAGE_FIELDS = ('attention_run_ms', 'cache_handoff_or_update_ms',
                'projection_run_ms', 'post_attention_run_ms')
COPIED_VALIDATOR_SOURCE = '/data/bt/tmp/gemma4-live-kv-20260913/analysis/summarize.py'
COPIED_VALIDATOR_SHA256 = 'OLD_SHA'

'''.replace('OLD_SHA',__import__('hashlib').sha256(old.encode()).hexdigest())
Path('/data/bt/tmp/gemma4-memory-20260913/perf_analysis.py').write_text(header+s)
