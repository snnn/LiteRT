# Compact-weight and shared-workspace performance cost review

The memory reduction has a measurable decode cost on TECNO in both completed
128- and 1024-token experiments. The extra time is concentrated in the
post-attention stages, which contain the changed MLP operations. Pixel 8
improves slightly at both prompt lengths. These measurements establish a
device-dependent tradeoff; they do not establish whether compact weights or
workspace sharing causes it.

This is an offline review of saved captures and source. No phone commands,
Linux model benchmarks, or implementation changes were made for this review.
The user has accepted the remaining memory gap; this report does not propose
further memory optimization.

## Completed 128-token comparison

Each phone has six fresh processes in LiteRT-LM, native v4, candidate,
candidate, native v4, LiteRT-LM order. Each process discards one warmup and
measures three sessions. Sessions have 128 prompt tokens and 64 forced decode
tokens, two pinned CPU threads, and reused runtimes. Native capacity is 2048,
prefill chunks have 128 rows, and live attention extents have alignment 32.

| Phone | LiteRT-LM CPU, tok/s | Native v4, tok/s | Compact/shared, tok/s | Candidate vs v4 |
| --- | ---: | ---: | ---: | ---: |
| TECNO | 11.98 | 16.45 | 13.40 | 18.5% lower throughput |
| Pixel 8 | 12.88 | 16.60 | 17.47 | 5.2% higher throughput |

These are medians of the six session throughputs per runner. Each throughput
is `64000 / sum(64 decode elapsed_ms)`. The candidate remains 11.9% faster than
LiteRT-LM CPU on TECNO and 35.6% faster on Pixel 8 in this short-prompt cell.
This comparison does not measure cold startup or sustained generation beyond
the recorded 64 decode tokens.

For attribution, arithmetic means preserve additive timer totals. Each native
column below averages 384 measured decode calls, equally represented by six
sessions across two process blocks. Positive deltas mean that the candidate
took longer.

| Mean ms per decode | TECNO v4 | TECNO candidate | Delta | Pixel v4 | Pixel candidate | Delta |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Inclusive `elapsed_ms` | 60.904 | 74.717 | +13.812 | 59.838 | 56.478 | −3.360 |
| Post-attention stage runs | 40.081 | 52.302 | +12.221 | 41.323 | 39.141 | −2.182 |
| Q/K/V projection stage runs | 4.696 | 5.604 | +0.908 | 4.769 | 4.649 | −0.120 |
| Attention stage runs | 4.452 | 4.766 | +0.313 | 3.686 | 3.438 | −0.248 |
| KV append/read-output timer | 0.041 | 0.039 | −0.002 | 0.042 | 0.040 | −0.003 |
| Remaining inclusive work | 11.634 | 12.006 | +0.372 | 10.018 | 9.211 | −0.807 |

The post-attention increase accounts for **88.48% of TECNO's +13.812 ms**
inclusive mean increase. On Pixel, post-attention decreases by 2.182 ms,
accounting for 64.95% of its inclusive mean decrease. These fractions describe
where wall time moved, not a causal partition between the two feature flags.
The mean latency increase on TECNO is 22.7%; this differs from the 18.5%
throughput decrease because latency and throughput are reciprocals and the
headline throughput uses session medians.

TECNO's candidate slowdown appears in both process blocks:

| Runner | First process median (session range), tok/s | Second process median (session range), tok/s |
| --- | ---: | ---: |
| Native v4 | 16.76 (15.88–17.10) | 16.29 (15.95–16.61) |
| Compact/shared | 13.25 (13.18–13.70) | 13.56 (12.76–13.92) |

Even the fastest candidate session is slower than the slowest v4 session in
this cell. That supports a repeatable regression under the recorded conditions.
It does not remove possible contributions from scheduling, DVFS, cache behavior,
or the use of two different changes together. The phones used default frequency
governors. Before/after thermal snapshots had status zero; these snapshots do
not prove identical clocks or absence of frequency changes during each token.

## What the stage timers actually measure

[RunLiveTokens](variants/v1/memory-main.cc) accumulates one timer around every
`StageRunner::Run()` call. The same timed scopes are present in native v4.
[NnpackRunner::Run](../../os/xnnpack/litert/tensor/runners/common_nnpack/runner.cc)
performs input shape propagation, runtime reshape, output buffer reservation,
external-value locking/setup, and synchronous invocation. Therefore none of
the three stage timers is a kernel-only profile.

| Field | Scope |
| --- | --- |
| `projection_run_ms` | Sum of projection-stage `Run()` calls: Q and owner K/V projections, normalization/RoPE, and K/V output quantization. |
| `attention_run_ms` | Sum of attention-stage `Run()` calls: the two BMMs and intermediate score/mask/softmax operations, including runtime reshape/setup. Construction and binding of the mask and KV views occur outside this timer. |
| `post_attention_run_ms` | Sum of post-stage `Run()` calls across 35 decode layers: attention output projection, normalization/residual operations, MLP, per-layer embedding gating/projection, and final layer scale. |
| `cache_handoff_or_update_ms` | Reading newly computed K/V outputs and appending them to the persistent cache bank. This is not all cache-related work. |
| `forward_ms` | Sum of preprocessing, projection, attention, post, and tail stage `Run()` calls. It excludes work between stage calls. |
| Decode `elapsed_ms` | Complete forced-token call through reading logits and selecting argmax, including embedding lookup, bindings, mask construction, cache work, all stage runs, and surrounding control logic. JSON writing and logits dumping occur after this timestamp. |

The residual in the table is `elapsed − projection − attention − post − append`.
It includes preprocessing and the logits-head tail, plus everything outside
the timed stage calls. For TECNO its +0.372 ms change consists of +0.397 ms in
preprocessing/tail runs and −0.024 ms outside the stage and append timers;
small rounding differences are expected.

The graph cut is explicit in [attention.h](variants/v1/overlay/litert/tensor/examples/gemma4/helpers/attention.h)
and [gemma4_graph.h](variants/v1/overlay/litert/tensor/examples/gemma4/gemma4_graph.h).
The remainder of each layer is implemented by
[TransformerLayer](../../os/xnnpack/litert/tensor/examples/gemma4/helpers/transformer.h).
This verifies that the 60 changed gate/up/down MLP FCs in layers 15–34 fall
inside the post-attention timer. The timer also includes unchanged operations,
so +12.221 ms cannot be assigned exclusively to those 60 FCs.

## Source-supported explanation, with limits

The candidate enables both `--preserve_static_int2=true` and
`--share_workspace=true`. It changes 60 statically quantized MLP FCs from widened
QC4 weight storage to true QC2 storage; the runtime metadata audits 60 actual
QS8/QC2W operators. Static activation input/output quantization is retained.
The candidate also replaces 151 private scratch workspaces with one shared
arena. External stage outputs remain independently owned.

The checked Android build enables `XNN_ENABLE_ARM_DOTPROD=1` and
`XNN_ENABLE_ASSEMBLY=1`. The relevant dispatch in
[gemm-config.c](../../os/xnnpack/src/configs/gemm-config.c) differs:

| Static FC format | ARM64 dot-product configuration for one row |
| --- | --- |
| QS8/QC2W | `xnn_qs8_qc2w_gemm_minmax_fp32_ukernel_1x8c4__neondot`, eight output columns, C NEON intrinsics |
| QS8/QC4W | `xnn_qs8_qc4w_gemm_minmax_fp32_ukernel_1x16c4__asm_aarch64_neondot_ld128_2`, sixteen output columns, assembly |

[fully-connected-nc.c](../../os/xnnpack/src/operators/fully-connected-nc.c)
selects the one-row case when batch size is one and that case is available.
Both listed symbols are present in the frozen Android candidate binary,
confirmed with the NDK's `llvm-nm`. This is source/build evidence; **the actual
function pointers were not traced during the performance captures**.

The [QC2 kernel](../../os/xnnpack/src/qs8-qc2w-gemm/gen/qs8-qc2w-gemm-1x8c4-minmax-fp32-neondot.c)
extracts four signed 2-bit values per packed byte using shifts before dot
products. The [QC4 assembly kernel](../../os/xnnpack/src/qs8-qc4w-gemm/gen/qs8-qc4w-gemm-1x16-minmax-fp32-asm-aarch64-neondot-ld128.S)
uses a different packing, extraction sequence, and tile width. Smaller packed
weights reduce bytes read for those weights, but the decode kernel is also
different. **A plausible explanation** is that extraction, scheduling, or tile
efficiency costs outweigh the reduced weight traffic on TECNO, while Pixel
benefits from the smaller working set. The saved stage timings support
investigating this region; they do not prove that microkernel explanation.

The source for [workspace growth](../../os/xnnpack/src/runtime.c) allocates only
when the arena must grow, and repairs peer-runtime pointers when the arena
moves. It does not copy every stage's entire scratch allocation into or out of
the shared arena on every invocation. Sharing can nevertheless change cache
locality and reshape/setup behavior. The existing benchmark compares both flags
at once, so it cannot separate these effects. The QC2-only/shared-only memory
captures have diagnostic reads enabled and are not valid performance ablations.

The one-time source INT2 reconstruction happens during loading, before the
measured first-logit and decode scopes. It cannot directly explain the repeated
decode-time increase. The prefill prefix stops at the last KV owner, layer 14,
and therefore does not execute the changed layers 15–34. First-logit latency
includes that prefix plus one full decode of the final prompt token; it should
not be interpreted as a separate QC2 prefill benchmark.

## Completed 1024-token follow-up

The original long-prompt experiment was interrupted before its final baseline
blocks completed. Its partial results are not used for conclusions here. A
fresh complete six-block comparison per phone was collected in
[perf-complete-20260914](perf-complete-20260914/). It uses the same protocol with
1024 prompt tokens. This review combines the completed original 128-token cells
with the fresh complete 1024-token cells, without using the interrupted
long-prompt captures: 24 processes, 72 measured sessions, 4,608 decode calls.

| Phone | LiteRT-LM CPU, tok/s | Native v4, tok/s | Compact/shared, tok/s | Candidate vs v4 |
| --- | ---: | ---: | ---: | ---: |
| TECNO | 12.01 | 13.19 | 11.67 | 11.6% lower throughput |
| Pixel 8 | 12.69 | 14.16 | 14.67 | 3.6% higher throughput |

The candidate is 2.9% slower than LiteRT-LM CPU at the median on TECNO and
15.6% faster on Pixel 8 in this cell. Session ranges overlap the LiteRT-LM
baseline on both phones: TECNO candidate 11.11–12.91 versus baseline
11.77–12.29 tok/s, and Pixel candidate 14.12–15.20 versus baseline
12.57–14.84 tok/s. These are descriptive medians from two process blocks per
runner, not evidence of a fixed speedup across devices or workloads.

| Mean ms per decode | TECNO v4 | TECNO candidate | Delta | Pixel v4 | Pixel candidate | Delta |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Inclusive `elapsed_ms` | 76.687 | 85.379 | +8.692 | 70.583 | 67.921 | −2.662 |
| Post-attention stage runs | 41.638 | 50.762 | +9.125 | 41.539 | 39.426 | −2.113 |
| Q/K/V projection stage runs | 4.828 | 5.437 | +0.610 | 4.801 | 4.755 | −0.046 |
| Attention stage runs | 17.970 | 17.362 | −0.608 | 13.379 | 13.029 | −0.349 |
| KV append/read-output timer | 0.042 | 0.040 | −0.002 | 0.045 | 0.045 | +0.000 |
| Remaining inclusive work | 12.210 | 11.777 | −0.432 | 10.821 | 10.666 | −0.155 |

On TECNO the +9.125 ms post-attention increase exceeds the net +8.692 ms
increase because reductions elsewhere partly offset it. Both candidate process
medians, 11.71 and 11.63 tok/s, are below both v4 process medians, 12.90 and
13.25 tok/s. The post-stage regression therefore repeats at the longer prompt;
it is not an increase in attention time from the live KV extent. Pixel again
spends less time in the post stages, down 2.113 ms.

First-logit medians at 1024 are 7.801 s for v4 versus 7.756 s for the candidate
on TECNO, and 7.675 s versus 8.003 s on Pixel. The candidate does not improve
every timing metric. As discussed above, first logits include a prefix through
layer 14 plus one complete decode token, and are not a measurement of cold
loading or a many-row QC2 MLP.

## Reproduction and checks

[review_decode_cost.py](analysis/review_decode_cost.py) reads raw command and
session JSON independently of the primary performance analyzer. It verifies
the six-block order, successful processes, binary hashes, fixture hashes,
thread/affinity metadata, reuse/warmup/session counts, no dumps or memory
diagnostics, 64 decode steps, and identical token histories, positions, and
65 argmax values across all 18 sessions per phone/prompt cell. It checks all
4,680 recorded argmax rows across the four selected cells; these are repeated
histories, not 4,680 distinct numerical test cases. Source file hashes for
every consumed command/run/session JSON are retained in
[DECODE_COST_REVIEW.json](analysis/DECODE_COST_REVIEW.json). Full-vector numerical
correctness is covered separately in [CORRECTNESS.json](CORRECTNESS.json).

```sh
python3 analysis/review_decode_cost.py
# Include the completed fresh long-prompt cells:
python3 analysis/review_decode_cost.py \
  --rerun-root perf-complete-20260914
```

Both commands were run successfully. The saved JSON contains all four complete
cells. This report is a bounded diagnosis of the measured tradeoff, not a
proposal to change kernel dispatch or the accepted memory target.
