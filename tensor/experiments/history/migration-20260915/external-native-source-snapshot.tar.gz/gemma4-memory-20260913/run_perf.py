"""Focused phone comparison after the memory optimizations pass correctness."""
import argparse,json
from perf_phone_runs import ROOT,EXTRA_FLAGS,run_capture
p=argparse.ArgumentParser();p.add_argument('phone',choices=['tecno','pixel8']);a=p.parse_args()
if json.loads((ROOT/'CORRECTNESS.json').read_text())['status']!='passed':raise RuntimeError('Numerical gate incomplete')
records=list((ROOT/a.phone/'runs').glob('memory20260913_p*_candidate*.command.json'))
if len(records)!=5 or any(json.loads(p.read_text())['status']!='completed' for p in records):raise RuntimeError('Finish this phone memory captures first')
EXTRA_FLAGS['candidate_both']=['--share_workspace=true','--preserve_static_int2=true','--memory_report=false']
for length in [128,1024]:
 cell=f'p{length}_t2'
 for block,backend in enumerate(['litertlm','v4','candidate_both','candidate_both','v4','litertlm']):
  tag=f'memperf_{cell}_b{block}_{backend}'
  record=ROOT/a.phone/'runs'/(tag+'.command.json')
  if record.exists():
   if json.loads(record.read_text())['status']!='completed':raise RuntimeError('Incomplete prior capture '+tag)
   continue
  run_capture(a.phone,backend,ROOT/'fixtures'/f'performance_{length}_64.tsv',tag,
    threads=2,phase='benchmark',reuse=True,warmups=1,runs=3,dump=False,cell=cell,block_index=block)
