#!/usr/bin/env python3
"""Validate/summarize the focused phone comparison; never runs inference or adb.

Reuse of validation/telemetry logic from the completed live-KV experiment is
recorded by source hash in each validation report. This file is self-contained.
"""
import argparse
import csv
import hashlib
import json
import math
import re
import shlex
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SERIALS = {'tecno': '144512553T000099', 'pixel8': '3A111FDJH005A0'}
MASKS = {'tecno': {2: 'c0'}, 'pixel8': {2: '180'}}
ORDER = ['litertlm', 'v4', 'candidate_both', 'candidate_both', 'v4', 'litertlm']
BACKENDS = ('litertlm', 'v4', 'candidate_both')
LABELS = {'litertlm': 'LiteRT-LM CPU', 'v4': 'Native v4', 'candidate_both': 'Native compact/shared'}
EXPECTED_CELLS = {'p128_t2', 'p1024_t2'}
STAGE_FIELDS = ('attention_run_ms', 'cache_handoff_or_update_ms',
                'projection_run_ms', 'post_attention_run_ms')
COPIED_VALIDATOR_SOURCE = '/data/bt/tmp/gemma4-live-kv-20260913/analysis/summarize.py'
COPIED_VALIDATOR_SHA256 = 'da422c81d5135d393ed6f57f8be93d48ed0a872b30a6c80b59a15e814d5f2b3f'

class InvalidCapture(ValueError):
    pass


def need(condition, message):
    if not condition:
        raise InvalidCapture(message)


def read_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def positive(value, context):
    need(isinstance(value, (int, float)) and not isinstance(value, bool)
         and math.isfinite(value) and value > 0, context + ': expected finite positive time')
    return float(value)


def nonnegative(value, context):
    need(isinstance(value, (int, float)) and not isinstance(value, bool)
         and math.isfinite(value) and value >= 0, context + ': expected finite nonnegative time')
    return float(value)


def normalize_affinity(value):
    need(isinstance(value, (int, str)), 'missing affinity')
    if isinstance(value, int):
        return format(value, 'x')
    try:
        return format(int(value, 16), 'x')
    except ValueError as exc:
        raise InvalidCapture('invalid hexadecimal affinity') from exc


def distribution(values):
    need(bool(values), 'empty distribution')
    sorted_values = sorted(values)

    def percentile(fraction):
        at = fraction * (len(sorted_values) - 1)
        lo = int(at)
        return sorted_values[lo] + (at - lo) * (sorted_values[min(lo + 1, len(sorted_values) - 1)] - sorted_values[lo])

    return {'count': len(values), 'median': statistics.median(values),
            'min': min(values), 'max': max(values), 'mean': statistics.mean(values),
            'p10': percentile(.1), 'p90': percentile(.9), 'p95': percentile(.95)}


def load_fixtures(path):
    manifest = read_json(path)
    records = manifest.get('cases', manifest.get('fixtures'))
    need(isinstance(records, (list, dict)), 'fixture manifest needs cases list/mapping')
    if isinstance(records, dict):
        records = [dict(value, id=key) for key, value in records.items()]
    cases = {}
    for rec in records:
        if rec.get('kind') == 'correctness_gate':
            continue
        name = rec.get('id', rec.get('case_id'))
        prompt = rec.get('prompt_token_ids')
        forced = rec.get('forced_token_ids', rec.get('forced_decode_token_ids'))
        need(isinstance(name, str) and name not in cases, 'duplicate or missing fixture ID')
        need(isinstance(prompt, list) and isinstance(forced, list), name + ': missing raw histories')
        need(prompt and prompt[0] == 2, name + ': missing BOS2')
        need(all(isinstance(x, int) and not isinstance(x, bool) and 0 <= x < 262144
                 for x in prompt + forced), name + ': invalid token')
        need(len(prompt) in (128, 512, 1024) and len(forced) == 64,
             name + ': expected 128/512/1024 prompt and 64 forced tokens')
        need(len(prompt) + len(forced) <= 2048, name + ': exceeds capacity')
        cases[name] = {'prompt': prompt, 'forced': forced, 'metadata': rec}
        if rec.get('fixture_file'):
            fixture_path = Path(path).parent / rec['fixture_file']
            need(fixture_path.is_file(), name + ': missing fixture TSV')
            need(sha256(fixture_path) == manifest.get('files_sha256', {}).get(rec['fixture_file']),
                 name + ': fixture hash differs from manifest')
            expected_line = name + '\t' + ','.join(map(str, prompt)) + '\t' + ','.join(map(str, forced))
            need(fixture_path.read_text().strip() == expected_line, name + ': fixture TSV history differs')
    need(bool(cases), 'no fixtures')
    return cases


def telemetry_summary(record):
    result, warnings = {}, []
    for moment in ('before', 'after'):
        raw = record.get('telemetry_' + moment) or {}
        selected = {key: raw.get(key) for key in ('host_utc', 'thermal_status', 'cpu_c', 'skin_c',
                    'battery_c', 'battery_level', 'battery_temperature', 'frequency_policies', 'frequency_raw')}
        if selected['battery_c'] is None and isinstance(selected['battery_temperature'], (float, int)):
            selected['battery_c'] = selected['battery_temperature'] / 10
            selected['battery_c_source'] = 'dumpsys battery temperature in tenths Celsius'
        else:
            selected['battery_c_source'] = 'thermal HAL'
        result[moment] = selected
        for key in ('thermal_status', 'cpu_c', 'skin_c', 'battery_c'):
            if selected[key] is None:
                warnings.append(f'{moment}: {key} telemetry unavailable')
        if selected['thermal_status'] not in (None, 0):
            warnings.append(f"{moment}: Android thermal status {selected['thermal_status']}")
        if moment == 'before':
            for key, limit in (('cpu_c', 50), ('skin_c', 35), ('battery_c', 35)):
                if selected[key] is not None and selected[key] > limit:
                    warnings.append(f'{moment}: {key} exceeds the recorded cooldown threshold {limit}')
    samples = []
    for sample in record.get('process_samples', []):
        raw = sample.get('proc_stat_and_status_raw', '')
        parsed = {'elapsed_wall_seconds': sample.get('elapsed_wall_seconds'), 'pid': sample.get('pid')}
        first_line = raw.splitlines()[0] if raw else ''
        if ')' in first_line:
            fields = first_line.rsplit(')', 1)[1].split()
            if len(fields) >= 10:
                try:
                    parsed['minor_faults'] = int(fields[7])
                    parsed['major_faults'] = int(fields[9])
                except ValueError:
                    pass
        for key in ('VmRSS', 'VmHWM', 'VmSwap'):
            match = re.search(r'^' + key + r':\s*(\d+)\s+kB', raw, re.M)
            parsed[key + '_kib'] = int(match.group(1)) if match else None
        match = re.search(r'^Cpus_allowed_list:\s*(.*)', raw, re.M)
        parsed['cpus_allowed_list'] = match.group(1).strip() if match else None
        samples.append(parsed)
    valid_faults = [s['major_faults'] for s in samples if 'major_faults' in s]
    if valid_faults and valid_faults[-1] > valid_faults[0]:
        warnings.append('Major faults increased within sampled process interval; phase attribution unavailable')
    result['process_sampling'] = {'sample_count': len(samples), 'samples': samples,
        'major_faults_first_observed': valid_faults[0] if valid_faults else None,
        'major_faults_last_observed': valid_faults[-1] if valid_faults else None,
        'scope': 'Sampled process intervals include setup, warmup, inference and report I/O; not timed-decode-only counters.'}
    result['warnings'] = warnings
    result['cooldown_samples'] = record.get('cooldown_samples', [])
    result['cooldown_criteria'] = {'cpu_c_max': 50, 'skin_c_max': 35,
                                   'battery_c_max': 35, 'thermal_status': 0}
    return result


def validate_process(record_path, cases, registry, root):
    record = read_json(record_path)
    tag = str(record_path)
    need(record.get('phase') == 'benchmark', tag + ': not a performance capture')
    need(record.get('status') == 'completed', tag + ': incomplete process')
    device, backend = record.get('device'), record.get('backend')
    need(device in SERIALS and record.get('serial') == SERIALS[device], tag + ': unauthorized/mismatched device')
    need(record_path.parent.resolve() == (root / device / 'runs').resolve(),
         tag + ': record directory does not match declared device')
    need(backend in BACKENDS, tag + ': unexpected backend')
    need(record.get('timings_valid_for_benchmark') is True and record.get('process_returncode') == 0,
         tag + ': benchmark timing eligibility/process exit mismatch')
    need(record.get('binary_sha256') == registry[backend]['sha256'], tag + ': wrong frozen binary hash')
    fixture_file = Path(record.get('fixture_file', ''))
    need(fixture_file.is_file() and sha256(fixture_file) == record.get('fixture_sha256'),
         tag + ': fixture file/hash mismatch')
    threads, prompt_length = record.get('num_threads'), record.get('prompt_length')
    need(threads == 2 and prompt_length in (128, 1024), tag + ': unsupported cell')
    cell = f'p{prompt_length}_t{threads}'
    need(record.get('cell') == cell, tag + ': cell mismatch')
    affinity = normalize_affinity(record.get('affinity'))
    need(affinity == MASKS[device][threads], tag + ': unexpected affinity')
    block = record.get('block_index')
    need(isinstance(block, int) and 0 <= block < 6, tag + ': invalid block')
    order = record.get('order')
    need(order == ORDER and order[block] == backend, tag + ': not declared ABC-CBA protocol')
    comparison = 'candidate_both_vs_litertlm_and_v4'
    for key, expected in [('warmup_runs', 1), ('measured_runs', 3),
                          ('forced_tokens', 64), ('reuse_runtimes', True),
                          ('dump_full_logits', False)]:
        need(record.get(key) == expected, tag + ': unexpected ' + key)
    command = record.get('command')
    need(isinstance(command, list) and '-s' in command and 'shell' in command,
         tag + ': missing actual adb command')
    need(command[command.index('-s') + 1] == SERIALS[device], tag + ': command targets wrong device')
    tokens = shlex.split(command[command.index('shell') + 1])
    need('taskset' in tokens, tag + ': command missing affinity binding')
    at = tokens.index('taskset')
    need(normalize_affinity(tokens[at + 1]) == affinity and
         Path(tokens[at + 2]).name == registry[backend]['remote'], tag + ': actual command affinity/binary mismatch')
    flags = dict(token[2:].split('=', 1) for token in tokens if token.startswith('--') and '=' in token)
    for key, expected in [('num_threads', str(threads)), ('warmup_runs', '1'),
                          ('measured_runs', '3'), ('reuse_runtimes', 'true'), ('dump_full_logits', 'false')]:
        need(flags.get(key) == expected, tag + ': actual command flag mismatch: ' + key)
    need(flags.get('trace_position', '-1') == '-1'
         and flags.get('dump_cache', 'false') == 'false', tag + ': diagnostic tracing/cache dumps enabled')
    if backend == 'litertlm':
        need(Path(flags.get('model_path', '')).name == 'gemma-4-E2B-it.litertlm'
             and flags.get('max_num_tokens') == '2048', tag + ': actual model/context argument mismatch')
    else:
        need(Path(flags.get('bundle_dir', '')).name == 'matched-bundle',
             tag + ': actual matched-bundle argument mismatch')
    expected_tag = f'memperf_{cell}_b{block}_{backend}'
    need(record.get('tag') == expected_tag and record_path.name == expected_tag + '.command.json',
         tag + ': unexpected benchmark namespace/tag')
    need(fixture_file.resolve() == (root / 'fixtures' / f'performance_{prompt_length}_64.tsv').resolve(),
         tag + ': fixture outside this experiment')
    need(record.get('controller_sha256') == sha256(root / 'perf_phone_runs.py'),
         tag + ': capture controller source hash differs; preserve original controller source')
    flag_tokens = [token for token in tokens if token.startswith('--')]
    need(all('=' in token for token in flag_tokens) and len(flag_tokens) == len(flags),
         tag + ': unsupported or duplicate actual command flags')
    allowed = {'cases_file', 'output_dir', 'num_threads', 'warmup_runs', 'measured_runs',
               'reuse_runtimes', 'dump_full_logits', 'trace_position', 'dump_cache',
               'memory_report', 'fixed_attention_extent', 'cache_capacity', 'prefill_chunk_rows',
               'kv_alignment'}
    allowed |= {'model_path', 'max_num_tokens'} if backend == 'litertlm' else {'bundle_dir'}
    if backend == 'candidate_both': allowed |= {'share_workspace', 'preserve_static_int2'}
    need(set(flags) <= allowed, tag + ': unreviewed actual command flag')
    for key, expected in [('memory_report', 'false'), ('fixed_attention_extent', 'false'),
                          ('cache_capacity', '2048'), ('prefill_chunk_rows', '128'), ('kv_alignment', '32')]:
        need(flags.get(key, expected) == expected, tag + ': diagnostic/shape flag mismatch: ' + key)
    if backend == 'candidate_both':
        need(flags.get('share_workspace') == 'true' and flags.get('preserve_static_int2') == 'true',
             tag + ': both candidate optimizations must be explicitly enabled')
    need(Path(flags.get('cases_file', '')).name == fixture_file.name and
         flags.get('output_dir') == record.get('remote_output_directory') and
         Path(flags.get('output_dir', '')).name == expected_tag,
         tag + ': command fixture/output mismatch')
    output = Path(record.get('output_directory', ''))
    need(output.is_absolute() and output.is_dir() and output.resolve() == (record_path.parent / expected_tag).resolve(), tag + ': missing/mismatched output directory')
    index = read_json(output / 'run.json')
    need(index.get('status') == 'completed', tag + ': output not completed')
    expected_index = [('cases', 1)]
    if backend == 'litertlm':
        expected_index += [('warmup_runs', 1), ('measured_runs', 3), ('reuse_runtimes', True), ('num_threads', threads)]
    for key, expected in expected_index:
        need(index.get(key) == expected, tag + ': output ' + key + ' mismatch')
    need(not list(output.rglob('*.f32')), tag + ': logit dumps present')
    need(not (output / 'memory.jsonl').exists(), tag + ': diagnostic memory snapshots present')
    measured = sorted(output.glob('*.run_*.json'))
    warmups = sorted(output.glob('*.warmup_*.json'))
    need(len(measured) == 3 and len(warmups) == 1, tag + ': wrong warmup/measured file count')
    all_paths = warmups + measured
    sessions = []
    token_rows = []
    sequence = None
    case_name = None
    for path in all_paths:
        run = read_json(path)
        warmup = path in warmups
        name = run.get('case_id')
        need(name in cases and (case_name is None or case_name == name), tag + ': unexpected/mixed fixture')
        case_name = name
        fixture = cases[name]
        prompt, forced = fixture['prompt'], fixture['forced']
        expected_line = name + '\t' + ','.join(map(str, prompt)) + '\t' + ','.join(map(str, forced))
        need(fixture_file.read_text().strip() == expected_line, tag + ': command fixture history mismatch')
        need(len(prompt) == prompt_length, tag + ': prompt length mismatch')
        need(run.get('prompt_token_ids') == prompt and run.get('forced_decode_token_ids') == forced,
             str(path) + ': raw fixture history mismatch')
        need(run.get('warmup') is warmup, str(path) + ': warmup marker mismatch')
        need(run.get('num_threads') == threads and run.get('vocab_size') == 262144,
             str(path) + ': shape/thread configuration mismatch')
        need(run.get('reuse_runtimes' if backend in ('v4', 'candidate_both') else 'reused_runtimes') is True,
             str(path) + ': runtime reuse disabled')
        expected_runner = 'litert_lm_cpu' if backend == 'litertlm' else 'xnnpack_tensor_live_int8'
        need(run.get('runner') == expected_runner, str(path) + ': wrong executable variant')
        if backend in ('v4', 'candidate_both'):
            need(run.get('kv_capacity') == 2048 and run.get('kv_alignment') == 32
                 and run.get('fixed_attention_extent') is False and run.get('kv_dtype') == 'int8'
                 and run.get('kv_layout') == 'owner_position_channel' and run.get('prefill_rows') == 128,
                 str(path) + ': final cache/layout/prefill configuration mismatch')
        else:
            need(run.get('max_num_tokens') == 2048 and run.get('cache_policy') == ':memory'
                 and run.get('engine_metadata_settings_applied') is True
                 and run.get('context_magic_number_configuration_verified') is True,
                 str(path) + ': baseline configuration mismatch')
        if backend == 'candidate_both':
            for key, expected in [('share_workspace', True), ('preserve_static_int2', True),
                                  ('memory_report', False), ('timings_valid_for_benchmark', True),
                                  ('static_int2_tensor_count', 60), ('static_int2_operator_count', 60),
                                  ('static_int2_compact_bytes', 283115520)]:
                need(run.get(key) == expected, str(path) + ': candidate metadata mismatch: ' + key)
        if warmup:
            need(run.get('run_index') == (-1 if backend == 'litertlm' else 0),
                 str(path) + ': wrong warmup index')
        if not warmup:
            if backend == 'litertlm':
                need(run.get('runtime_setup_ms') == 0, str(path) + ': measured runtime compilation')
            if backend in ('v4', 'candidate_both'):
                need(run.get('compiled_this_run') is False, str(path) + ': measured native compile')
            else:
                need(run.get('runtime_reused') is True, str(path) + ': measured baseline not reused')
        passes = run.get('passes')
        need(isinstance(passes, list) and len(passes) == 65, str(path) + ': expected 65 passes')
        argmax = []
        elapsed = []
        stage_times = {key: [] for key in STAGE_FIELDS}
        for i, step in enumerate(passes):
            need(step.get('kind') == ('prefill' if i == 0 else 'decode')
                 and step.get('decode_index') == i, str(path) + ': pass schedule mismatch')
            need(step.get('input_ids') == (prompt if i == 0 else [forced[i - 1]])
                 and step.get('context_length_after') == prompt_length + i
                 and step.get('logits_position') == prompt_length + i - 1,
                 str(path) + ': consumed history/position mismatch')
            need(step.get('logits_file') is None, str(path) + ': logits dump enabled')
            predicted = step.get('argmax_id')
            need(isinstance(predicted, int) and 0 <= predicted < 262144, str(path) + ': invalid argmax')
            if backend == 'litertlm':
                need(step.get('consumed_token_ids_verified') is True
                     and step.get('executor_current_step_after') == prompt_length + i + 1,
                     str(path) + ': unverified executor history')
            ms = positive(step.get('elapsed_ms'), str(path))
            elapsed.append(ms)
            argmax.append(predicted)
            if backend in ('v4', 'candidate_both'):
                for key in STAGE_FIELDS:
                    stage_times[key].append(nonnegative(step.get(key), str(path) + ': ' + key))
                # These are nested diagnostic scopes, never the primary rate.
                need(sum(stage_times[key][-1] for key in STAGE_FIELDS) <= ms + .05,
                     str(path) + ': diagnostic scopes exceed inclusive timer')
                invocations = math.ceil((prompt_length - 1) / 128) + 1 if i == 0 else 1
                need(step.get('invocations') == invocations, str(path) + ': wrong prefill/decode chunk count')
            if not warmup:
                token_rows.append({'device': device, 'cell': cell, 'backend': backend,
                                   'comparison': comparison,
                                   'block_index': block, 'run_index': run.get('run_index'),
                                   'decode_index': i, 'context_length_after': prompt_length + i,
                                   'kind': step['kind'], 'elapsed_ms': ms, 'argmax_id': predicted,
                                   **{key: step.get(key) for key in STAGE_FIELDS}})
        need(sequence is None or sequence == argmax, str(path) + ': prediction sequence changed across session reset/reuse')
        sequence = argmax
        if backend == 'litertlm':
            need(math.isclose(sum(elapsed), run.get('inference_work_ms', float('nan')), rel_tol=1e-10, abs_tol=1e-6),
                 str(path) + ': total timer inconsistent')
        if warmup:
            continue
        run_index = run.get('run_index')
        need(run_index in (0, 1, 2), str(path) + ': invalid measured run index')
        rss = run.get('peak_process_rss_kib')
        need(isinstance(rss, (int, float)) and math.isfinite(rss) and rss > 0,
             str(path) + ': invalid peak RSS')
        sessions.append({'device': device, 'serial': record['serial'], 'cell': cell,
                         'comparison': comparison,
                         'backend': backend, 'num_threads': threads, 'affinity': affinity,
                         'prompt_length': prompt_length, 'block_index': block,
                         'run_index': run_index, 'ttft_ms': elapsed[0],
                         'decode_steps': 64, 'decode_total_ms': sum(elapsed[1:]),
                         'decode_ms_per_token': sum(elapsed[1:]) / 64,
                         'decode_tokens_per_second': 64000 / sum(elapsed[1:]),
                         'decode_token_latency_distribution_ms': distribution(elapsed[1:]),
                         'peak_process_rss_kib': rss, 'argmax_ids': argmax,
                         'diagnostic_scopes': {key: {
                             'prefill_total_ms': values[0], 'decode_total_ms': sum(values[1:]),
                             'decode_mean_ms_per_token': sum(values[1:]) / 64}
                             for key, values in stage_times.items() if values},
                         'run_file': str(path), 'command_record': str(record_path)})
    need({s['run_index'] for s in sessions} == {0, 1, 2}, tag + ': duplicate/missing session indices')
    process_peak_rss = positive(index.get('peak_process_rss_kib'), tag + ': process peak RSS')
    need(process_peak_rss >= max(s['peak_process_rss_kib'] for s in sessions),
         tag + ': final process peak RSS smaller than a session high-water mark')
    telemetry = telemetry_summary(record)
    expected_cpus = {i for i in range(64) if int(affinity, 16) & (1 << i)}
    for sample in telemetry['process_sampling']['samples']:
        allowed = sample.get('cpus_allowed_list')
        if allowed:
            cpus = set()
            for part in allowed.split(','):
                ends = [int(x) for x in part.split('-')]
                cpus.update(range(ends[0], ends[-1] + 1))
            need(cpus == expected_cpus, tag + ': observed process affinity mismatch')
    if not telemetry['process_sampling']['samples']:
        telemetry['warnings'].append('No process samples: actual runtime affinity/paging could not be checked')
    if not record.get('cooldown_samples'):
        telemetry['warnings'].append('No cooldown samples recorded')
    return {'device': device, 'cell': cell, 'backend': backend, 'block_index': block,
            'comparison': comparison, 'order': order, 'binary_sha256': record['binary_sha256'],
            'fixture_sha256': record['fixture_sha256'],
            'controller_sha256': record.get('controller_sha256'),
            'case_id': case_name, 'output_directory': str(output),
            'command_record': str(record_path), 'command_sha256': sha256(record_path),
            'raw_files': [{'path': str(path), 'sha256': sha256(path)} for path in [record_path, output / 'run.json', *all_paths]],
            'decode_tokens_per_second_median': statistics.median(s['decode_tokens_per_second'] for s in sessions),
            'ttft_ms_median': statistics.median(s['ttft_ms'] for s in sessions),
            'peak_process_rss_kib': process_peak_rss,
            'telemetry_before': record.get('telemetry_before'),
            'telemetry_after': record.get('telemetry_after'),
            'cooldown_samples': record.get('cooldown_samples', []),
            'telemetry_summary': telemetry}, sessions, token_rows


def aggregate(processes, sessions, allow_partial):
    grouped = defaultdict(list)
    for process in processes:
        grouped[(process['device'], process['cell'])].append(process)
    cells = []
    for (device, cell), blocks in sorted(grouped.items()):
        indices = [p['block_index'] for p in blocks]
        need(len(indices) == len(set(indices)), f'{device}/{cell}: duplicate process block')
        complete = set(indices) == set(range(6))
        need(allow_partial or complete, f'{device}/{cell}: incomplete ABC-CBA cell')
        item = {'device': device, 'cell': cell, 'complete': complete, 'backends': {}, 'comparisons': {}}
        sequences = {}
        for backend in BACKENDS:
            chosen = [s for s in sessions if s['device'] == device and s['cell'] == cell and s['backend'] == backend]
            if not chosen:
                continue
            own_blocks = sorted((p for p in blocks if p['backend'] == backend), key=lambda p: p['block_index'])
            need(len(chosen) == 3 * len(own_blocks), f'{device}/{cell}: inconsistent block/session counts')
            sequences[backend] = chosen[0]['argmax_ids']
            need(all(s['argmax_ids'] == sequences[backend] for s in chosen),
                 f'{device}/{cell}/{backend}: predictions differ across process blocks')
            metrics = {key: distribution([s[key] for s in chosen]) for key in
                       ('decode_tokens_per_second', 'decode_ms_per_token', 'ttft_ms', 'peak_process_rss_kib')}
            metrics.update({'label': LABELS[backend], 'measured_sessions': len(chosen),
                            'measured_decode_tokens': len(chosen) * 64, 'num_threads': 2,
                            'prompt_length': chosen[0]['prompt_length'], 'affinity': chosen[0]['affinity'],
                            'process_blocks': own_blocks,
                            'process_block_medians': {
                                'decode_tokens_per_second': distribution([p['decode_tokens_per_second_median'] for p in own_blocks]),
                                'ttft_ms': distribution([p['ttft_ms_median'] for p in own_blocks]),
                                'peak_process_rss_kib': distribution([p['peak_process_rss_kib'] for p in own_blocks])}})
            item['backends'][backend] = metrics
        for reference in ('litertlm', 'v4'):
            if reference not in item['backends'] or 'candidate_both' not in item['backends']:
                continue
            candidate, baseline = item['backends']['candidate_both'], item['backends'][reference]
            mismatches = [{'decode_index': i, 'context_length_after': baseline['prompt_length'] + i,
                           'reference_argmax': a, 'candidate_argmax': b}
                          for i, (a, b) in enumerate(zip(sequences[reference], sequences['candidate_both'])) if a != b]
            item['comparisons']['candidate_vs_' + reference] = {
                'decode_speedup': candidate['decode_tokens_per_second']['median'] / baseline['decode_tokens_per_second']['median'],
                'ttft_speedup': baseline['ttft_ms']['median'] / candidate['ttft_ms']['median'],
                'peak_rss_ratio': candidate['peak_process_rss_kib']['median'] / baseline['peak_process_rss_kib']['median'],
                'peak_rss_delta_mib': (candidate['peak_process_rss_kib']['median'] - baseline['peak_process_rss_kib']['median']) / 1024,
                'argmax_agreement': {'matches': 65 - len(mismatches), 'predictions': 65,
                                    'mismatches': mismatches,
                                    'scope': 'Metadata diagnostic; full-logit correctness is checked separately.'}}
        if len(sequences) == 3:
            matches = sum(len({values[i] for values in sequences.values()}) == 1 for i in range(65))
            item['cross_backend_argmax_agreement'] = {'matches': matches, 'predictions': 65,
                                                     'all_equal': matches == 65}
            need(matches == 65, f'{device}/{cell}: cross-backend argmax mismatch; investigate before reporting performance')
        cells.append(item)
    return cells


def write_csv(path, rows):
    if not rows:
        Path(path).write_text('')
        return
    with Path(path).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def render_markdown(summary):
    def value(d, factor=1, decimals=2):
        return f"{d['median'] / factor:.{decimals}f} ({d['min'] / factor:.{decimals}f}–{d['max'] / factor:.{decimals}f})"
    lines = ['# Compact-weight/shared-workspace phone comparison', '',
             f"Status: **{summary['status']}**; {len(summary['processes'])} processes, {len(summary['sessions'])} measured sessions, {len(summary['sessions']) * 64} measured decode calls.", '',
             'Each complete phone/prompt cell uses six fresh processes in LiteRT-LM, native v4, candidate, candidate, native v4, LiteRT-LM order. Every process reuses its compiled runtimes for one discarded warmup and three measured sessions. Each session contains 64 forced decode calls after first logits. Both phones use two pinned CPU threads; capacity is 2048 and input token IDs are identical.', '',
             'Values below are median (session minimum–maximum). Decode throughput is `64000 / sum(64 decode elapsed_ms)` per session. First-logit latency is the inclusive first pass `elapsed_ms`; no timing field is substituted.', '',
             '| Phone / prompt | Runner | Decode tok/s | First logits ms | Peak process RSS MiB |',
             '| --- | --- | ---: | ---: | ---: |']
    for cell in summary['cells']:
        for backend, m in cell['backends'].items():
            suffix = '' if cell['complete'] else ' (partial)'
            lines.append(f"| {cell['device']} / {m['prompt_length']}{suffix} | {LABELS[backend]} | {value(m['decode_tokens_per_second'])} | {value(m['ttft_ms'], decimals=1)} | {value(m['peak_process_rss_kib'], factor=1024, decimals=1)} |")
    lines += ['', '## Candidate comparisons', '',
              '| Phone / cell | Reference | Decode speedup | First-logit speedup | Peak RSS delta MiB | Argmax agreement |',
              '| --- | --- | ---: | ---: | ---: | ---: |']
    for cell in summary['cells']:
        for name, m in cell['comparisons'].items():
            lines.append(f"| {cell['device']} / {cell['cell']} | {name.removeprefix('candidate_vs_')} | {m['decode_speedup']:.3f}× | {m['ttft_speedup']:.3f}× | {m['peak_rss_delta_mib']:+.1f} | {m['argmax_agreement']['matches']}/65 |")
    lines += ['', 'Speedups above one favor the candidate; negative RSS deltas indicate less resident memory. Candidate changes preserve the original INT2 MLP weights and share one scratch workspace across sequential stages. Native v4 has the same live INT8 KV layout and 128-row chunked prefill but widened MLP weights and separate stage workspaces.', '',
              'Peak RSS is a process high-water mark, including loading, packing and warmup. Session values within one process are cumulative observations of the same process maximum, not independent steady-state allocations. Process-block RSS below uses the final `run.json` process peak. Memory phase diagnostics are excluded from these timing results.', '',
              '## Process block medians and session ranges', '',
              '| Phone / cell | Block | Runner | Decode tok/s median (range) | First logits ms median (range) | Process peak RSS MiB |',
              '| --- | ---: | --- | ---: | ---: | ---: |']
    for p in summary['processes']:
        chosen = [s for s in summary['sessions'] if s['device'] == p['device'] and s['cell'] == p['cell'] and s['block_index'] == p['block_index']]
        lines.append(f"| {p['device']} / {p['cell']} | {p['block_index']} | {p['backend']} | {value(distribution([s['decode_tokens_per_second'] for s in chosen]))} | {value(distribution([s['ttft_ms'] for s in chosen]), decimals=1)} | {p['peak_process_rss_kib'] / 1024:.1f} |")
    warnings = [{'device': p['device'], 'cell': p['cell'], 'block': p['block_index'], 'warning': w}
                for p in summary['processes'] for w in p['telemetry_summary']['warnings']]
    lines += ['', f"Telemetry/paging observations requiring review: {len(warnings)}; detailed before/after temperatures, clocks and process samples are retained in `summary.json`.", '',
              'Passive cooling is requested before every process. CPU clocks remain under the phone’s default DVFS policy, so descriptive ranges include clock and thermal variability. Process blocks are the independent repetition unit; tokens within sessions and sessions within one process are correlated. No token-level confidence intervals are claimed. Argmax agreement is a metadata check, not a substitute for the separate full-logit correctness tests.', '',
              '[JSON summary](summary.json), [validation and source hashes](validation.json), [cell metrics](cells.csv), [session rows](sessions.csv), [per-pass timings](passes.csv).', '']
    return '\n'.join(lines)


def chart(summary, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    cells = [c for c in summary['cells'] if c['complete']]
    if not cells:
        return
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.8))
    for ax, key, factor, title, ylabel in zip(axes,
            ['decode_tokens_per_second', 'ttft_ms', 'peak_process_rss_kib'],
            [1, 1000, 1024], ['Decode (higher is better)', 'First logits (lower is better)', 'Process peak RSS (lower is better)'],
            ['Tokens / second', 'Seconds', 'MiB']):
        for i, backend in enumerate(BACKENDS):
            data = [c['backends'][backend][key] for c in cells]
            median = [d['median'] / factor for d in data]
            errors = [[(d['median'] - d['min']) / factor for d in data],
                      [(d['max'] - d['median']) / factor for d in data]]
            ax.bar([n + (i - 1) * .25 for n in range(len(cells))], median,
                   width=.23, yerr=errors, capsize=2, label=LABELS[backend], color=['#757575', '#397bae', '#25834d'][i])
        ax.set_xticks(range(len(cells)), [c['device'] + '\n' + c['cell'].split('_')[0][1:] + ' tokens' for c in cells])
        ax.set_title(title); ax.set_ylabel(ylabel); ax.set_ylim(bottom=0)
        ax.grid(axis='y', alpha=.2); ax.set_axisbelow(True)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper center', bbox_to_anchor=(.5, .94),
               ncol=3, fontsize=9)
    fig.suptitle('Gemma4 E2B · 2 CPU threads · six sessions per backend · medians with session ranges')
    fig.tight_layout(rect=(0, 0, 1, .88))
    fig.savefig(out / 'comparison.svg'); fig.savefig(out / 'comparison.png', dpi=180)
    plt.close(fig)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--allow-partial', action='store_true')
    parser.add_argument('--chart', action='store_true')
    args = parser.parse_args(argv)
    root = args.root.resolve()
    out = (args.output or root / 'perf_results').resolve()
    out.mkdir(parents=True, exist_ok=True)
    processes, sessions, passes, skipped, ignored, inputs = [], [], [], [], [], []
    try:
        fixtures_path, registry_path = root / 'fixtures/manifest.json', root / 'binaries.json'
        cases, registry = load_fixtures(fixtures_path), read_json(registry_path)
        for backend in BACKENDS:
            entry = registry[backend]
            need(re.fullmatch('[0-9a-f]{64}', entry['sha256']) is not None, 'Invalid frozen binary hash')
            if 'local' in entry:
                need(sha256(entry['local']) == entry['sha256'], backend + ': frozen local binary hash differs')
        source_paths = [Path(__file__).resolve(), root / 'perf_phone_runs.py', root / 'run_perf.py', registry_path, fixtures_path]
        source_snapshots = out / 'source_snapshots'
        source_snapshots.mkdir(exist_ok=True)
        for path in source_paths:
            digest = sha256(path)
            snapshot = source_snapshots / (path.name + '.' + digest)
            if not snapshot.exists(): snapshot.write_bytes(path.read_bytes())
            need(sha256(snapshot) == digest, 'Source snapshot hash mismatch')
            inputs.append({'path': str(path), 'sha256': digest, 'source_snapshot': str(snapshot)})
        for path in sorted(root.glob('*/runs/*.command.json')):
            record = read_json(path)
            if record.get('phase') != 'benchmark':
                ignored.append({'path': str(path), 'phase': record.get('phase')})
                continue
            need(path.name.startswith('memperf_'), str(path) + ': unexpected benchmark tag')
            if record.get('status') != 'completed' and args.allow_partial:
                skipped.append({'path': str(path), 'status': record.get('status'), 'reason': 'benchmark process incomplete'})
                continue
            process, rows, token_rows = validate_process(path, cases, registry, root)
            processes.append(process); sessions.extend(rows); passes.extend(token_rows)
            inputs.extend(process['raw_files'])
        cells = aggregate(processes, sessions, args.allow_partial)
        missing = [{'device': d, 'cell': c} for d in SERIALS for c in sorted(EXPECTED_CELLS)
                   if not any(x['device'] == d and x['cell'] == c and x['complete'] for x in cells)]
        need(args.allow_partial or not missing, 'Full 4-cell matrix incomplete: ' + str(missing))
        if not missing:
            need(len(processes) == 24 and len(sessions) == 72 and len(passes) == 4680,
                 'Completed matrix must have 24 processes,72 sessions,4680 passes (4608 decode)')
        status = 'partial' if missing or skipped else 'completed'
        summary = {'schema_version': 1, 'status': status, 'order': ORDER,
                   'expected_processes': 24, 'expected_measured_sessions': 72, 'expected_measured_decode_calls': 4608,
                   'processes': processes, 'sessions': sessions, 'cells': cells,
                   'skipped_records': skipped, 'ignored_nonbenchmark_count': len(ignored),
                   'missing_or_incomplete_cells': missing,
                   'timing_metric': 'passes.elapsed_ms', 'decode_formula': '64000 / sum(64 decode elapsed_ms)',
                   'statistical_unit': 'process block; six session values are descriptive, nested in two blocks per backend',
                   'peak_rss_scope': 'Process lifetime high-water mark including startup,packing,warmup; session samples are cumulative',
                   'performance_executed_by_aggregator': False}
        validation = {'status': 'passed', 'capture_status': status,
                      'validated_processes': len(processes), 'validated_measured_sessions': len(sessions),
                      'validated_measured_decode_calls': len(sessions) * 64, 'validated_measured_passes': len(passes),
                      'copied_validator_source': COPIED_VALIDATOR_SOURCE,
                      'copied_validator_sha256': COPIED_VALIDATOR_SHA256,
                      'inputs': inputs, 'skipped_records': skipped, 'ignored_nonbenchmark_records': ignored}
        write_json(out / 'summary.json', summary); write_json(out / 'validation.json', validation)
        write_csv(out / 'sessions.csv', [{k:v for k,v in s.items() if not isinstance(v,(dict,list))} for s in sessions])
        write_csv(out / 'passes.csv', passes)
        rows = []
        for c in cells:
            for backend, m in c['backends'].items():
                row = {'device': c['device'], 'cell': c['cell'], 'backend': backend, 'complete': c['complete'], 'measured_sessions': m['measured_sessions']}
                for field in ('decode_tokens_per_second', 'ttft_ms', 'peak_process_rss_kib'):
                    for stat in ('median', 'min', 'max'):
                        row[field + '_' + stat] = m[field][stat]
                rows.append(row)
        write_csv(out / 'cells.csv', rows)
        (out / 'SUMMARY.md').write_text(render_markdown(summary))
        if args.chart: chart(summary, out)
        print(json.dumps({'status':status,'processes':len(processes),'sessions':len(sessions),'cells':len(cells),'output':str(out)}))
        return 0
    except (InvalidCapture, OSError, ValueError, TypeError, KeyError) as exc:
        write_json(out / 'validation.json', {'status':'failed','error':str(exc),'inputs_validated_before_failure':inputs})
        write_json(out / 'summary.json', {'status':'invalid','error':str(exc)})
        (out / 'SUMMARY.md').write_text('# Invalid performance summary\n\n' + str(exc) + '\n')
        for name in ('cells.csv','sessions.csv','passes.csv'): (out / name).write_text('')
        print(json.dumps({'status':'failed','error':str(exc)}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
