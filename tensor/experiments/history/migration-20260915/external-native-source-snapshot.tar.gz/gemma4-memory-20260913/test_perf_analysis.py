#!/usr/bin/env python3
"""Offline synthetic-schema regression tests; does not produce benchmark results."""
import copy
import importlib.util
import json
from pathlib import Path
import shlex
import shutil
import sys
import tempfile

ROOT=Path(__file__).resolve().parent
OLD=Path('/data/bt/tmp/gemma4-live-kv-20260913')
spec=importlib.util.spec_from_file_location('perf_analysis',ROOT/'perf_analysis.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
checks=[]
def expect_rejection(label, fn):
    try: fn()
    except a.InvalidCapture: checks.append(label); return
    raise AssertionError('Accepted invalid '+label)

with tempfile.TemporaryDirectory(prefix='synthetic_perf_analysis_',dir=ROOT/'analysis') as d:
    root=Path(d)
    shutil.copytree(ROOT/'fixtures',root/'fixtures')
    for name in ['binaries.json','perf_phone_runs.py','run_perf.py']:
        shutil.copy2(ROOT/name,root/name)
    registry=a.read_json(root/'binaries.json')
    records=[]
    for device in a.SERIALS:
        runroot=root/device/'runs';runroot.mkdir(parents=True)
        for prompt in (128,1024):
            for block,backend in enumerate(a.ORDER):
                oldbackend='litertlm' if backend=='litertlm' else 'final'
                oldblock=0 if backend=='litertlm' else 1
                oldtag=f'perf_p{prompt}_t2_b{oldblock}_{oldbackend}'
                source=OLD/device/'runs'/oldtag
                rec=a.read_json(source.with_name(oldtag+'.command.json'))
                tag=f'memperf_p{prompt}_t2_b{block}_{backend}'
                dest=runroot/tag;dest.mkdir()
                for f in source.glob('*.json'):
                    data=a.read_json(f)
                    if backend=='candidate_both' and f.name!='run.json':
                        data.update({'share_workspace':True,'preserve_static_int2':True,'memory_report':False,
                                     'timings_valid_for_benchmark':True,'static_int2_tensor_count':60,
                                     'static_int2_operator_count':60,'static_int2_compact_bytes':283115520})
                    a.write_json(dest/f.name,data)
                rec.update({'tag':tag,'backend':backend,'block_index':block,'order':a.ORDER,
                            'binary_sha256':registry[backend]['sha256'],'output_directory':str(dest),
                            'fixture_file':str(root/'fixtures'/f'performance_{prompt}_64.tsv'),
                            'controller_sha256':a.sha256(root/'perf_phone_runs.py')})
                remote=Path(rec['remote_output_directory']).parent/tag
                rec['remote_output_directory']=str(remote)
                flags=['taskset',rec['affinity'],'/synthetic/'+registry[backend]['remote'],
                       '--num_threads=2','--warmup_runs=1','--measured_runs=3','--reuse_runtimes=true',
                       '--dump_full_logits=false','--cases_file=/synthetic/'+f'performance_{prompt}_64.tsv',
                       '--output_dir='+str(remote)]
                if backend=='litertlm':flags+=['--model_path=/synthetic/gemma-4-E2B-it.litertlm','--max_num_tokens=2048']
                else:flags+=['--bundle_dir=/synthetic/matched-bundle']
                if backend=='candidate_both':flags+=['--share_workspace=true','--preserve_static_int2=true','--memory_report=false']
                rec['command']=['adb','-s',a.SERIALS[device],'shell',shlex.join(flags)]
                path=runroot/(tag+'.command.json');a.write_json(path,rec);records.append(path)
    cases=a.load_fixtures(root/'fixtures/manifest.json')
    processes,sessions,passes=[],[],[]
    for path in records:
        p,s,t=a.validate_process(path,cases,registry,root)
        processes.append(p);sessions+=s;passes+=t
    assert len(processes)==24 and len(sessions)==72 and len(passes)==4680
    cells=a.aggregate(processes,sessions,False)
    assert len(cells)==4 and all(c['complete'] for c in cells)
    assert all(c['cross_backend_argmax_agreement']['all_equal'] for c in cells)
    assert all(c['comparisons']['candidate_vs_v4']['decode_speedup']==1 for c in cells)
    checks.append('24-process72-session full synthetic protocol accepted and identical-reference ratio exactly1')
    for session in sessions:
        raw=a.read_json(session['run_file'])
        assert session['decode_tokens_per_second']==64000/sum(p['elapsed_ms'] for p in raw['passes'][1:])
        assert session['ttft_ms']==raw['passes'][0]['elapsed_ms']
    checks.append('independent raw inclusive decode sum and first-logit calculation')
    expect_rejection('duplicate blocks',lambda:a.aggregate(processes+[processes[0]],sessions,False))
    expect_rejection('incomplete strict matrix cell',lambda:a.aggregate(processes[1:],sessions[3:],False))
    altered=copy.deepcopy(sessions)
    for session in altered:
        if session['backend']=='candidate_both':session['argmax_ids'][1]=(session['argmax_ids'][1]+1)%262144
    expect_rejection('cross-backend argmax difference',lambda:a.aggregate(processes,altered,False))
    path=next(p for p in records if '_b2_candidate_both.' in p.name)
    original=a.read_json(path)
    for key,value in [('binary_sha256','0'*64),('order',list(reversed(a.BACKENDS))),
                      ('phase','memory'),('affinity','ff'),('num_threads',4),
                      ('fixture_sha256','0'*64),('status','running'),('dump_full_logits',True)]:
        bad=copy.deepcopy(original);bad[key]=value;a.write_json(path,bad)
        expect_rejection('wrong '+key,lambda:a.validate_process(path,cases,registry,root))
    a.write_json(path,original)
    sessionpath=next(Path(original['output_directory']).glob('*.run_000.json'))
    run=a.read_json(sessionpath)
    for key,value in [('static_int2_operator_count',59),('static_int2_compact_bytes',1),('memory_report',True),
                      ('share_workspace',False),('preserve_static_int2',False),('compiled_this_run',True)]:
        bad=copy.deepcopy(run);bad[key]=value;a.write_json(sessionpath,bad)
        expect_rejection('wrong '+key,lambda:a.validate_process(path,cases,registry,root))
    a.write_json(sessionpath,run)
    bad=copy.deepcopy(original);bad['command'][-1]+=' --num_threads=2';a.write_json(path,bad)
    expect_rejection('duplicate flags',lambda:a.validate_process(path,cases,registry,root))
    a.write_json(path,original)
    memory=Path(original['output_directory'])/'memory.jsonl';memory.write_text('{}\n')
    expect_rejection('memory diagnostics present',lambda:a.validate_process(path,cases,registry,root))
    memory.unlink()
    assert a.main(['--root',str(root),'--output',str(root/'results')] +
                  (['--chart'] if '--chart' in sys.argv else []))==0
    checks.append('complete CLI/report generation')
    if '--chart' in sys.argv:
        assert (root/'results/comparison.svg').stat().st_size > 1000
        assert (root/'results/comparison.png').stat().st_size > 1000
        checks.append('three-panel chart generation')
    report=a.read_json(root/'results/validation.json')
    assert report['validated_measured_decode_calls']==4608
    assert len(report['inputs'])==149
    checks.append('source and all raw command/index/session hashes retained')
result={'status':'passed','scope':'Synthetic-schema offline tests only; no new inference/performance samples',
        'analyzer_sha256':a.sha256(ROOT/'perf_analysis.py'),'checks':checks,'check_count':len(checks)}
a.write_json(ROOT/'analysis/perf_analyzer_test.json',result)
print(json.dumps({'status':'passed','checks':len(checks)}))
