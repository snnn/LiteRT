# Preserving published static INT2 MLP weights

This local adapter preserves all 60 original INT2 MLP matrices in Gemma4 E2B
layers 15–34. It keeps the original static INT8 activation scales and zero
points. The existing dynamic INT2 output head is a separate path.

## Implementation

[matched_bundle_loader.h](matched_bundle_loader.h) validates the fixed bundle's
source section, subgraph, tensor identity, source dtype, shape, byte count and
quantization metadata. Selection requires the original `INT2` provenance;
small numeric codes alone never select the compact path. Each selected widened
I4 mapping is repacked once, checking every code is in `[-2,1]`, then unmapped.

[static_int2_fully_connected.h](overlay/litert/tensor/examples/gemma4/helpers/static_int2_fully_connected.h)
provides an immutable owned compact buffer with its original source metadata.
The frontend already supports `Type::kI2`, so the type, matrix shape, buffer
byte count and readable span all describe actual two-bit storage. No shape or
size fields are repurposed. The custom lowering defines QCINT2 weights directly
because the ordinary XNNPACK conversion currently maps `Type::kI2` to QCINT4.
Graph keep-alive references retain the same compact buffer across stages;
there is no per-stage copy or repeated repacking.

[mobile_fully_connected.h](overlay/litert/tensor/examples/gemma4/helpers/mobile_fully_connected.h)
retains the original FP32-to-static-INT8 cast, routes only the explicit I2
weights through `StaticInt2FullyConnected`, then retains the original static
INT8-to-FP32 output conversion. It does not introduce dynamic input quantization.
The authored and executed FC path is static QS8/QC2W/QS8.

The loader setting is `SetPreserveStaticInt2Weights(bool)`. It only affects
future loads; existing weights keep their representation. The experiment's
main driver controls it with `--preserve_static_int2`.

## Accounting and runtime checks

`GetStaticInt2WeightAudit(loaded.weights_handle)` returns the number of compact
weights, replaced widened payload, compact payload, actual vector capacity
including padding, and number of custom lowerings. Expected values after load:

| Category | Bytes |
| --- | ---: |
| Widened MLP payload replaced | 566,231,040 (540 MiB) |
| Compact MLP payload retained | 283,115,520 (270 MiB) |
| Compact allocation including padding | 283,116,480 |

These are exact source-buffer counts, not RSS or packed-kernel allocation
estimates. The compact source representation alone removes 270 MiB of retained
payload. Kernel-packed weights are independently accounted by the driver.

`CountStaticInt2RuntimeOperators(runtime)` examines actual operator objects and
requires QS8/QC2W FC with QINT8/QCINT2/QINT8 edges. The separate dynamic output
head is excluded. All 60 static operators are in decode, because cache-only
prefill stops before layer 15.

## Completed validation

- [Focused Linux test](static_int2_test.linux.log): 450,246 checks, 75 reshaped
  FC invocations and 73,416 output floats bitwise equal to QC4. Shapes include
  one-row decode, 2/7/128 rows and shrinking back to one row; input widths include
  1,536 and 12,288. Inputs include exact activation half-step boundaries,
  adjacent representable FP32 values, saturation and signed random values.
  The test also verifies actual static QS8/QC2W execution, all packed codes,
  immutable buffer metadata and rejection of invalid provenance/code ranges.
- [Full loader test](static_int2_loader_test.linux.log): all 60 compact tensors
  have the expected byte counts, and every widened MLP mapping is absent from
  `/proc/self/maps` after load.
- [Independent manifest verification](static_int2_manifest_verification.json):
  all 60 reconstructed compact payload hashes match the original published
  source hashes exactly. All 1,132,462,080 codes, export file hashes, per-channel
  scales and 120 scalar activation-scale files were checked.
- [Android focused-test executable](static_int2_test.android) was built; phone
  execution and full-model checks are coordinated separately by the parent task.

Reproduce on Linux without collecting performance measurements:

```sh
python3 build-probe.py linux static_int2_test.cc
./static_int2_test.linux
python3 build-probe.py linux static_int2_loader_test.cc
./static_int2_loader_test.linux /path/to/matched-bundle
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 verify_static_int2_manifest.py
```

The manifest verifier uses the recorded local bundle path. These focused tests
support this specific adapter and backend configuration; full-model numerical
validation remains a separate requirement before reporting a replacement result.
