"""Separate allocation ablations; no benchmark timing claims."""
import argparse,json
from phone_runs import ROOT,REMOTE,EXTRA_FLAGS,run_capture
p=argparse.ArgumentParser();p.add_argument('phone',choices=['tecno','pixel8']);a=p.parse_args()
report=json.loads((ROOT/'CORRECTNESS.json').read_text())
if report['status']!='passed':raise RuntimeError('Complete full numerical gate first')
for backend,share,qc2 in [('candidate_none',False,False),('candidate_qc2',False,True),('candidate_shared',True,False),('candidate_both',True,True)]:
 EXTRA_FLAGS[backend]=['--memory_report=true','--share_workspace='+str(share).lower(),'--preserve_static_int2='+str(qc2).lower()]
for length,backend in [(128,'candidate_none'),(128,'candidate_qc2'),(128,'candidate_shared'),(128,'candidate_both'),(1024,'candidate_both')]:
 tag=f'memory20260913_p{length}_{backend}'
 record=ROOT/a.phone/'runs'/(tag+'.command.json')
 if record.exists():
  if json.loads(record.read_text())['status']!='completed':raise RuntimeError('Incomplete previous capture '+tag)
  continue
 run_capture(a.phone,backend,ROOT/'fixtures'/f'performance_{length}_64.tsv',tag,
   threads=2,phase='memory',reuse=True,warmups=0,runs=2,dump=False,cell=f'p{length}_t2')
