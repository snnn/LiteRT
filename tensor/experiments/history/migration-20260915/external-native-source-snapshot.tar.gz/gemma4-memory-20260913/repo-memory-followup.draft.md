### Follow-up: compact INT2 MLP weights and shared stage scratch

The next [local Gemma4 E2B experiment](/data/bt/tmp/gemma4-memory-20260913/README.md)
addresses two memory costs left by the live-KV v4 adapter. It reconstructs the
original two-bit coefficients for the 60 gate/up/down MLP matrices in layers
15–34 and dispatches them through static QS8/QC2W fully connected operators.
The published activation and per-channel weight scales are preserved. Their
raw coefficient payload changes from 540 MiB to 270 MiB, and their widened
source mappings are released. Independent
[source verification](/data/bt/tmp/gemma4-memory-20260913/static_int2_manifest_verification.json)
matches all 60 reconstructed streams to the original source hashes.
The compact reconstruction happens once during loading. First-logit benchmarks
exclude model loading and compilation, so they do not measure this additional
loading work or establish a cold-start improvement.

The 151 prefill/decode stage runtimes can also share one XNNPACK scratch arena.
Stages execute sequentially; their externally visible outputs remain in
separate buffers for later consumers. XNNPACK grows the arena when necessary
and repairs sharing runtimes' pointers. The driver retains ownership until
all stage runtimes are destroyed. KV storage remains one 18 MiB INT8 bank at
capacity 2048, with the preceding chunked-prefill and live-attention behavior.

The frozen candidate enables both changes with
`--preserve_static_int2=true --share_workspace=true`; both CLI options default
to false. Its [numerical gate](/data/bt/tmp/gemma4-memory-20260913/CORRECTNESS.json)
passes **199/199 full-logit vectors bitwise** against same-phone LiteRT-LM CPU
references on TECNO LJ9 and Pixel 8. Each phone also passes 103 shared-workspace
checks with 4,071,360 compared floats and 73,416 static-QC2/QC4 FC output values.
A separate [Linux correctness smoke](/data/bt/tmp/gemma4-memory-20260913/linux-smoke-comparison.json)
passes three full-logit vectors. These are recorded correctness diagnostics,
not universal numerical-equivalence or model-quality guarantees.

The [completed memory matrix](/data/bt/tmp/gemma4-memory-20260913/analysis/results/MEMORY.md)
contains 18 processes and 36 sessions. It compares all four combinations of
compact weights and shared scratch at prompt 128, plus the combined candidate
at prompt 1024, with preceding native v4 and LiteRT-LM CPU observations.
Current RSS after the second session's last decode is:

| Phone | Prompt | LiteRT-LM RSS (MiB) | Native v4 RSS (MiB) | Combined candidate RSS (MiB) |
| --- | ---: | ---: | ---: | ---: |
| TECNO LJ9 | 128 | 1601.7 | 2634.2 | 1908.1 |
| TECNO LJ9 | 1024 | 2015.7 | 2779.6 | 1998.6 |
| Pixel 8 | 128 | 1516.9 | 2637.5 | 1897.8 |
| Pixel 8 | 1024 | 2004.7 | 2785.3 | 1988.8 |

The combined candidate reduces current RSS by 726–797 MiB relative to v4.
The source payload and recorded packed-weight capacity each fall by 270 MiB.
Unique scratch falls from 197–268 MiB to one 8.75 MiB arena on TECNO or one
9.13 MiB arena on Pixel. The remaining current-RSS gap versus LiteRT-LM is
306–381 MiB at prompt 128; at prompt 1024 the candidate is about 16–17 MiB lower
in these observations. The report keeps PSS and lifetime peak separate and
does not assign every resident byte to one allocation category. All 1820
native argmax rows in the memory captures match the same-phone LM references.
The earlier 60-matrix widening limitation applies to historical v4, not this
combined candidate.

The [completed focused performance report](/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914/perf_results/SUMMARY.md)
contains **24 selected processes and 72 measured sessions**, covering two
threads at prompts 128 and 1024 on both phones. Each cell uses the process
order LiteRT-LM, v4, candidate, candidate, v4, LiteRT-LM, with one warmup and
three measured sessions per process and 64 forced decode calls per session.
Each value below is a median of six measured sessions from two process blocks
per backend/cell, using inclusive `elapsed_ms`.

| Phone | Prompt | LiteRT-LM decode (tok/s) | Native v4 decode (tok/s) | Combined candidate decode (tok/s) | First logits, LM / v4 / candidate (s) |
| --- | ---: | ---: | ---: | ---: | ---: |
| TECNO LJ9 | 128 | 11.98 | 16.45 | 13.40 | 1.243 / 0.840 / 0.842 |
| TECNO LJ9 | 1024 | 12.01 | 13.19 | 11.67 | 11.966 / 7.801 / 7.756 |
| Pixel 8 | 128 | 12.88 | 16.60 | 17.47 | 1.444 / 0.789 / 0.751 |
| Pixel 8 | 1024 | 12.69 | 14.16 | 14.67 | 11.108 / 7.675 / 8.003 |

Relative to native v4, the candidate's median decode throughput is **18.5%
lower at prompt 128 and 11.6% lower at prompt 1024 on TECNO**. Pixel's median
throughput is **5.2% and 3.6% higher**, respectively. Against LiteRT-LM CPU,
the candidate is 11.9% faster on TECNO at 128 tokens but 2.9% slower at 1024;
on Pixel it is 35.6% and 15.6% faster. Its first-logit latency is lower than
LiteRT-LM in all four cells. Against v4, first-logit differences are small on
TECNO; Pixel improves at 128 but takes 4.3% longer at 1024. These are measured
medians under default DVFS, with session and process ranges retained in the
report; small differences are not claims of a universal speedup. Three Pixel
process blocks recorded increases in sampled major-fault counters; the samples
do not identify which execution phase incurred those faults.

First-logit time includes session initialization, prefill, and the final prompt
token's decode. Both first-logit and decode timings include reading logits
and selecting the validation argmax; they exclude loading, compilation,
tokenization, and generation-policy sampling. Memory diagnostics and dumps
are disabled for timing captures. The
[stage/source cost review](/data/bt/tmp/gemma4-memory-20260913/PERFORMANCE_COST_REVIEW.md)
locates most of TECNO's added time in post-attention stages containing the
changed MLP operations. It does not isolate QC2 kernel cost from shared-workspace
effects or other work in those stages. The memory savings have a measured
performance cost on TECNO; this is not a universal speed improvement.

The [selected performance matrix](/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914/)
preserves the completed prompt-128 cells from the original attempt. An
interruption left the final long-prompt processes incomplete; both prompt-1024
cells were rerun as complete six-process sequences in a fresh capture namespace.
The [selection record](/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914/selection.json)
preserves the original hashes and explains the excluded captures. Frozen
executables, models, and protocol are unchanged. No cell combines sessions
from the two attempts. The selected count excludes the preserved long-prompt
captures from the interrupted attempt.

Memory comparisons use `after_last_decode`, while both implementations still
retain KV. Native releases its bank before `after_session`; LiteRT-LM retains
executor-owned KV at that phase. Source-buffer bytes are mapped/owned payload,
not resident pages; allocation counters and RSS/PSS are not additive.
Quantization metadata and general allocator overhead remain outside the
enumerated totals. The output head's 96 MiB reconstruction buffer and retained
external outputs are further costs beyond the shared scratch optimization.

The experiment guide links frozen source/binary hashes, exact build and capture
commands, component tests, and phone rerun instructions assuming `ANDROID_HOME`
is set. These commands regenerate saved numerical and memory reports without
device execution. The numerical comparison requires NumPy; the recorded run
used the converter's existing NumPy environment with one BLAS thread. Use
`python3` below only when that interpreter has NumPy installed:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  python3 /data/bt/tmp/gemma4-memory-20260913/check_correctness.py
python3 /data/bt/tmp/gemma4-memory-20260913/analysis/memory.py --expect-final-matrix
```

Both validations have passed for the completed correctness and memory matrices.
The selected performance report and standalone chart also passed strict
offline analysis. The separate
[independent review](/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914/PERF_REVIEW.json)
passes all 24 selected processes, 72 sessions, and 4608 measured decode calls,
including source hashes, non-overlapping process order, and recomputed medians:

```sh
GEMMA_PERF_ROOT=/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  uv run --no-project --with matplotlib python \
  /data/bt/tmp/gemma4-memory-20260913/perf_analysis.py --root "$GEMMA_PERF_ROOT" --chart
```

The remaining memory difference is within this local experiment's scope;
further memory changes are not part of this campaign. Fresh phone runs require
a new capture namespace. No Samsung/S25 tests
or Linux-host model-performance benchmarks are included. The implementation
remains local testing code outside the checkout.
