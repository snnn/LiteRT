# Compact-weight/shared-workspace phone comparison

Status: **partial**; 18 processes, 54 measured sessions, 3456 measured decode calls.

Each complete phone/prompt cell uses six fresh processes in LiteRT-LM, native v4, candidate, candidate, native v4, LiteRT-LM order. Every process reuses its compiled runtimes for one discarded warmup and three measured sessions. Each session contains 64 forced decode calls after first logits. Both phones use two pinned CPU threads; capacity is 2048 and input token IDs are identical.

Values below are median (session minimum–maximum). Decode throughput is `64000 / sum(64 decode elapsed_ms)` per session. First-logit latency is the inclusive first pass `elapsed_ms`; no timing field is substituted.

| Phone / prompt | Runner | Decode tok/s | First logits ms | Peak process RSS MiB |
| --- | --- | ---: | ---: | ---: |
| pixel8 / 1024 (partial) | LiteRT-LM CPU | 14.17 (12.53–14.27) | 9910.2 (9887.7–10117.8) | 2125.1 (2125.1–2125.1) |
| pixel8 / 1024 (partial) | Native v4 | 14.66 (13.87–14.67) | 6282.3 (5913.8–8313.6) | 2779.9 (2779.9–2779.9) |
| pixel8 / 1024 (partial) | Native compact/shared | 15.58 (14.32–15.59) | 6206.5 (6189.1–6766.6) | 1983.5 (1983.5–1983.5) |
| pixel8 / 128 | LiteRT-LM CPU | 12.88 (12.62–14.25) | 1444.3 (1379.2–1501.5) | 1606.8 (1599.3–1614.3) |
| pixel8 / 128 | Native v4 | 16.60 (16.14–17.51) | 789.1 (671.1–861.7) | 2642.7 (2642.6–2642.8) |
| pixel8 / 128 | Native compact/shared | 17.47 (17.18–19.21) | 751.2 (599.4–919.4) | 1900.4 (1900.3–1900.6) |
| tecno / 1024 (partial) | LiteRT-LM CPU | 12.09 (12.00–12.10) | 12153.7 (11821.9–12237.4) | 2117.6 (2117.4–2117.6) |
| tecno / 1024 (partial) | Native v4 | 12.73 (12.43–13.13) | 7829.1 (7753.5–7893.2) | 2788.4 (2788.4–2788.4) |
| tecno / 1024 (partial) | Native compact/shared | 11.35 (11.03–11.60) | 7811.1 (7776.3–7903.5) | 2007.6 (2007.6–2007.6) |
| tecno / 128 | LiteRT-LM CPU | 11.98 (11.85–12.10) | 1243.0 (1204.5–1262.6) | 1610.0 (1608.3–1611.7) |
| tecno / 128 | Native v4 | 16.45 (15.88–17.10) | 840.2 (769.8–911.4) | 2639.2 (2639.2–2639.2) |
| tecno / 128 | Native compact/shared | 13.40 (12.76–13.92) | 842.3 (810.3–950.9) | 1913.6 (1913.5–1913.6) |

## Candidate comparisons

| Phone / cell | Reference | Decode speedup | First-logit speedup | Peak RSS delta MiB | Argmax agreement |
| --- | --- | ---: | ---: | ---: | ---: |
| pixel8 / p1024_t2 | litertlm | 1.099× | 1.597× | -141.6 | 65/65 |
| pixel8 / p1024_t2 | v4 | 1.062× | 1.012× | -796.4 | 65/65 |
| pixel8 / p128_t2 | litertlm | 1.356× | 1.923× | +293.7 | 65/65 |
| pixel8 / p128_t2 | v4 | 1.052× | 1.050× | -742.3 | 65/65 |
| tecno / p1024_t2 | litertlm | 0.939× | 1.556× | -109.9 | 65/65 |
| tecno / p1024_t2 | v4 | 0.891× | 1.002× | -780.7 | 65/65 |
| tecno / p128_t2 | litertlm | 1.119× | 1.476× | +303.6 | 65/65 |
| tecno / p128_t2 | v4 | 0.815× | 0.998× | -725.6 | 65/65 |

Speedups above one favor the candidate; negative RSS deltas indicate less resident memory. Candidate changes preserve the original INT2 MLP weights and share one scratch workspace across sequential stages. Native v4 has the same live INT8 KV layout and 128-row chunked prefill but widened MLP weights and separate stage workspaces.

Peak RSS is a process high-water mark, including loading, packing and warmup. Session values within one process are cumulative observations of the same process maximum, not independent steady-state allocations. Process-block RSS below uses the final `run.json` process peak. Memory phase diagnostics are excluded from these timing results.

## Process block medians and session ranges

| Phone / cell | Block | Runner | Decode tok/s median (range) | First logits ms median (range) | Process peak RSS MiB |
| --- | ---: | --- | ---: | ---: | ---: |
| pixel8 / p1024_t2 | 0 | litertlm | 14.17 (12.53–14.27) | 9910.2 (9887.7–10117.8) | 2125.1 |
| pixel8 / p1024_t2 | 1 | v4 | 14.66 (13.87–14.67) | 6282.3 (5913.8–8313.6) | 2779.9 |
| pixel8 / p1024_t2 | 2 | candidate_both | 15.58 (14.32–15.59) | 6206.5 (6189.1–6766.6) | 1983.5 |
| pixel8 / p128_t2 | 0 | litertlm | 12.89 (12.62–13.07) | 1391.5 (1379.2–1501.5) | 1599.3 |
| pixel8 / p128_t2 | 1 | v4 | 16.73 (16.14–17.33) | 788.9 (705.0–789.2) | 2642.7 |
| pixel8 / p128_t2 | 2 | candidate_both | 17.85 (17.18–19.21) | 710.1 (599.4–757.2) | 1900.6 |
| pixel8 / p128_t2 | 3 | candidate_both | 17.27 (17.23–17.67) | 785.1 (745.3–919.4) | 1900.3 |
| pixel8 / p128_t2 | 4 | v4 | 16.46 (16.19–17.51) | 789.3 (671.1–861.7) | 2642.8 |
| pixel8 / p128_t2 | 5 | litertlm | 12.86 (12.72–14.25) | 1453.4 (1435.3–1497.8) | 1614.3 |
| tecno / p1024_t2 | 0 | litertlm | 12.09 (12.00–12.10) | 12153.7 (11821.9–12237.4) | 2117.6 |
| tecno / p1024_t2 | 1 | v4 | 12.73 (12.43–13.13) | 7829.1 (7753.5–7893.2) | 2788.4 |
| tecno / p1024_t2 | 2 | candidate_both | 11.35 (11.03–11.60) | 7811.1 (7776.3–7903.5) | 2007.6 |
| tecno / p128_t2 | 0 | litertlm | 11.94 (11.85–11.97) | 1252.8 (1232.7–1262.6) | 1608.3 |
| tecno / p128_t2 | 1 | v4 | 16.76 (15.88–17.10) | 829.0 (769.8–911.4) | 2639.2 |
| tecno / p128_t2 | 2 | candidate_both | 13.25 (13.18–13.70) | 824.2 (810.3–912.3) | 1913.5 |
| tecno / p128_t2 | 3 | candidate_both | 13.56 (12.76–13.92) | 851.9 (832.7–950.9) | 1913.6 |
| tecno / p128_t2 | 4 | v4 | 16.29 (15.95–16.61) | 851.5 (823.1–869.8) | 2639.2 |
| tecno / p128_t2 | 5 | litertlm | 12.09 (11.99–12.10) | 1240.1 (1204.5–1245.8) | 1611.7 |

Telemetry/paging observations requiring review: 4; detailed before/after temperatures, clocks and process samples are retained in `summary.json`.

Passive cooling is requested before every process. CPU clocks remain under the phone’s default DVFS policy, so descriptive ranges include clock and thermal variability. Process blocks are the independent repetition unit; tokens within sessions and sessions within one process are correlated. No token-level confidence intervals are claimed. Argmax agreement is a metadata check, not a substitute for the separate full-logit correctness tests.

[JSON summary](summary.json), [validation and source hashes](validation.json), [cell metrics](cells.csv), [session rows](sessions.csv), [per-pass timings](passes.csv).
