import argparse,json,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('phone',choices=['tecno','pixel8']);a=p.parse_args()
root=Path(__file__).resolve().parent
for attempt in range(40):
 records=[json.loads(x.read_text()) for x in (root/a.phone/'runs').glob('memory20260913_p*_candidate*.command.json')]
 if any(x.get('status')=='failed' for x in records):raise RuntimeError('Candidate memory capture failed')
 if len(records)==5 and all(x.get('status')=='completed' for x in records):
  print('Memory captures complete; starting separate performance blocks',flush=True)
  sys.exit(subprocess.call([sys.executable,str(root/'run_perf.py'),a.phone]))
 if attempt%2==0:print('Waiting for candidate memory captures',flush=True)
 time.sleep(30)
raise RuntimeError('Memory captures did not finish within20minutes')
