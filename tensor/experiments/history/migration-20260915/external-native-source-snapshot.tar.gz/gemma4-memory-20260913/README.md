# Gemma4 E2B: compact MLP weights and shared stage scratch

This local experiment reduces memory retained by the direct XNNPACK tensor
adapter after the [live-KV v4 work](../gemma4-live-kv-20260913/README.md).
It preserves the same published Gemma4 E2B coefficients, activation scales,
INT8 KV cache, 128-row chunked prefill, and attention alignment of 32 positions.
The comparison baseline remains LiteRT-LM CPU with the local PR9918 update.
The adapter and overlays live outside the XNNPACK checkout and are for local
testing; they are not a supported tensor-runner API or a proposed repository
submission.

**Status:** the frozen candidate with both optimizations passes **199/199
full-logit vectors bitwise** against same-phone LiteRT-LM CPU references.
The complete 18-process memory matrix shows **726–797 MiB lower current RSS**
than native v4 at the recorded end-of-decode phase. At prompt 1024, current RSS
is close to LiteRT-LM CPU. The completed focused three-runner comparison shows a device-dependent
tradeoff: the combined candidate decodes more slowly than v4 on TECNO and
slightly faster on Pixel. It remains faster than LiteRT-LM CPU in three of
four measured cells; TECNO at prompt 1024 is 2.9% slower. Memory reduction does
not imply that every device becomes faster.

## Implementation

| Component | Responsibility |
| --- | --- |
| [memory-main.cc](memory-main.cc) | Owns model resources, the optional shared workspace, prefill/decode stages, KV sessions, allocation counters, and command-line controls. |
| [matched_bundle_loader.h](matched_bundle_loader.h) | Validates the fixed bundle export and optionally reconstructs the 60 original INT2 MLP tensors, releasing their widened mappings. |
| [static_int2_fully_connected.h](overlay/litert/tensor/examples/gemma4/helpers/static_int2_fully_connected.h) | Owns compact signed two-bit coefficients and defines static QS8/QC2W fully connected operations with the published quantization boundaries. |
| [mobile_fully_connected.h](overlay/litert/tensor/examples/gemma4/helpers/mobile_fully_connected.h) | Selects the compact static INT2 path when the loader supplies the validated weight type; keeps the existing paths for other weights. |
| [stage_runner.h](stage_runner.h) | Borrows one pool and weights cache, optionally shares XNNPACK scratch, and reports workspace/external-buffer allocations. |
| [memory_snapshot.h](memory_snapshot.h) | Records current `/proc/self/smaps_rollup` and grouped `smaps` counters separately from process-lifetime peak RSS. |
| [baseline/](baseline/) | Frozen v4 source plus observation hooks; retains its original `xnn_create_runtime_v3` private-workspace behavior. |
| [litertlm-probe/](litertlm-probe/README.md) | Adds matching observation hooks to the frozen LiteRT-LM CPU driver without rebuilding model-execution libraries. |
| [analysis/](analysis/README.md) | Offline memory validation and phase/allocation reports. |

### Preserve static INT2 MLP weights

The affected weights are gate, up, and down projections in layers 15–34:
60 matrices in total. The earlier export stores their two-bit coefficients
inside signed four-bit containers. The new loader verifies original INT2
provenance and every coefficient's range, repacks the unchanged values into
two-bit storage, then releases those widened file mappings. Runtime lowering
uses static signed INT8 activations and QC2 weights; the original input/output
activation scales and per-channel weight scales remain in force.
Repacking happens once during model loading and touches all affected source
weights. Its cost is outside the first-logit timing protocol below; this
experiment makes no cold-start performance claim.

The retained coefficient payload changes from **540 MiB to 270 MiB**, excluding
small overread padding. This is an exact storage count, not a measured RSS
reduction. The [source verification](static_int2_manifest_verification.json)
confirms all 60 reconstructed byte streams match their original published
source hashes. Each compiled candidate audits exactly 60 static QS8/QC2W
operators. The existing dynamic-QD8/QC2 output-head path remains separate.

### Share scratch across sequential stages

The adapter retains 151 stage runtimes across prefill and decode. With
`--share_workspace=true`, their `StageRunner` instances receive the same
caller-owned workspace through `xnn_create_runtime_v4`. XNNPACK grows a single
arena to the largest requirement encountered. Runtime reshaping repairs peer
runtime pointers when that arena relocates.

All preparation and complete stage invocations are serialized. Persistent
weights, KV storage, and stage outputs are outside the shared scratch arena.
Outputs remain in separate owning buffers because later stages borrow them;
sharing scratch does not shorten those lifetimes or eliminate retained output
buffers. `LiveRuntime` destroys all stages before releasing the workspace,
pool, and weights cache. This is an allocation-sharing change, not an attempt
to execute stages concurrently.

`StageRunner::Create(outputs, pool, cache, flags, workspace)` accepts a null
workspace for private allocation. `MemorySnapshot()` exposes the actual
workspace identity and retained arena size; the driver deduplicates that
identity across stages. Summing all 151 reported aliases would overcount a
shared arena.

### Explicit experiment controls

Both **CLI** optimization flags default to false. `LiveMain` configures the
loader's registry from `--preserve_static_int2` before loading; its internal
header initializer is not the command-line default. The frozen candidate is
selected explicitly with:

```text
--preserve_static_int2=true --share_workspace=true
```

| Registry backend | Static INT2 | Shared scratch | Purpose |
| --- | --- | --- | --- |
| `baseline_memory` | No | No, original v3 runtime creation | Observe the preceding v4 implementation. |
| `candidate_none` | No | No, v4 runtime creation with null workspace | Control for the new adapter without either optimization. |
| `candidate_qc2` | Yes | No | Isolate compact-weight allocations. |
| `candidate_shared` | No | Yes | Isolate shared-scratch allocations. |
| `candidate_both` | Yes | Yes | Combined candidate used for correctness and performance. |

`--memory_report=true` enables phase snapshots and marks timings ineligible for
benchmarking. It is disabled for correctness and performance captures. All
four candidate registry entries use the **same frozen binary** with different
flags; a backend name alone does not change the native executable's defaults.

## Correctness and source evidence

The [final numerical gate](CORRECTNESS.json) compares 199 complete vocabulary
vectors with same-phone LiteRT-LM CPU references: 102 on TECNO and 97 on Pixel.
Coverage includes two- and four-thread gates, repeated histories with runtime
reuse, 512-token prompts followed by 64 forced decode calls, the local-attention
boundary, and histories reaching capacity 2048. The candidate enables both
optimizations. The [Linux smoke](linux-smoke-comparison.json) separately passes
three bitwise vectors against the prior native adapter; its timings are not
host-performance evidence.

Focused checks provide additional coverage:

- [Shared-workspace test](stage_workspace_test.cc): 103 checks and 4,071,360
  floats compared bitwise with private-workspace references. It alternates
  stages through growth and shrinkage, reinvokes peers after arena relocation,
  and checks borrowed outputs, retained output locks, caller outputs, ownership,
  and allocation accounting. [TECNO log](tecno-stage_workspace_test.android.log),
  [Pixel log](pixel8-stage_workspace_test.android.log).
- [Static INT2 FC test](static_int2_test.cc): 75 reshaped invocations and 73,416
  output values bitwise equal to the QC4 path, with actual QS8/QC2W operators
  audited. [TECNO log](tecno-static_int2_test.android.log),
  [Pixel log](pixel8-static_int2_test.android.log).
- [Loader check](static_int2_loader_test.linux.log), run on Linux: all 60 original
  matrices retained compactly and all 60 widened mappings released. Source
  reconstruction is checked independently by
  [verify_static_int2_manifest.py](verify_static_int2_manifest.py).

These are implementation and numerical diagnostics for recorded inputs. They
do not establish universal bitwise equivalence or replace a model-quality
evaluation.

## Memory measurements

The [final phase report](analysis/results/MEMORY.md) validates **18 completed
processes and 36 sessions**. Each process uses two
threads, zero warmups, two sessions with reused runtimes, and 64 forced decode
calls. Logit/cache dumps are disabled. The table compares **current RSS and
PSS after the second session's last decode**, while both runners still retain
their KV state; units are MiB.

| Phone | Prompt | LiteRT-LM RSS / PSS | Earlier native v4 RSS / PSS | Combined candidate RSS / PSS |
| --- | ---: | ---: | ---: | ---: |
| TECNO LJ9 | 128 | 1601.7 / 1584.1 | 2634.2 / 2631.3 | 1908.1 / 1905.4 |
| TECNO LJ9 | 1024 | 2015.7 / 1998.2 | 2779.6 / 2776.8 | 1998.6 / 1995.7 |
| Pixel 8 | 128 | 1516.9 / 1508.0 | 2637.5 / 2635.0 | 1897.8 / 1895.3 |
| Pixel 8 | 1024 | 2004.7 / 1996.2 | 2785.3 / 2782.8 | 1988.8 / 1986.2 |

The earlier native adapter already reaches about 2341–2349 MiB RSS after
packing, before its scratch arenas and outputs are allocated by inference.
Recorded native allocation categories include 1021.9 MiB packed-weight
capacity, the output head's 96 MiB reconstruction buffer, 197.0–268.4 MiB of
private stage arenas after decode, and about 48 MiB of retained stage outputs.
The logical KV bank remains 18 MiB at capacity 2048. These measurements locate
real retained allocations; they do not assign every byte of the RSS difference
to one cause.

All four flag combinations ran at prompt 128 using the same candidate binary:

| Configuration | TECNO RSS (MiB) | Pixel RSS (MiB) |
| --- | ---: | ---: |
| Both disabled (`candidate_none`) | 2633.9 | 2640.5 |
| Compact MLP weights only (`candidate_qc2`) | 2096.7 | 2103.5 |
| Shared scratch only (`candidate_shared`) | 2445.1 | 2435.0 |
| Both enabled (`candidate_both`) | 1908.1 | 1897.8 |

Recorded packed-weight capacity falls by exactly **270 MiB**, from 1021.9 to
751.9 MiB. The 151 private workspaces become one retained arena: **8.75 MiB on
TECNO and 9.13 MiB on Pixel**, versus 197.0–268.4 MiB across baseline cases.
Source coefficient payload independently falls by 270 MiB. These measured
allocations support the observed reductions; mapped-page residency, copied
representations, and allocator behavior prevent exact per-category attribution
of the entire RSS difference.

The combined candidate's process-lifetime peak at prompt 128 is 1913.6 MiB on
TECNO and 1903.1 MiB on Pixel; at prompt 1024 it is 2007.7 and 1997.9 MiB.
Compared with LiteRT-LM, the candidate still uses about **306–381 MiB more
current RSS at prompt 128**. At prompt 1024 its current RSS is about 16–17 MiB
lower in these captures; the PSS gap is also much smaller. These results cover
the measured session states, not all prompt lengths or allocator conditions.
All 1820 native argmax rows across the memory sessions agree with same-phone
LiteRT-LM references; the full-logit gate remains the separate correctness
evidence.

Current RSS/PSS describe a snapshot; `peak_rss_bytes` is a process-lifetime
high-water mark that can include temporary setup allocations. Source buffer
sizes include mapped/owned payload, not only resident pages. Quantization
metadata and general allocator overhead are not fully enumerated by the
allocation counters. File-mapping and anonymous categories can overlap after
copy-on-write. `/proc` reads are sequential, so small differences between
rollup and grouped snapshots are expected. Do not add allocation counters to
RSS, add shared aliases to unique workspace bytes, or equate freed logical
storage with an immediate RSS decrease.

Native `after_session` follows destruction of its KV bank, while LiteRT-LM's
executor still owns KV at its corresponding phase. The primary comparison
therefore uses `after_last_decode`. Model resources remain live after runtime
destruction in both diagnostic drivers. No heap trimming, residency advice,
governor changes, or thermal overrides are used.

## Focused performance results and protocol

The [completed selected report](perf-complete-20260914/perf_results/SUMMARY.md)
compares LiteRT-LM CPU, frozen native live-KV v4, and the combined candidate.
The four cells are prompt lengths 128 and 1024 on TECNO and Pixel, using two
threads. Each cell uses the process order **LM, v4, candidate, candidate, v4,
LM**, one warmup and three measured sessions per process, and 64 forced decode
calls per session. The final matrix contains **24 selected processes, 72
measured sessions, and 4608 measured decode calls**; these counts exclude
preserved captures from the interrupted attempt. Each table value is the
median of six measured sessions from two process blocks per backend/cell.

| Phone | Prompt | LiteRT-LM decode (tok/s) | Native v4 decode (tok/s) | Combined candidate decode (tok/s) | First logits, LM / v4 / candidate (s) |
| --- | ---: | ---: | ---: | ---: | ---: |
| TECNO LJ9 | 128 | 11.98 | 16.45 | 13.40 | 1.243 / 0.840 / 0.842 |
| TECNO LJ9 | 1024 | 12.01 | 13.19 | 11.67 | 11.966 / 7.801 / 7.756 |
| Pixel 8 | 128 | 12.88 | 16.60 | 17.47 | 1.444 / 0.789 / 0.751 |
| Pixel 8 | 1024 | 12.69 | 14.16 | 14.67 | 11.108 / 7.675 / 8.003 |

Relative to native v4, the candidate's median decode throughput is **18.5%
lower at prompt 128 and 11.6% lower at prompt 1024 on TECNO**. Pixel's median
throughput is **5.2% and 3.6% higher**, respectively. Against LiteRT-LM CPU,
the candidate is 11.9% faster on TECNO at 128 tokens but 2.9% slower at 1024;
on Pixel it is 35.6% and 15.6% faster. Its first-logit latency is lower than
LiteRT-LM in all four cells. Against v4, first-logit differences are small on
TECNO; Pixel improves at 128 but takes 4.3% longer at 1024. These are measured
medians under default DVFS, with session and process ranges retained in the
report; small differences are not claims of a universal speedup. Three Pixel
process blocks recorded increases in sampled major-fault counters; the samples
do not identify which execution phase incurred those faults.

The [stage/source cost review](PERFORMANCE_COST_REVIEW.md) finds most of TECNO's
added decode time inside post-attention stages, which contain the changed MLP
operators. Static QC2 and QC4 use different ARM64 kernel configurations, but
those stages also contain other work and both feature flags change together.
The recorded data cannot assign the regression exclusively to the QC2 kernel
or workspace sharing. Diagnostic memory ablations are not timing evidence.
The [standalone chart](perf-complete-20260914/perf_results/comparison.svg) shows
decode and first-logit results with session ranges.

Histories, model coefficients, KV dtype/capacity, thread count, and CPU affinity
are matched. Diagnostic snapshots, traces, and logit/cache dumps are disabled.
The primary decode rate uses inclusive per-pass elapsed time aggregated within
each session, then the median of six sessions per backend/cell. First-logit
time includes session initialization, prefill, and the reserved last prompt
token's decode. Both first-logit and decode timings include reading logits and
selecting the validation argmax; model loading, runtime construction,
tokenization, and generation-policy sampling are excluded.
[perf_analysis.py](perf_analysis.py) validates the saved protocol
and keeps process/session variation visible. Memory diagnostics are analyzed
separately and supply no performance conclusion.

The original attempt was interrupted with 22 completed processes: TECNO's
last prompt-1024 process was incomplete, and Pixel's last record was truncated
before launch. The final selected matrix lives in
[perf-complete-20260914/](perf-complete-20260914/). Its two complete prompt-128
cells link unchanged to the original records. Both prompt-1024 cells were rerun
as whole six-process sequences; all original long-prompt captures remain
preserved and are excluded from final aggregation. The
[selection record](perf-complete-20260914/selection.json) records these choices
and original hashes. Selection follows capture completeness, not performance.

The [completion driver](perf-complete-20260914/run_perf.py) changes only the
capture namespace through a wrapper around the unchanged frozen controller.
The [phone setup record](perf-complete-20260914/remote-setup.json) verifies that
`/data/local/tmp/gemma4-memory-perf-20260914` aliases the same frozen binaries,
model bundle, and dependencies in the original phone directory. It does not
introduce a new native build or model conversion. The selected short and long
cells were captured at different times; each cell retains its own balanced
process order and measured session ranges. No cell pools measurements across
the original and completion attempts.

## Frozen artifacts and reproduction

[variants/v1/manifest.json](variants/v1/manifest.json) hashes the frozen source,
overlay, command records, and binaries. The Android candidate SHA256 is
`0f60c0b9d2887c42d64d40332cc426ea9db79659e8d0f696b6923501fac458b8`.
[binaries.json](binaries.json) pins the original native v4, native observation
probe, LiteRT-LM baseline/probe, and all candidate variants. The
[Android build command record](variants/v1/memory-main.android.commands.json)
and [Linux record](variants/v1/memory-main.linux.commands.json) preserve exact
compiler/linker arguments. The LiteRT-LM probe has its own
[build validation](litertlm-probe/build-validation.json).
The [final source verification](final-source-verification.json) confirms all
20 frozen source/build/binary entries still match their current counterparts.

Builds reuse existing archives and generated dependencies under
`/tmp/gemma4-local-port-nggiqf9x/{linux,android}` and include the local Gemma
driver from `/data/bt/os/xnnpack`. These are retained local builds, not a
hermetic source distribution. To rebuild in a fresh directory without
overwriting the frozen evidence:

```sh
GEMMA_MEMORY_ROOT=/data/bt/tmp/gemma4-memory-20260913
GEMMA_MEMORY_BUILD=$(mktemp -d /data/bt/tmp/gemma4-memory-rebuild-XXXXXX)
cp -a "$GEMMA_MEMORY_ROOT/variants/v1/." "$GEMMA_MEMORY_BUILD/"
python3 "$GEMMA_MEMORY_BUILD/build-probe.py" linux "$GEMMA_MEMORY_BUILD/memory-main.cc"
python3 "$GEMMA_MEMORY_BUILD/build-probe.py" android "$GEMMA_MEMORY_BUILD/memory-main.cc"
```

The candidate Linux and Android builds succeeded. The fresh-directory copy
recipe above is an illustrative way to preserve them, not an additional
executed build. No Linux-host model-performance benchmark is part of this work.

Saved numerical and memory reports can be regenerated without inference.
The numerical comparison requires NumPy; use a Python environment where it is
installed. The recorded correctness validation used the converter's existing
NumPy environment with BLAS restricted to one thread. The equivalent commands
below use `python3` with the same thread limits:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  python3 /data/bt/tmp/gemma4-memory-20260913/check_correctness.py
python3 /data/bt/tmp/gemma4-memory-20260913/analysis/memory.py --expect-final-matrix
```

Both validations completed successfully: the final 199-vector gate and the
18-process/36-session memory matrix. `--expect-final-matrix` rejects missing
experimental conditions as well as incomplete/invalid captures. Use `--allow-partial
--output PATH` while captures are running, keeping interim results separate.

Regenerate the completed selected performance summary and optional standalone
chart with:

```sh
GEMMA_PERF_ROOT=/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914
python3 /data/bt/tmp/gemma4-memory-20260913/perf_analysis.py --root "$GEMMA_PERF_ROOT"
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  uv run --no-project --with matplotlib python \
  /data/bt/tmp/gemma4-memory-20260913/perf_analysis.py --root "$GEMMA_PERF_ROOT" --chart
```

These commands target the selected matrix, not the interrupted original
capture directory. Final strict analysis and chart generation completed
successfully. The [validation record](perf-complete-20260914/perf_results/validation.json)
retains source hashes and protocol checks. The separate
[independent review](perf-complete-20260914/PERF_REVIEW.json) also passes all
24 selected processes, 72 sessions, 4608 decode calls, source hashes, process
ordering, non-overlap, and matched histories/argmax metadata. It recomputes
session throughput and cell medians without importing the primary analyzer.
Performance analysis runs on saved reports and does not execute the model on
the host. `--allow-partial --output
PATH` is for interim reports only; final validation requires all four complete
cells.

Phone tools obtain adb from `$ANDROID_HOME/platform-tools/adb`. Every device
operation selects an explicit authorized serial:

| Phone | Serial | Two-thread mask | Four-thread gate mask |
| --- | --- | --- | --- |
| TECNO LJ9 | `144512553T000099` | `c0` | `f0` |
| Pixel 8 | `3A111FDJH005A0` | `180` | `1e0` |

Samsung/S25 is excluded. Run only one workload at a time on each phone.
[phone_runs.py](phone_runs.py) checks transferred fixture and binary hashes,
retains commands and telemetry, and refuses to overwrite captures.
[perf_phone_runs.py](perf_phone_runs.py) records the six-block performance
order and passively waits for the configured cooling criteria; clocks are not
fixed. Models and dependencies are reused from the already verified phone
directory `/data/local/tmp/gemma4-phone-perf-20260913`.

The campaign sequence is [run_baseline_memory.py](run_baseline_memory.py),
[run_candidate_gate.py](run_candidate_gate.py), `check_correctness.py`,
[run_candidate_memory.py](run_candidate_memory.py), then `run_perf.py`, each
phone driver taking `tecno` or `pixel8`. The gate runs component checks before
the model; memory/performance drivers require the completed numerical report.
These scripts use fixed campaign tags and completion prerequisites. The
baseline-memory, candidate-memory, and performance drivers skip completed
records, allowing interrupted campaigns to resume between completed processes.
They reject a recorded incomplete/failed process. The original performance
campaign has such records and must not be resumed in place; its completion
uses the separately recorded selection and namespace described above.
`run_candidate_gate.py` is a one-shot campaign step: it requires exactly four completed baseline-memory
captures and does not skip already recorded gates. To repeat gates after the
campaign, use the unique-tag helper example below. A full new campaign requires
a fresh capture namespace and fresh tags. Existing captures must be preserved.

For an independent gate rerun against the already deployed frozen binary,
use a unique tag with the same capture helper:

```sh
cd /data/bt/tmp/gemma4-memory-20260913
python3 - <<'PY'
from datetime import datetime, timezone
from phone_runs import ROOT, EXTRA_FLAGS, run_capture
EXTRA_FLAGS['candidate_both'] = [
    '--preserve_static_int2=true', '--share_workspace=true',
    '--memory_report=false',
]
tag = 'memory_gate_recheck_' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
output = run_capture('tecno', 'candidate_both', ROOT / 'fixtures/gate.tsv',
    tag, threads=2, phase='correctness', reuse=True, warmups=1, runs=1, dump=True)
print(output)
PY
```

This illustrative rerun is not included in the recorded results. Substitute
`pixel8` to select that phone. Compare its printed output directory with the
corresponding saved LiteRT-LM gate using
[/tmp/gemma4-local-port-nggiqf9x/replacement-comparison/compare_runs.py](/tmp/gemma4-local-port-nggiqf9x/replacement-comparison/compare_runs.py)
and the [correctness fixture manifest](../gemma4-live-kv-20260913/validation/fixtures/manifest.json).
Exact historical invocation and artifact paths are retained in each
`<phone>/runs/<tag>.command.json`, including the
[TECNO gate](tecno/runs/memory20260913_v1_gate_t2.command.json) and
[Pixel gate](pixel8/runs/memory20260913_v1_gate_t2.command.json).

## Remaining limits

The output head's 96 MiB reconstruction buffer, retained external stage
outputs, source mappings, quantization metadata, packed weights, and general
runtime allocations remain distinct costs. This work shares scratch rather
than all inter-stage buffers. The 60-matrix compact conversion is specific to
the validated E2B bundle. The remaining memory difference is within this local
experiment's accepted scope; further memory changes are not part of this
campaign. The measured performance tradeoff is documented above; no further
model or kernel changes are part of this completed comparison.
