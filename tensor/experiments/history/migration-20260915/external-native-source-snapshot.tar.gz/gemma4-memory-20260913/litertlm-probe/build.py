#!/usr/bin/env python3
"""Relink a memory-observation driver using the frozen PR9918 Android objects.

Compiles one copied translation unit; does not invoke Bazel or run the model.
The frozen adapter, source, objects and original link inputs remain unchanged.
"""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess

ROOT = Path(__file__).resolve().parent
BASE = Path('/data/bt/tmp/gemma4-pr9918')
CWD = (BASE / 'LiteRT-LM/.bazel-output/execroot/litert_lm').resolve(strict=True)
EXPECTED_BINARY = 'fdfbd3dee9ff4ee409319486a4c3874797a7ee8a173fa76fe7322d636efd29a1'
EXPECTED_SOURCE = 'e10a41cde28eaa3ba3058d7c3e41ff8b0d2abbba66e565ba1d98bfe690ffed0e'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def absolute(path):
    value = Path(path)
    return value if value.is_absolute() else CWD / value


def expand(command, params):
    result = []
    for value in command:
        if value.startswith('@'):
            name = value[1:]
            items = params.get(name)
            if items is None:
                items = shlex.split(absolute(name).read_text())
            result.extend(expand(items, params))
        else:
            result.append(value)
    return result


def without_side_outputs(command):
    result = []
    index = 0
    while index < len(command):
        flag = command[index]
        if flag in ['-MF', '-MT', '-MQ', '--dependency-file', '-serialize-diagnostics']:
            index += 2
            continue
        if flag in ['-MD', '-MMD', '-MP'] or flag.startswith((
                '-MF', '-MT', '-MQ', '--dependency-file=',
                '-Wl,--dependency-file=', '-Wl,-Map=')):
            index += 1
            continue
        result.append(flag)
        index += 1
    return result


actions = json.loads((BASE / 'aquery-android-v1.json').read_text())['actions']
selected = {}
for action in actions:
    mnemonic = action.get('mnemonic')
    if mnemonic not in ['CppCompile', 'CppLink']:
        continue
    command = expand(action.get('arguments', []), {
        p['execPath']: p['arguments'] for p in action.get('paramFiles', [])})
    if '-o' not in command:
        continue
    output = command[command.index('-o') + 1]
    wanted = ((mnemonic == 'CppCompile' and '-c' in command and
               command[command.index('-c') + 1].endswith('local_correctness/adapter.cc')) or
              (mnemonic == 'CppLink' and output.endswith('/local_correctness/adapter')))
    if wanted:
        assert mnemonic not in selected
        selected[mnemonic] = (command, {
            e['key']: e['value'] for e in action.get('environmentVariables', [])})
assert set(selected) == {'CppCompile', 'CppLink'}
compile_command, compile_env = selected['CppCompile']
link_command, link_env = selected['CppLink']
source = absolute(compile_command[compile_command.index('-c') + 1])
object_arg = compile_command[compile_command.index('-o') + 1]
original_object = absolute(object_arg)
binary = absolute(link_command[link_command.index('-o') + 1])
assert sha(source) == EXPECTED_SOURCE
assert sha(binary) == EXPECTED_BINARY
preserved = {str(p): sha(p) for p in [source, original_object, binary]}
compile_command = without_side_outputs(compile_command)
compile_command[compile_command.index('-c') + 1] = str(ROOT / 'adapter.cc')
compile_command[compile_command.index('-o') + 1] = str(ROOT / 'adapter.android.o')
link_command = without_side_outputs(link_command)
locations = [i for i, value in enumerate(link_command) if value == object_arg]
assert len(locations) == 1
link_command[locations[0]] = str(ROOT / 'adapter.android.o')
link_command[link_command.index('-o') + 1] = str(ROOT / 'adapter.android')
record = {
    'status': 'building', 'cwd': str(CWD), 'originals': preserved,
    'commands': {'compile': compile_command, 'link': link_command},
    'environments': {'compile': compile_env, 'link': link_env},
    'source_sha256': sha(ROOT / 'adapter.cc'),
    'memory_snapshot_header_sha256': sha(ROOT.parent / 'memory_snapshot.h'),
    'aquery_sha256': sha(BASE / 'aquery-android-v1.json'),
    'timings_valid_for_benchmark': False, 'model_or_device_executed': False,
}


def save():
    (ROOT / 'build-validation.json').write_text(json.dumps(record, indent=2) + '\n')


save()
for name, command, environment in [('compile', compile_command, compile_env),
                                    ('link', link_command, link_env)]:
    with (ROOT / (name + '.log')).open('w') as log:
        result = subprocess.run(['nice', '-n', '10', *command], cwd=CWD,
                                env={**os.environ, **environment},
                                stdout=log, stderr=subprocess.STDOUT)
    record[name + '_returncode'] = result.returncode
    save()
    if result.returncode:
        raise SystemExit('Failed ' + name + '; see ' + str(ROOT / (name + '.log')))
assert all(sha(path) == digest for path, digest in preserved.items())
record.update(status='built', binary=str(ROOT / 'adapter.android'),
              binary_sha256=sha(ROOT / 'adapter.android'), originals_preserved=True)
save()
print(json.dumps({key: record[key] for key in ['status', 'binary', 'binary_sha256']}))
