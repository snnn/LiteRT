#!/usr/bin/env python3
"""Copy the frozen baseline driver and add opt-in memory observation hooks."""
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/data/bt/tmp/gemma4-pr9918/harness/adapter.cc')
original = SOURCE.read_text()
assert hashlib.sha256(original.encode()).hexdigest() == 'e10a41cde28eaa3ba3058d7c3e41ff8b0d2abbba66e565ba1d98bfe690ffed0e'
text = original


def replace(before, after):
    global text
    assert text.count(before) == 1, before
    text = text.replace(before, after)


replace('#include "nlohmann/json.hpp"', '#include "nlohmann/json.hpp"\n#include "../memory_snapshot.h"')
replace('"--dump_logits true]\\n";', '"--dump_logits true --memory_report false]\\n";')
replace('"dump_logits", "dump_full_logits"};', '"dump_logits", "dump_full_logits", "memory_report"};')
replace('    if (threads < 1 || warmups < 0 || runs < 1 || capacity < 1)',
        '    const bool memory_report = boolean("memory_report", "false");\n'
        '    if (threads < 1 || warmups < 0 || runs < 1 || capacity < 1)')
replace('    auto startup = Clock::now();', '''    auto snapshot = [&](const std::string &phase,
                        const std::string &case_id = "", int repetition = -1) {
      if (memory_report && !gemma_memory::AppendMemorySnapshot(
              (output / "memory.jsonl").string(), phase, case_id, repetition))
        throw std::runtime_error("Failed memory snapshot write");
    };
    snapshot("before_model_load");
    auto startup = Clock::now();''')
replace('    auto assets = Take(ModelAssets::Create(model));',
        '    auto assets = Take(ModelAssets::Create(model));\n    snapshot("after_model_load");')
replace('    double startup_ms = Ms(startup);',
        '    double startup_ms = Ms(startup);\n    snapshot("after_environment_init");')
replace('    std::unique_ptr<LlmExecutor> reused_executor;', '''    if (memory_report) {
      index["memory_report"] = true;
      index["timings_valid_for_benchmark"] = false;
      index["memory_snapshot_note"] =
          "Opt-in procfs snapshots include observation overhead; no heap trimming. "
          "Use dump_full_logits=false to avoid the separate cloned-cache audit.";
    }
    std::unique_ptr<LlmExecutor> reused_executor;''')
replace('        double executor_ms = created ? Ms(init) : 0;',
        '        double executor_ms = created ? Ms(init) : 0;\n'
        '        snapshot(created ? "after_executor_init" : "after_executor_reset", c.id, r);')
replace('        double inference_work_ms = 0;', '''        if (memory_report) {
          run["memory_report"] = true;
          run["timings_valid_for_benchmark"] = false;
        }
        double inference_work_ms = 0;''')
replace('          if (i == 0)\n            Check(exec->Prefill(in));',
        '          if (i == 0) {\n            Check(exec->Prefill(in));\n'
        '            snapshot("after_prefill_before_first_logits", c.id, r);\n          }')
replace('          double forward_ms = Ms(begin);', '''          double forward_ms = Ms(begin);
          if (i == 0) snapshot("after_first_logits", c.id, r);
          if (i == c.forced.size()) snapshot("after_last_decode", c.id, r);''')
replace('        // CloneContext copies the currently bound cache tensors with their',
        '        snapshot("after_session_before_optional_cache_audit", c.id, r);\n'
        '        // CloneContext copies the currently bound cache tensors with their')
replace('        run["inference_work_ms"] = inference_work_ms;',
        '        snapshot("after_session", c.id, r);\n'
        '        run["inference_work_ms"] = inference_work_ms;')
replace('    index["status"] = "completed";', '''    snapshot("before_executor_release");
    if (memory_report) {
      reused_executor.reset();
      snapshot("after_executor_release");
    }
    index["status"] = "completed";''')

(ROOT / 'adapter.cc').write_text(text)
(ROOT / 'memory-hooks.diff').write_text(''.join(difflib.unified_diff(
    original.splitlines(keepends=True), text.splitlines(keepends=True),
    fromfile=str(SOURCE), tofile=str(ROOT / 'adapter.cc'))))
(ROOT / 'source-provenance.json').write_text(json.dumps({
    'original_source': str(SOURCE),
    'original_source_sha256': hashlib.sha256(original.encode()).hexdigest(),
    'instrumented_source_sha256': hashlib.sha256(text.encode()).hexdigest(),
    'default_enabled': False,
    'memory_flag': '--memory_report true',
    'memory_output': '<output_dir>/memory.jsonl',
    'inference_code_changed': False,
    'lifetime_change_when_enabled': 'Release reused executor before final snapshot, after all model work.',
    'timings_valid_for_benchmark_when_enabled': False,
    'model_or_device_executed': False,
}, indent=2) + '\n')
