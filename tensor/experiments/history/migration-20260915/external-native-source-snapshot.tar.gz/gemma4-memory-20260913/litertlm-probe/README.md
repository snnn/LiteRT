# LiteRT-LM CPU memory observation probe

This local Android driver adds opt-in memory snapshots to the frozen PR9918
LiteRT-LM CPU baseline. It compiles one copied translation unit and relinks
against the baseline's existing objects. No LiteRT, XNNPACK, or model-execution
implementation is changed. The original source, main object, and executable
hashes are checked before and after the build.

The baseline executable has SHA256
`fdfbd3dee9ff4ee409319486a4c3874797a7ee8a173fa76fe7322d636efd29a1`.
The probe executable has SHA256
`59bab16079ff3c8057fd5f85e5a7817bb2ac8e9f8230274f09bca4cc26a1ab0c`.

## Source and build

- [adapter.cc](adapter.cc) is the copied driver with observation hooks.
- [memory-hooks.diff](memory-hooks.diff) shows every change from the baseline.
- [prepare.py](prepare.py) reproduces the source copy and hook additions.
- [build.py](build.py) reuses the archived Android compile and link actions;
  it does not invoke Bazel or rebuild dependencies.
- [build-validation.json](build-validation.json) records commands, source/header
  hashes, original artifact hashes, compiler/linker results, and output hash.
- [memory_snapshot.h](../memory_snapshot.h) owns the shared JSONL schema and
  reads `/proc/self/smaps_rollup`, `/proc/self/smaps`, and `getrusage`.

```sh
python3 /data/bt/tmp/gemma4-memory-20260913/litertlm-probe/prepare.py
python3 /data/bt/tmp/gemma4-memory-20260913/litertlm-probe/build.py
```

The initial build succeeded and ELF inspection confirmed an AArch64 PIE with
Android system-library dependencies. No model or device was executed as part
of that build validation.

## Observation mode

The existing raw-ID driver arguments remain available. Add `--memory_report
true` to write `<output_dir>/memory.jsonl`; the default is `false`. Use a fresh
output directory. Use `--dump_full_logits false` for primary memory captures:
the original full-logit diagnostic also deep-copies the KV cache for a separate
capacity audit after inference. Snapshots before and after that optional audit
are distinct, but its allocation can affect process-lifetime peak RSS.

Snapshots cover model/resource loading, environment setup, executor creation
or reset, prefill before the pending last token, first logits, last decode,
session completion, and executor release. Case ID and repetition distinguish
warmups and measured sessions. With runtime reuse, the final
`after_executor_release` snapshot follows destruction of the reused executor;
model resources and the environment remain alive. With fresh runtimes, those
executors have already been destroyed at the end of each session.

Memory counters use bytes and explicitly mark unavailable procfs sources.
Current RSS/PSS and clean/dirty/anonymous accounting are separate from
`ru_maxrss`, which is the lifetime high-water mark. File mappings may be only
partly resident, and the allocator may retain freed memory. No heap trimming,
page advice, forced collection, or residency manipulation is performed.

Every enabled memory capture is marked `timings_valid_for_benchmark: false`.
Snapshot parsing and report writes add overhead and may allocate small temporary
buffers. These captures are memory diagnostics, not performance measurements.
