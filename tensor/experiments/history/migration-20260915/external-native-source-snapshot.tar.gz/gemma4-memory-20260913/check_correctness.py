from pathlib import Path
import argparse,importlib.util,json,sys
p=argparse.ArgumentParser();p.add_argument('--allow-partial',action='store_true');a=p.parse_args()
ROOT=Path(__file__).resolve().parent
LIVE=Path('/data/bt/tmp/gemma4-live-kv-20260913')
OLD=Path('/data/bt/tmp/gemma4-phone-perf-20260913')
spec=importlib.util.spec_from_file_location('compare','/tmp/gemma4-local-port-nggiqf9x/replacement-comparison/compare_runs.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
report={'status':'passed','comparisons':{},'unavailable':[],'candidate_variant':'v1_qc2_shared_workspace','scope':'All full-vocabulary logits against same-phone LiteRT-LM CPU; repeated gate histories included'}
for device in ['tecno','pixel8']:
 pairs=[('gate_t'+str(t),OLD/device/f'runs/gate_litertlm_reuse_t{t}') for t in [2,4]]
 pairs.append(('long512',OLD/'tecno/runs/followup512_litertlm_t2' if device=='tecno' else LIVE/device/'runs/reference_long512_t2'))
 pairs.append(('long_boundary',LIVE/device/'runs/reference_long_boundary_t2'))
 if device=='tecno':pairs.append(('boundary',Path('/data/bt/tmp/gemma4-pr9918/results/android/litertlm/boundary-pr9918-v1')))
 for name,ref in pairs:
  key=device+'_'+name;candidate=ROOT/device/'runs'/('memory20260913_v1_'+name)
  record=ROOT/device/'runs'/('memory20260913_v1_'+name+'.command.json')
  if not record.exists() or json.loads(record.read_text()).get('status')!='completed':report['unavailable'].append(key);continue
  result=c.compare(ref,candidate,LIVE/'validation/fixtures/manifest.json')
  (ROOT/(key+'-comparison.json')).write_text(json.dumps(result,indent=2)+'\n')
  report['comparisons'][key]=result['overall']
  print(key,json.dumps(result['overall']))
  if result['overall']['bitwise_equal_rows']!=result['overall']['prediction_rows']:report['status']='failed'
if report['unavailable'] and report['status']=='passed':report['status']='incomplete'
report['prediction_rows']=sum(x['prediction_rows'] for x in report['comparisons'].values())
report['bitwise_equal_rows']=sum(x['bitwise_equal_rows'] for x in report['comparisons'].values())
(ROOT/'CORRECTNESS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='comparisons'}))
if report['status']=='failed' or (report['status']=='incomplete' and not a.allow_partial):sys.exit(1)
