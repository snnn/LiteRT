"""Update local documentation from the selected, completed performance report.

Does not run inference, access devices, or modify the repository README.
"""
import json
from pathlib import Path
root=Path(__file__).resolve().parent
report=json.loads((root/'perf-complete-20260914/perf_results/summary.json').read_text())
assert report['status']=='completed' and len(report['processes'])==24 and len(report['sessions'])==72
cells={(x['device'],x['cell']):x for x in report['cells']}
lines=['| Phone | Prompt | LiteRT-LM decode (tok/s) | Native v4 decode (tok/s) | Combined candidate decode (tok/s) | First logits, LM / v4 / candidate (s) |',
       '| --- | ---: | ---: | ---: | ---: | ---: |']
for phone,label in [('tecno','TECNO LJ9'),('pixel8','Pixel 8')]:
 for prompt in [128,1024]:
  c=cells[phone,f'p{prompt}_t2']['backends']
  assert all(b['measured_sessions']==6 and len(b['process_blocks'])==2 for b in c.values())
  rates=[c[b]['decode_tokens_per_second']['median'] for b in ['litertlm','v4','candidate_both']]
  first=[c[b]['ttft_ms']['median']/1000 for b in ['litertlm','v4','candidate_both']]
  lines.append(f'| {label} | {prompt} | '+ ' | '.join(f'{v:.2f}' for v in rates)+' | '+' / '.join(f'{v:.3f}' for v in first)+' |')
table='\n'.join(lines)
summary='''Relative to native v4, the candidate's median decode throughput is **18.5%
lower at prompt 128 and 11.6% lower at prompt 1024 on TECNO**. Pixel's median
throughput is **5.2% and 3.6% higher**, respectively. Against LiteRT-LM CPU,
the candidate is 11.9% faster on TECNO at 128 tokens but 2.9% slower at 1024;
on Pixel it is 35.6% and 15.6% faster. Its first-logit latency is lower than
LiteRT-LM in all four cells. Against v4, first-logit differences are small on
TECNO; Pixel improves at 128 but takes 4.3% longer at 1024. These are measured
medians under default DVFS, with session and process ranges retained in the
report; small differences are not claims of a universal speedup.'''
p=root/'README.md';s=p.read_text()
start=s.index('The focused three-runner performance comparison is')
end=s.index('\n## Implementation',start)
s=s[:start]+'''The completed focused three-runner comparison shows a device-dependent
tradeoff: the combined candidate decodes more slowly than v4 on TECNO and
slightly faster on Pixel. It remains faster than LiteRT-LM CPU in three of
four measured cells; TECNO at prompt 1024 is 2.9% slower. Memory reduction does
not imply that every device becomes faster.
'''+s[end:]
start=s.index('## Focused performance protocol')
end=s.index('Histories, model coefficients',start)
s=s[:start]+'''## Focused performance results and protocol

The [completed selected report](perf-complete-20260914/perf_results/SUMMARY.md)
compares LiteRT-LM CPU, frozen native live-KV v4, and the combined candidate.
The four cells are prompt lengths 128 and 1024 on TECNO and Pixel, using two
threads. Each cell uses the process order **LM, v4, candidate, candidate, v4,
LM**, one warmup and three measured sessions per process, and 64 forced decode
calls per session. The final matrix contains **24 selected processes, 72
measured sessions, and 4608 measured decode calls**; these counts exclude
preserved captures from the interrupted attempt. Each table value is the
median of six measured sessions from two process blocks per backend/cell.

'''+table+'\n\n'+summary+'''

The [stage/source cost review](PERFORMANCE_COST_REVIEW.md) finds most of TECNO's
added decode time inside post-attention stages, which contain the changed MLP
operators. Static QC2 and QC4 use different ARM64 kernel configurations, but
those stages also contain other work and both feature flags change together.
The recorded data cannot assign the regression exclusively to the QC2 kernel
or workspace sharing. Diagnostic memory ablations are not timing evidence.
The [standalone chart](perf-complete-20260914/perf_results/comparison.svg) shows
decode and first-logit results with session ranges.

'''+s[end:]
s=s.replace('Both prompt-1024 cells are rerun\nas whole six-process sequences;', 'Both prompt-1024 cells were rerun\nas whole six-process sequences;')
s=s.replace('After all selected performance captures finish, regenerate their separate\nsummary and optional standalone chart with:', 'Regenerate the completed selected performance summary and optional standalone\nchart with:')
s=s.replace('''These commands target the selected matrix, not the interrupted original
capture directory. Final strict performance analysis and chart generation are
pending. Performance analysis runs on saved reports and does not execute the
model on the host. `--allow-partial --output PATH` is for interim reports only;
final validation requires all four complete cells.''','''These commands target the selected matrix, not the interrupted original
capture directory. Final strict analysis and chart generation completed
successfully. The [validation record](perf-complete-20260914/perf_results/validation.json)
retains source hashes and protocol checks. Performance analysis runs on saved
reports and does not execute the model on the host. `--allow-partial --output
PATH` is for interim reports only; final validation requires all four complete
cells.''')
s=s.replace("campaign. Performance conclusions still await the completed focused comparison.", "campaign. The measured performance tradeoff is documented above; no further\nmodel or kernel changes are part of this completed comparison.")
p.write_text(s)
p=root/'repo-memory-followup.draft.md';s=p.read_text()
start=s.index('**Focused performance results are pending.**')
end=s.index('The [selected performance matrix]',start)
s=s[:start]+'''The [completed focused performance report](/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914/perf_results/SUMMARY.md)
contains **24 selected processes and 72 measured sessions**, covering two
threads at prompts 128 and 1024 on both phones. Each cell uses the process
order LiteRT-LM, v4, candidate, candidate, v4, LiteRT-LM, with one warmup and
three measured sessions per process and 64 forced decode calls per session.
Each value below is a median of six measured sessions from two process blocks
per backend/cell, using inclusive `elapsed_ms`.

'''+table+'\n\n'+summary+'''

First-logit time includes session initialization, prefill, and the final prompt
token's decode. Both first-logit and decode timings include reading logits
and selecting the validation argmax; they exclude loading, compilation,
tokenization, and generation-policy sampling. Memory diagnostics and dumps
are disabled for timing captures. The
[stage/source cost review](/data/bt/tmp/gemma4-memory-20260913/PERFORMANCE_COST_REVIEW.md)
locates most of TECNO's added time in post-attention stages containing the
changed MLP operations. It does not isolate QC2 kernel cost from shared-workspace
effects or other work in those stages. The memory savings have a measured
performance cost on TECNO; this is not a universal speed improvement.

'''+s[end:]
s=s.replace('cells are rerun as complete six-process sequences in a fresh capture namespace.', 'cells were rerun as complete six-process sequences in a fresh capture namespace.')
needle='''Both validations have passed for the completed correctness and memory matrices.
'''
new='''Both validations have passed for the completed correctness and memory matrices.
The selected performance report and standalone chart also passed strict
offline analysis:

```sh
GEMMA_PERF_ROOT=/data/bt/tmp/gemma4-memory-20260913/perf-complete-20260914
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \\
  uv run --no-project --with matplotlib python \\
  /data/bt/tmp/gemma4-memory-20260913/perf_analysis.py --root "$GEMMA_PERF_ROOT" --chart
```

'''
assert needle in s;s=s.replace(needle,new)
p.write_text(s)
print(table)
