"""Phone-only RSS/PSS diagnostic; no performance results come from these runs."""
import argparse,json
from pathlib import Path
from phone_runs import ROOT,REGISTRY,REMOTE,EXTRA_FLAGS,adb,run_capture
p=argparse.ArgumentParser();p.add_argument('phone',choices=['tecno','pixel8']);a=p.parse_args()
for backend in ['baseline_memory','litertlm_memory']:
 spec=REGISTRY[backend]
 adb(a.phone,['push',spec['local'],REMOTE+'/'+spec['remote']])
 adb(a.phone,['shell','chmod','755',REMOTE+'/'+spec['remote']])
 EXTRA_FLAGS[backend]=['--memory_report=true']
for length in [128,1024]:
 for backend in ['litertlm_memory','baseline_memory']:
  tag=f'memory20260913_p{length}_{backend}'
  rec=ROOT/a.phone/'runs'/(tag+'.command.json')
  if rec.exists():
   if json.loads(rec.read_text())['status']!='completed':raise RuntimeError('Prior incomplete capture '+tag)
   continue
  run_capture(a.phone,backend,ROOT/'fixtures'/f'performance_{length}_64.tsv',tag,
    threads=2,phase='memory',reuse=True,warmups=0,runs=2,dump=False,cell=f'p{length}_t2')
