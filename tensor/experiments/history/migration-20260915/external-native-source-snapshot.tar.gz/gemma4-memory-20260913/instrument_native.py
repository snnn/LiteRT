from pathlib import Path
import shutil
root=Path(__file__).resolve().parent
# Copy diagnostic-only accessors into the original v3 runner for an unchanged
# private-workspace baseline. Its constructor and CreateRuntime remain original.
new=(root/'stage_runner.h').read_text();p=root/'baseline/stage_runner.h';old=p.read_text()
block=new[new.index('  // Local diagnostic accessors'):new.index('\n protected:')]
block=block.replace('runtime_ == nullptr ? shared_workspace_ : runtime_->workspace','runtime_ == nullptr ? nullptr : runtime_->workspace')
assert 'MemorySnapshot()' not in old
old=old.replace('\n protected:', '\n'+block+'\n protected:')
old=old.replace('#include "litert/tensor/utils/macros.h"','#include "litert/tensor/utils/macros.h"\n#include "src/xnnpack/subgraph.h"')
p.write_text(old)
shutil.copy2(root/'memory_snapshot.h',root/'baseline/memory_snapshot.h')
collector=r'''
absl::Status RecordMemory(const std::string& phase, const LiveRuntime* rt = nullptr,
    const LoadedTensors* loaded = nullptr, const std::string& case_id = "", int repetition = -1,
    size_t bank_bytes = 0) {
  if (!absl::GetFlag(FLAGS_memory_report)) return absl::OkStatus();
  gemma_memory::Counters counts;
  counts["logical_kv_bytes"] = bank_bytes;
  std::set<const void*> seen_workspaces, seen_owned_buffers, seen_model_buffers;
  if (loaded) for (const auto& entry : loaded->weights_handle) {
    const auto& handle = entry.second;
    auto buffer = handle.GetBuffer();
    if (!buffer.ok()) continue;
    if (!seen_model_buffers.insert(&*buffer).second) continue;
    LRT_TENSOR_ASSIGN_OR_RETURN(const auto bytes, buffer->ByteSize());
    counts["model_source_buffer_bytes"] += bytes;
    counts["model_source_buffer_count"]++;
  }
  auto stage = [&](const SR& runner)->absl::Status {
    if (!runner) return absl::OkStatus();
    LRT_TENSOR_ASSIGN_OR_RETURN(auto info, runner->MemorySnapshot());
    counts["stage_count"]++;
    if (info.workspace && seen_workspaces.insert(info.workspace).second) {
      counts["unique_workspace_count"]++;
      counts["unique_workspace_bytes"] += info.workspace_bytes;
    }
    counts["stage_workspace_bytes_sum_including_shared_aliases"] += info.workspace_bytes;
    counts["graph_constant_capacity_bytes"] += info.graph_constant_capacity_bytes;
    counts["graph_dequantized_capacity_bytes"] += info.graph_dequantized_capacity_bytes;
    counts["graph_fp16_capacity_bytes"] += info.graph_fp16_capacity_bytes;
    for (const auto& b : info.external_buffers) if (b.owns_storage && seen_owned_buffers.insert(b.buffer).second) {
      counts["owned_external_buffer_bytes"] += b.bytes;
      if (b.flags & XNN_VALUE_FLAG_EXTERNAL_OUTPUT) counts["owned_external_output_bytes"] += b.bytes;
    }
    return absl::OkStatus();
  };
  if (rt) {
    for (const auto* signature : {rt->prefill.get(), rt->decode.get()}) if (signature) {
      LRT_TENSOR_RETURN_IF_ERROR(stage(signature->preprocess));
      LRT_TENSOR_RETURN_IF_ERROR(stage(signature->tail));
      for (const auto& layer : signature->stages) {
        LRT_TENSOR_RETURN_IF_ERROR(stage(layer.projection));
        LRT_TENSOR_RETURN_IF_ERROR(stage(layer.attention.runner));
        LRT_TENSOR_RETURN_IF_ERROR(stage(layer.post));
      }
    }
    if (rt->cache) {
      const auto* cache = static_cast<const xnn_internal_weights_cache*>(rt->cache->context);
      counts["packed_weight_bytes"] = cache->cache.weights.size;
      counts["packed_weight_capacity_bytes"] = cache->cache.weights.capacity;
      counts["packed_weight_cache_entries"] = cache->cache.num_entries;
      counts["packed_weight_cache_hits"] = cache->cache.hits;
      counts["packed_weight_cache_misses"] = cache->cache.misses;
    }
  }
  if (!gemma_memory::AppendMemorySnapshot(absl::GetFlag(FLAGS_output_dir)+"/memory.jsonl",
      phase, case_id, repetition, gemma_memory::Object(counts)))
    return absl::InternalError("Could not write memory snapshot");
  return absl::OkStatus();
}
'''
for p in [root/'memory-main.cc',root/'baseline/memory-main.cc']:
 s=p.read_text()
 s=s.replace('#include "stage_runner.h"','#include "stage_runner.h"\n#include "memory_snapshot.h"\n#include "src/xnnpack/cache.h"\nABSL_FLAG(bool, memory_report, false, "Record diagnostic phase RSS/PSS and allocation counters; timing is ineligible.");')
 key='template<class Data>\nabsl::Status BindLive'
 assert key in s;s=s.replace(key,collector+'\n'+key)
 s=s.replace('auto start=BenchClock::now();LRT_TENSOR_RETURN_IF_ERROR(xnn_initialize(nullptr));','LRT_TENSOR_RETURN_IF_ERROR(RecordMemory("before_load"));\n  auto start=BenchClock::now();LRT_TENSOR_RETURN_IF_ERROR(xnn_initialize(nullptr));')
 s=s.replace('double load_ms=Milliseconds(start);','double load_ms=Milliseconds(start);\n  LRT_TENSOR_RETURN_IF_ERROR(RecordMemory("after_load", nullptr, &loaded));')
 s=s.replace('rt->times.total_ms=rt->times.compile_pack_ms=Milliseconds(start);','rt->times.total_ms=rt->times.compile_pack_ms=Milliseconds(start);\n  LRT_TENSOR_RETURN_IF_ERROR(RecordMemory("after_pack", rt.get(), &loaded));')
 s=s.replace('StageTimes times;\n  for(size_t offset=', 'LRT_TENSOR_RETURN_IF_ERROR(RecordMemory("after_kv_allocation", &rt, &loaded, item.id, index, size_t(absl::GetFlag(FLAGS_cache_capacity))*9216));\n  StageTimes times;\n  for(size_t offset=')
 s=s.replace('  std::vector<PassResult> passes;\n  for(size_t i=', '  LRT_TENSOR_RETURN_IF_ERROR(RecordMemory("after_prefill_prefix", &rt, &loaded, item.id, index, size_t(absl::GetFlag(FLAGS_cache_capacity))*9216));\n  std::vector<PassResult> passes;\n  for(size_t i=')
 s=s.replace('    passes.push_back(std::move(pass));','    passes.push_back(std::move(pass));\n    if (i == 0 || i == 1 || i == item.forced.size())\n      LRT_TENSOR_RETURN_IF_ERROR(RecordMemory(i == 0 ? "after_first_logits" : (i == 1 ? "after_first_forced_decode" : "after_last_decode"), &rt, &loaded, item.id, index, size_t(absl::GetFlag(FLAGS_cache_capacity))*9216));')
 s=s.replace('    if(!reuse)rt.reset();','    LRT_TENSOR_RETURN_IF_ERROR(RecordMemory("after_session", rt.get(), &loaded, c.id, index));\n    if(!reuse)rt.reset();')
 s=s.replace('  std::ofstream f(dir+"/run.json");','  rt.reset();\n  LRT_TENSOR_RETURN_IF_ERROR(RecordMemory("after_runtime_destroy", nullptr, &loaded));\n  std::ofstream f(dir+"/run.json");')
 s=s.replace('<<",\\"kv_dtype\\":\\"int8\\",', '<<",\\"memory_report\\":"<<(absl::GetFlag(FLAGS_memory_report)?"true":"false")<<",\\"timings_valid_for_benchmark\\":"<<(absl::GetFlag(FLAGS_memory_report)?"false":"true")\n     <<",\\"kv_dtype\\":\\"int8\\",')
 p.write_text(s)
print('Instrumented native and v4 baseline copies')
