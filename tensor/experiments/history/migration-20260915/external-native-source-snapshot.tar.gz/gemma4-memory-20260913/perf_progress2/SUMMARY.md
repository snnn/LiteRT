# Compact-weight/shared-workspace phone comparison

Status: **partial**; 9 processes, 27 measured sessions, 1728 measured decode calls.

Each complete phone/prompt cell uses six fresh processes in LiteRT-LM, native v4, candidate, candidate, native v4, LiteRT-LM order. Every process reuses its compiled runtimes for one discarded warmup and three measured sessions. Each session contains 64 forced decode calls after first logits. Both phones use two pinned CPU threads; capacity is 2048 and input token IDs are identical.

Values below are median (session minimum–maximum). Decode throughput is `64000 / sum(64 decode elapsed_ms)` per session. First-logit latency is the inclusive first pass `elapsed_ms`; no timing field is substituted.

| Phone / prompt | Runner | Decode tok/s | First logits ms | Peak process RSS MiB |
| --- | --- | ---: | ---: | ---: |
| pixel8 / 128 (partial) | LiteRT-LM CPU | 12.89 (12.62–13.07) | 1391.5 (1379.2–1501.5) | 1599.3 (1599.3–1599.3) |
| pixel8 / 128 (partial) | Native v4 | 16.60 (16.14–17.51) | 789.1 (671.1–861.7) | 2642.7 (2642.6–2642.8) |
| pixel8 / 128 (partial) | Native compact/shared | 17.47 (17.18–19.21) | 751.2 (599.4–919.4) | 1900.4 (1900.3–1900.6) |
| tecno / 128 (partial) | LiteRT-LM CPU | 11.94 (11.85–11.97) | 1252.8 (1232.7–1262.6) | 1608.3 (1608.3–1608.3) |
| tecno / 128 (partial) | Native v4 | 16.76 (15.88–17.10) | 829.0 (769.8–911.4) | 2639.2 (2639.2–2639.2) |
| tecno / 128 (partial) | Native compact/shared | 13.40 (12.76–13.92) | 842.3 (810.3–950.9) | 1913.6 (1913.5–1913.6) |

## Candidate comparisons

| Phone / cell | Reference | Decode speedup | First-logit speedup | Peak RSS delta MiB | Argmax agreement |
| --- | --- | ---: | ---: | ---: | ---: |
| pixel8 / p128_t2 | litertlm | 1.355× | 1.852× | +301.2 | 65/65 |
| pixel8 / p128_t2 | v4 | 1.052× | 1.050× | -742.3 | 65/65 |
| tecno / p128_t2 | litertlm | 1.123× | 1.487× | +305.2 | 65/65 |
| tecno / p128_t2 | v4 | 0.800× | 0.984× | -725.6 | 65/65 |

Speedups above one favor the candidate; negative RSS deltas indicate less resident memory. Candidate changes preserve the original INT2 MLP weights and share one scratch workspace across sequential stages. Native v4 has the same live INT8 KV layout and 128-row chunked prefill but widened MLP weights and separate stage workspaces.

Peak RSS is a process high-water mark, including loading, packing and warmup. Session values within one process are cumulative observations of the same process maximum, not independent steady-state allocations. Process-block RSS below uses the final `run.json` process peak. Memory phase diagnostics are excluded from these timing results.

## Process block medians and session ranges

| Phone / cell | Block | Runner | Decode tok/s median (range) | First logits ms median (range) | Process peak RSS MiB |
| --- | ---: | --- | ---: | ---: | ---: |
| pixel8 / p128_t2 | 0 | litertlm | 12.89 (12.62–13.07) | 1391.5 (1379.2–1501.5) | 1599.3 |
| pixel8 / p128_t2 | 1 | v4 | 16.73 (16.14–17.33) | 788.9 (705.0–789.2) | 2642.7 |
| pixel8 / p128_t2 | 2 | candidate_both | 17.85 (17.18–19.21) | 710.1 (599.4–757.2) | 1900.6 |
| pixel8 / p128_t2 | 3 | candidate_both | 17.27 (17.23–17.67) | 785.1 (745.3–919.4) | 1900.3 |
| pixel8 / p128_t2 | 4 | v4 | 16.46 (16.19–17.51) | 789.3 (671.1–861.7) | 2642.8 |
| tecno / p128_t2 | 0 | litertlm | 11.94 (11.85–11.97) | 1252.8 (1232.7–1262.6) | 1608.3 |
| tecno / p128_t2 | 1 | v4 | 16.76 (15.88–17.10) | 829.0 (769.8–911.4) | 2639.2 |
| tecno / p128_t2 | 2 | candidate_both | 13.25 (13.18–13.70) | 824.2 (810.3–912.3) | 1913.5 |
| tecno / p128_t2 | 3 | candidate_both | 13.56 (12.76–13.92) | 851.9 (832.7–950.9) | 1913.6 |

Telemetry/paging observations requiring review: 1; detailed before/after temperatures, clocks and process samples are retained in `summary.json`.

Passive cooling is requested before every process. CPU clocks remain under the phone’s default DVFS policy, so descriptive ranges include clock and thermal variability. Process blocks are the independent repetition unit; tokens within sessions and sessions within one process are correlated. No token-level confidence intervals are claimed. Argmax agreement is a metadata check, not a substitute for the separate full-logit correctness tests.

[JSON summary](summary.json), [validation and source hashes](validation.json), [cell metrics](cells.csv), [session rows](sessions.csv), [per-pass timings](passes.csv).
