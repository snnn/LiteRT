import argparse,json
from phone_runs import ROOT,REGISTRY,REMOTE,EXTRA_FLAGS,adb,run_capture
p=argparse.ArgumentParser();p.add_argument('phone',choices=['tecno','pixel8']);a=p.parse_args()
prior=list((ROOT/a.phone/'runs').glob('memory20260913_p*.command.json'))
assert len(prior)==4 and all(json.loads(x.read_text())['status']=='completed' for x in prior)
for name in ['stage_workspace_test.android','static_int2_test.android']:
 remote=REMOTE+'/memory20260913_'+name
 adb(a.phone,['push',str(ROOT/name),remote]);adb(a.phone,['shell','chmod','755',remote])
 result=adb(a.phone,['shell',remote],check=False)
 (ROOT/(a.phone+'-'+name+'.log')).write_text(result.stdout+result.stderr)
 if result.returncode:raise RuntimeError('Unit failed: '+name)
 print(json.dumps({'phone':a.phone,'unit':name,'status':'passed'}),flush=True)
spec=REGISTRY['candidate_both']
adb(a.phone,['push',spec['local'],REMOTE+'/'+spec['remote']]);adb(a.phone,['shell','chmod','755',REMOTE+'/'+spec['remote']])
EXTRA_FLAGS['candidate_both']=['--share_workspace=true','--preserve_static_int2=true','--memory_report=false']
for fixture,tag,threads,warmups in [('gate.tsv','gate_t2',2,1),('gate.tsv','gate_t4',4,1),('performance_512_64.tsv','long512',2,0),('long_boundary.tsv','long_boundary',2,0),('boundary.tsv','boundary',2,0)]:
 tag='memory20260913_v1_'+tag
 run_capture(a.phone,'candidate_both',ROOT/'fixtures'/fixture,tag,threads=threads,
   phase='correctness',reuse=True,warmups=warmups,runs=1,dump=True)
